import { 
  User, 
  Lembaga, 
  CVProfile, 
  Buku, 
  Pengajuan, 
  PengajuanItem, 
  PengajuanHistory, 
  AuditLog, 
  StatusPengajuan,
  RekapFilterOptions,
  SystemSettings,
  RegistrationSettings
} from '../types/index.ts';

// Profil Tunggal CV Penyedia
export const INITIAL_CV_PROFILE: CVProfile = {
  id: 'cv-utama-01',
  namaCv: 'CV GRAHA PUSTAKA UTAMA',
  direktur: 'H. Bambang Sugiarto, M.Pd.',
  jabatanDirektur: 'Direktur Utama',
  nipDirektur: '197008151996031002',
  alamat: 'Jl. Pembangunan No. 88, Tarogong Kidul, Jawa Barat',
  telepon: '(0262) 234567',
  whatsapp: '0812-9876-5432',
  email: 'admin@superadmin',
  tahunAnggaranAktif: '2026',
  keterangan: 'Penyedia Resmi Buku SIPOBU - Portal Satuan Pendidikan & CV Penyedia SIPLah'
};

// Pengaturan Isian Registrasi Lembaga Default
export const INITIAL_REGISTRATION_SETTINGS: RegistrationSettings = {
  bukaRegistrasi: true,
  pesanRegistrasiTutup: 'Pendaftaran akun satuan pendidikan baru sedang ditutup sementara oleh CV Penyedia SIPLah. Silakan hubungi nomor WhatsApp Layanan CV jika sekolah Anda memerlukan akses.',
  autoApprove: true,
  pesanPendingVerifikasi: 'Pendaftaran berhasil dikirim. Akun sekolah Anda sedang dalam proses verifikasi & persetujuan oleh tim CV Penyedia SIPLah sebelum dapat digunakan.',
  jenjangDiizinkan: ['SD', 'SMP', 'SMA', 'SMK', 'PKBM', 'Lainnya'],
  statusLembagaDiizinkan: 'SEMUA',
  defaultKabupaten: '',
  defaultProvinsi: 'Jawa Barat',
  kunciWilayahDefault: false,
  wajibValidasiNpsn8Digit: true,
  minPanjangPassword: 6,
  petunjukRegistrasi: 'Pastikan data NPSN dan nama kepala sekolah sesuai dengan data resmi Dapodik / Kemdikbudristek.',
  wajibCentangPernyataan: true,
  teksPernyataan: 'Saya menyatakan dengan sebenar-benarnya bahwa data satuan pendidikan di atas adalah valid dan merupakan perwakilan resmi untuk pemesanan buku melalui SIPOBU.',
  notifWaAdminRegistrasi: true,
  fields: {
    nipKepalaSekolah: { tampilkan: true, wajib: false, label: 'NIP / NIK Kepala Sekolah', keterangan: 'Format 18 digit untuk PNS atau NIK' },
    teleponKantor: { tampilkan: true, wajib: false, label: 'Nomor Telepon Kantor', keterangan: 'Nomor telepon kantor / TU sekolah' },
    alamatJalan: { tampilkan: true, wajib: true, label: 'Alamat Jalan & Nomor', keterangan: 'Alamat lengkap domisili sekolah' },
    desa: { tampilkan: true, wajib: true, label: 'Desa / Kelurahan', keterangan: 'Kelurahan domisili sekolah' },
    kecamatan: { tampilkan: true, wajib: true, label: 'Kecamatan', keterangan: 'Kecamatan domisili sekolah' },
    emailSekolah: { tampilkan: true, wajib: true, label: 'Email Resmi Sekolah', keterangan: 'Email resmi sekolah untuk korespondensi' },
    whatsappOperator: { tampilkan: true, wajib: true, label: 'Nomor WhatsApp Operator', keterangan: 'Nomor WhatsApp aktif operator ARKAS' },
    namaOperator: { tampilkan: true, wajib: true, label: 'Nama Operator Sekolah', keterangan: 'Nama lengkap staf operator yang mengelola ARKAS' }
  }
};

// Pengaturan Sistem Super Admin Default
export const INITIAL_SYSTEM_SETTINGS: SystemSettings = {
  tahunAnggaranAktif: '2026',
  periodePengajuanBuka: true,
  batasWaktuPengajuan: '2026-11-30',
  prefixNomorPengajuan: 'PB',
  digitNomorUrut: 4,
  izinkanBukuCustom: true,
  minEksemplarPerItem: 1,
  maxEksemplarPerItem: 500,
  disclaimerDokumen: 'Dokumen ini merupakan rekapitulasi resmi pemesanan buku melalui SIPOBU - Portal Satuan Pendidikan & CV Penyedia SIPLah.',
  templateCatatanSetuju: 'Daftar kebutuhan buku teks telah diverifikasi lengkap dan disetujui sesuai pesanan sekolah.',
  templateCatatanRevisi: 'Mohon periksa dan sesuaikan kembali jumlah eksemplar buku dengan kebutuhan riil pemesanan sekolah.',
  notifWaAdminAktif: true,
  nomorWaAdmin: '0813-1122-3344',
  templatePesanWaAdmin: 'Terdapat pemesanan buku baru melalui SIPOBU dari lembaga mitra. Mohon untuk diverifikasi berkasnya melalui sistem.',
  registrationSettings: INITIAL_REGISTRATION_SETTINGS
};

// Master Buku Awal Lengkap (Kurikulum Merdeka & 2013)
export const INITIAL_BUKU: Buku[] = [
  {
    id: 'bk-sd-01',
    kodeBuku: 'BK-KM-SD-001',
    isbn: '978-602-244-301-8',
    judul: 'Matematika: Belajar Bersama Temanmu untuk SD Kelas 1',
    penulis: 'Tim Gakkosho Tosho',
    penerbit: 'Pusat Kurikulum dan Perbukuan Kemdikbudristek',
    jenjang: 'SD',
    kelas: 'Kelas 1',
    mataPelajaran: 'Matematika',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 21500,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-sd-02',
    kodeBuku: 'BK-KM-SD-002',
    isbn: '978-602-244-302-5',
    judul: 'Bahasa Indonesia: Aku Bisa! untuk SD Kelas 1',
    penulis: 'Sofie Dewayani',
    penerbit: 'Pusat Kurikulum dan Perbukuan Kemdikbudristek',
    jenjang: 'SD',
    kelas: 'Kelas 1',
    mataPelajaran: 'Bahasa Indonesia',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 23000,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-sd-03',
    kodeBuku: 'BK-KM-SD-004',
    isbn: '978-602-244-374-2',
    judul: 'Ilmu Pengetahuan Alam dan Sosial (IPAS) untuk SD Kelas 4',
    penulis: 'Amalia Fitri, dkk.',
    penerbit: 'Pusat Kurikulum dan Perbukuan Kemdikbudristek',
    jenjang: 'SD',
    kelas: 'Kelas 4',
    mataPelajaran: 'IPAS',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 28500,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-sd-04',
    kodeBuku: 'BK-KM-SD-005',
    isbn: '978-602-244-375-9',
    judul: 'Pendidikan Pancasila untuk SD/MI Kelas 4',
    penulis: 'Dede Kurniawan, dkk.',
    penerbit: 'Pusat Kurikulum dan Perbukuan Kemdikbudristek',
    jenjang: 'SD',
    kelas: 'Kelas 4',
    mataPelajaran: 'Pendidikan Pancasila',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 22000,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-smp-01',
    kodeBuku: 'BK-KM-SMP-001',
    isbn: '978-602-244-381-0',
    judul: 'Informatika untuk SMP Kelas 7',
    penulis: 'Maresha Caroline Wijanto, dkk.',
    penerbit: 'Pusat Perbukuan Kemdikbudristek',
    jenjang: 'SMP',
    kelas: 'Kelas 7',
    mataPelajaran: 'Informatika',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 31000,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-smp-02',
    kodeBuku: 'BK-KM-SMP-002',
    isbn: '978-602-244-382-7',
    judul: 'English for Nusantara untuk SMP/MTs Kelas 7',
    penulis: 'Ika Lestari Damayanti, dkk.',
    penerbit: 'Pusat Perbukuan Kemdikbudristek',
    jenjang: 'SMP',
    kelas: 'Kelas 7',
    mataPelajaran: 'Bahasa Inggris',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 29500,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-smp-03',
    kodeBuku: 'BK-KM-SMP-003',
    isbn: '978-602-244-383-4',
    judul: 'Ilmu Pengetahuan Alam untuk SMP Kelas 7',
    penulis: 'Victoriani Inabuy, dkk.',
    penerbit: 'Pusat Perbukuan Kemdikbudristek',
    jenjang: 'SMP',
    kelas: 'Kelas 7',
    mataPelajaran: 'IPA',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 34000,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-sma-01',
    kodeBuku: 'BK-KM-SMA-001',
    isbn: '978-602-244-496-1',
    judul: 'Matematika untuk SMA/SMK Kelas 10',
    penulis: 'Dicky Susanto, dkk.',
    penerbit: 'Pusat Kurikulum dan Perbukuan Kemdikbudristek',
    jenjang: 'SMA',
    kelas: 'Kelas 10',
    mataPelajaran: 'Matematika',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 35000,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-sma-02',
    kodeBuku: 'BK-KM-SMA-002',
    isbn: '978-602-244-498-5',
    judul: 'Fisika untuk SMA/MA Kelas 11',
    penulis: 'Marianna Magdalena Radjawane',
    penerbit: 'Pusat Perbukuan Kemdikbudristek',
    jenjang: 'SMA',
    kelas: 'Kelas 11',
    mataPelajaran: 'Fisika',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 38000,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-paud-01',
    kodeBuku: 'BK-KM-PAUD-001',
    isbn: '978-602-244-555-5',
    judul: 'Buku Panduan Guru: Belajar dan Bermain Berbasis Buku Cerita PAUD',
    penulis: 'Lilis Madyawati',
    penerbit: 'Pusat Perbukuan Kemdikbudristek',
    jenjang: 'PAUD',
    kelas: 'PAUD/TK',
    mataPelajaran: 'Tematik PAUD',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 45000,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  },
  {
    id: 'bk-smk-01',
    kodeBuku: 'BK-KM-SMK-001',
    isbn: '978-602-244-678-1',
    judul: 'Dasar-Dasar Teknik Jaringan Komputer dan Telekomunikasi SMK Kelas 10',
    penulis: 'Supriyanto',
    penerbit: 'Pusat Perbukuan Kemdikbudristek',
    jenjang: 'SMK',
    kelas: 'Kelas 10',
    mataPelajaran: 'Kejuruan TJKT',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 42000,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  }
];

// Lembaga Awal
export const INITIAL_LEMBAGA: Lembaga[] = [
  {
    id: 'lem-01',
    userId: 'usr-lem-01',
    npsn: '20104501',
    namaLembaga: 'SD Negeri Sukamaju 01',
    jenjang: 'SD',
    statusLembaga: 'Negeri',
    kepalaSekolah: 'Dra. Hj. Siti Rohmah, M.Pd.',
    nipKepalaSekolah: '197205141998032004',
    operator: 'Rahmat Hidayat, S.Kom.',
    email: 'sdn.sukamaju01@sekolah.id',
    whatsapp: '0813-1122-3344',
    telepon: '(021) 89110022',
    alamat: 'Jl. Ki Hajar Dewantara No. 12',
    desa: 'Sukamaju',
    kecamatan: 'Cikarang Pusat',
    kabupaten: 'Bekasi',
    provinsi: 'Jawa Barat',
    createdAt: '2026-01-10T08:00:00Z'
  },
  {
    id: 'lem-02',
    userId: 'usr-lem-02',
    npsn: '20108912',
    namaLembaga: 'SMP Negeri 2 Tambun',
    jenjang: 'SMP',
    statusLembaga: 'Negeri',
    kepalaSekolah: 'Drs. Hendra Gunawan, M.M.',
    nipKepalaSekolah: '196803201994121002',
    operator: 'Ahmad Fauzi, S.Pd.',
    email: 'smpn2tambun@sekolah.id',
    whatsapp: '0812-3344-5566',
    telepon: '(021) 88334455',
    alamat: 'Jl. Sultan Hasanudin No. 88',
    desa: 'Setiadarma',
    kecamatan: 'Tambun Selatan',
    kabupaten: 'Bekasi',
    provinsi: 'Jawa Barat',
    createdAt: '2026-01-12T09:30:00Z'
  },
  {
    id: 'lem-03',
    userId: 'usr-lem-03',
    npsn: '20109923',
    namaLembaga: 'SMA Negeri 1 Cikarang',
    jenjang: 'SMA',
    statusLembaga: 'Negeri',
    kepalaSekolah: 'Dr. H. Mulyadi, M.Si.',
    nipKepalaSekolah: '197011021995031003',
    operator: 'Nurul Indah, S.Kom.',
    email: 'sman1cikarang@sekolah.id',
    whatsapp: '0815-5566-7788',
    telepon: '(021) 89001122',
    alamat: 'Jl. KH. Fudholi No. 15',
    desa: 'Karangasih',
    kecamatan: 'Cikarang Utara',
    kabupaten: 'Bekasi',
    provinsi: 'Jawa Barat',
    createdAt: '2026-01-15T11:00:00Z'
  },
  {
    id: 'lem-04',
    userId: 'usr-lem-04',
    npsn: '69912034',
    namaLembaga: 'TK Pertiwi Harapan',
    jenjang: 'TK',
    statusLembaga: 'Swasta',
    kepalaSekolah: 'Euis Karlina, S.Pd.AUD.',
    operator: 'Rina Marlina',
    email: 'tk.pertiwiharapan@gmail.com',
    whatsapp: '0857-7788-9900',
    telepon: '(021) 89223344',
    alamat: 'Kompleks Harapan Indah Blok C3',
    desa: 'Hegarmanah',
    kecamatan: 'Cikarang Timur',
    kabupaten: 'Bekasi',
    provinsi: 'Jawa Barat',
    createdAt: '2026-01-18T14:15:00Z'
  }
];

// Akun Pengguna Awal
export const INITIAL_USERS: User[] = [
  {
    id: 'usr-cv-superadmin',
    username: 'admin@superadmin',
    email: 'admin@superadmin',
    password: 'admin123@',
    role: 'CV',
    status: 'ACTIVE',
    createdAt: '2026-01-01T00:00:00Z'
  },
  {
    id: 'usr-cv-01',
    username: 'admin_cv',
    email: 'arkas.grahapustaka@gmail.com',
    password: 'admin123@',
    role: 'CV',
    status: 'ACTIVE',
    createdAt: '2026-01-01T00:00:00Z'
  },
  {
    id: 'usr-lem-01',
    username: 'sdn_sukamaju01',
    email: 'sdn.sukamaju01@sekolah.id',
    password: 'password123',
    role: 'LEMBAGA',
    status: 'ACTIVE',
    lembagaId: 'lem-01',
    createdAt: '2026-01-10T08:00:00Z'
  },
  {
    id: 'usr-lem-02',
    username: 'smpn2_tambun',
    email: 'smpn2tambun@sekolah.id',
    password: 'password123',
    role: 'LEMBAGA',
    status: 'ACTIVE',
    lembagaId: 'lem-02',
    createdAt: '2026-01-12T09:30:00Z'
  },
  {
    id: 'usr-lem-03',
    username: 'sman1_cikarang',
    email: 'sman1cikarang@sekolah.id',
    password: 'password123',
    role: 'LEMBAGA',
    status: 'ACTIVE',
    lembagaId: 'lem-03',
    createdAt: '2026-01-15T11:00:00Z'
  },
  {
    id: 'usr-lem-04',
    username: 'tk_pertiwi',
    email: 'tk.pertiwiharapan@gmail.com',
    password: 'password123',
    role: 'LEMBAGA',
    status: 'ACTIVE',
    lembagaId: 'lem-04',
    createdAt: '2026-01-18T14:15:00Z'
  }
];

// Pengajuan Awal Contoh
export const INITIAL_PENGAJUAN: Pengajuan[] = [
  {
    id: 'pg-2026-001',
    nomorPengajuan: 'PB-2026-0001',
    lembagaId: 'lem-01',
    tahunAnggaran: '2026',
    tanggalPengajuan: '2026-02-10',
    status: 'DISETUJUI',
    catatanCv: 'Daftar kebutuhan buku teks Kurikulum Merdeka telah diverifikasi lengkap dan sesuai pagu ARKAS BOSP Reguler 2026.',
    keteranganUmum: 'Pengadaan Buku Pelajaran Pokok Semester 1 & 2 Tahun Ajaran 2026/2027.',
    totalJenisBuku: 3,
    totalBuku: 180,
    totalNilai: 4330000,
    items: [
      {
        id: 'item-01',
        bukuId: 'bk-sd-01',
        kodeBuku: 'BK-KM-SD-001',
        isbn: '978-602-244-301-8',
        judul: 'Matematika: Belajar Bersama Temanmu untuk SD Kelas 1',
        penulis: 'Tim Gakkosho Tosho',
        penerbit: 'Pusat Kurikulum dan Perbukuan Kemdikbudristek',
        jenjang: 'SD',
        kelas: 'Kelas 1',
        mataPelajaran: 'Matematika',
        kurikulum: 'Kurikulum Merdeka',
        jumlah: 60,
        hargaSatuan: 21500,
        total: 1290000,
        keterangan: 'Untuk 2 rombel kelas 1'
      },
      {
        id: 'item-02',
        bukuId: 'bk-sd-02',
        kodeBuku: 'BK-KM-SD-002',
        isbn: '978-602-244-302-5',
        judul: 'Bahasa Indonesia: Aku Bisa! untuk SD Kelas 1',
        penulis: 'Sofie Dewayani',
        penerbit: 'Pusat Kurikulum dan Perbukuan Kemdikbudristek',
        jenjang: 'SD',
        kelas: 'Kelas 1',
        mataPelajaran: 'Bahasa Indonesia',
        kurikulum: 'Kurikulum Merdeka',
        jumlah: 60,
        hargaSatuan: 23000,
        total: 1380000,
        keterangan: 'Untuk 2 rombel kelas 1'
      },
      {
        id: 'item-03',
        bukuId: 'bk-sd-03',
        kodeBuku: 'BK-KM-SD-004',
        isbn: '978-602-244-374-2',
        judul: 'Ilmu Pengetahuan Alam dan Sosial (IPAS) untuk SD Kelas 4',
        penulis: 'Amalia Fitri, dkk.',
        penerbit: 'Pusat Kurikulum dan Perbukuan Kemdikbudristek',
        jenjang: 'SD',
        kelas: 'Kelas 4',
        mataPelajaran: 'IPAS',
        kurikulum: 'Kurikulum Merdeka',
        jumlah: 60,
        hargaSatuan: 27666.67, // sesuaikan
        total: 1660000,
        keterangan: 'Untuk siswa kelas 4 baru'
      }
    ],
    history: [
      {
        id: 'hist-01',
        pengajuanId: 'pg-2026-001',
        userId: 'usr-lem-01',
        userName: 'Rahmat Hidayat (Operator SDN Sukamaju 01)',
        userRole: 'LEMBAGA',
        statusBaru: 'DIKIRIM LEMBAGA',
        catatan: 'Pengajuan dibuat dan dikirim ke CV untuk perencanaan ARKAS 2026.',
        createdAt: '2026-02-10T09:15:00Z'
      },
      {
        id: 'hist-02',
        pengajuanId: 'pg-2026-001',
        userId: 'usr-cv-01',
        userName: 'Admin CV Graha Pustaka',
        userRole: 'CV',
        statusSebelumnya: 'DIKIRIM LEMBAGA',
        statusBaru: 'DIPERIKSA CV',
        catatan: 'Dokumen dan rincian buku sedang dalam tahap verifikasi ketersediaan dan kesesuaian HET.',
        createdAt: '2026-02-11T10:00:00Z'
      },
      {
        id: 'hist-03',
        pengajuanId: 'pg-2026-001',
        userId: 'usr-cv-01',
        userName: 'Admin CV Graha Pustaka',
        userRole: 'CV',
        statusSebelumnya: 'DIPERIKSA CV',
        statusBaru: 'DISETUJUI',
        catatan: 'Daftar kebutuhan buku teks Kurikulum Merdeka telah diverifikasi lengkap dan sesuai pagu ARKAS BOSP Reguler 2026.',
        createdAt: '2026-02-12T14:30:00Z'
      }
    ],
    createdAt: '2026-02-10T09:00:00Z',
    updatedAt: '2026-02-12T14:30:00Z'
  },
  {
    id: 'pg-2026-002',
    nomorPengajuan: 'PB-2026-0002',
    lembagaId: 'lem-02',
    tahunAnggaran: '2026',
    tanggalPengajuan: '2026-02-18',
    status: 'PERLU REVISI',
    catatanCv: 'Mohon revisi jumlah buku pada item nomor 2 (English for Nusantara), sesuaikan dengan jumlah siswa terdaftar di Dapodik yaitu 128 eksemplar bukan 180.',
    keteranganUmum: 'Kebutuhan Buku Penunjang & Pokok Siswa Baru SMP Kelas 7.',
    totalJenisBuku: 2,
    totalBuku: 300,
    totalNilai: 9020000,
    items: [
      {
        id: 'item-04',
        bukuId: 'bk-smp-01',
        kodeBuku: 'BK-KM-SMP-001',
        isbn: '978-602-244-381-0',
        judul: 'Informatika untuk SMP Kelas 7',
        penulis: 'Maresha Caroline Wijanto, dkk.',
        penerbit: 'Pusat Perbukuan Kemdikbudristek',
        jenjang: 'SMP',
        kelas: 'Kelas 7',
        mataPelajaran: 'Informatika',
        kurikulum: 'Kurikulum Merdeka',
        jumlah: 120,
        hargaSatuan: 31000,
        total: 3720000,
        keterangan: 'Siswa kelas 7'
      },
      {
        id: 'item-05',
        bukuId: 'bk-smp-02',
        kodeBuku: 'BK-KM-SMP-002',
        isbn: '978-602-244-382-7',
        judul: 'English for Nusantara untuk SMP/MTs Kelas 7',
        penulis: 'Ika Lestari Damayanti, dkk.',
        penerbit: 'Pusat Perbukuan Kemdikbudristek',
        jenjang: 'SMP',
        kelas: 'Kelas 7',
        mataPelajaran: 'Bahasa Inggris',
        kurikulum: 'Kurikulum Merdeka',
        jumlah: 180,
        hargaSatuan: 29500,
        total: 5310000,
        keterangan: 'Siswa kelas 7'
      }
    ],
    history: [
      {
        id: 'hist-04',
        pengajuanId: 'pg-2026-002',
        userId: 'usr-lem-02',
        userName: 'Ahmad Fauzi (Operator SMPN 2 Tambun)',
        userRole: 'LEMBAGA',
        statusBaru: 'DIKIRIM LEMBAGA',
        catatan: 'Pengajuan kebutuhan buku baru diajukan ke CV.',
        createdAt: '2026-02-18T10:00:00Z'
      },
      {
        id: 'hist-05',
        pengajuanId: 'pg-2026-002',
        userId: 'usr-cv-01',
        userName: 'Admin CV Graha Pustaka',
        userRole: 'CV',
        statusSebelumnya: 'DIKIRIM LEMBAGA',
        statusBaru: 'PERLU REVISI',
        catatan: 'Mohon revisi jumlah buku pada item nomor 2 (English for Nusantara), sesuaikan dengan jumlah siswa terdaftar di Dapodik yaitu 128 eksemplar bukan 180.',
        createdAt: '2026-02-19T11:20:00Z'
      }
    ],
    createdAt: '2026-02-18T10:00:00Z',
    updatedAt: '2026-02-19T11:20:00Z'
  },
  {
    id: 'pg-2026-003',
    nomorPengajuan: 'PB-2026-0003',
    lembagaId: 'lem-03',
    tahunAnggaran: '2026',
    tanggalPengajuan: '2026-02-25',
    status: 'DIKIRIM LEMBAGA',
    keteranganUmum: 'Daftar Kebutuhan Buku Mata Pelajaran Wajib dan Peminatan Kelas 10 & 11 Tahun 2026.',
    totalJenisBuku: 2,
    totalBuku: 150,
    totalNilai: 5450000,
    items: [
      {
        id: 'item-06',
        bukuId: 'bk-sma-01',
        kodeBuku: 'BK-KM-SMA-001',
        isbn: '978-602-244-496-1',
        judul: 'Matematika untuk SMA/SMK Kelas 10',
        penulis: 'Dicky Susanto, dkk.',
        penerbit: 'Pusat Kurikulum dan Perbukuan Kemdikbudristek',
        jenjang: 'SMA',
        kelas: 'Kelas 10',
        mataPelajaran: 'Matematika',
        kurikulum: 'Kurikulum Merdeka',
        jumlah: 75,
        hargaSatuan: 35000,
        total: 2625000,
        keterangan: 'Perpustakaan & siswa'
      },
      {
        id: 'item-07',
        bukuId: 'bk-sma-02',
        kodeBuku: 'BK-KM-SMA-002',
        isbn: '978-602-244-498-5',
        judul: 'Fisika untuk SMA/MA Kelas 11',
        penulis: 'Marianna Magdalena Radjawane',
        penerbit: 'Pusat Perbukuan Kemdikbudristek',
        jenjang: 'SMA',
        kelas: 'Kelas 11',
        mataPelajaran: 'Fisika',
        kurikulum: 'Kurikulum Merdeka',
        jumlah: 75,
        hargaSatuan: 37666.67,
        total: 2825000,
        keterangan: 'Peminatan MIPA'
      }
    ],
    history: [
      {
        id: 'hist-06',
        pengajuanId: 'pg-2026-003',
        userId: 'usr-lem-03',
        userName: 'Nurul Indah (Operator SMAN 1 Cikarang)',
        userRole: 'LEMBAGA',
        statusBaru: 'DIKIRIM LEMBAGA',
        catatan: 'Pengajuan telah dikirim dan menunggu verifikasi CV penyedia.',
        createdAt: '2026-02-25T08:45:00Z'
      }
    ],
    createdAt: '2026-02-25T08:45:00Z',
    updatedAt: '2026-02-25T08:45:00Z'
  },
  {
    id: 'pg-2026-004',
    nomorPengajuan: 'PB-2026-0004',
    lembagaId: 'lem-04',
    tahunAnggaran: '2026',
    tanggalPengajuan: '2026-02-28',
    status: 'SELESAI REKAP',
    catatanCv: 'Sudah selesai direkap ke dalam Buku Besar Perencanaan ARKAS wilayah Cikarang Timur.',
    keteranganUmum: 'Buku panduan dan stimulasi bermain anak usia dini.',
    totalJenisBuku: 1,
    totalBuku: 30,
    totalNilai: 1350000,
    items: [
      {
        id: 'item-08',
        bukuId: 'bk-paud-01',
        kodeBuku: 'BK-KM-PAUD-001',
        isbn: '978-602-244-555-5',
        judul: 'Buku Panduan Guru: Belajar dan Bermain Berbasis Buku Cerita PAUD',
        penulis: 'Lilis Madyawati',
        penerbit: 'Pusat Perbukuan Kemdikbudristek',
        jenjang: 'PAUD',
        kelas: 'PAUD/TK',
        mataPelajaran: 'Tematik PAUD',
        kurikulum: 'Kurikulum Merdeka',
        jumlah: 30,
        hargaSatuan: 45000,
        total: 1350000,
        keterangan: 'Pengadaan PAUD 2026'
      }
    ],
    history: [
      {
        id: 'hist-07',
        pengajuanId: 'pg-2026-004',
        userId: 'usr-lem-04',
        userName: 'Rina Marlina (TK Pertiwi Harapan)',
        userRole: 'LEMBAGA',
        statusBaru: 'DIKIRIM LEMBAGA',
        catatan: 'Pengajuan kebutuhan buku TK dikirim.',
        createdAt: '2026-02-28T10:00:00Z'
      },
      {
        id: 'hist-08',
        pengajuanId: 'pg-2026-004',
        userId: 'usr-cv-01',
        userName: 'Admin CV Graha Pustaka',
        userRole: 'CV',
        statusSebelumnya: 'DIKIRIM LEMBAGA',
        statusBaru: 'DISETUJUI',
        catatan: 'Disetujui untuk dianggarkan di BOSP PAUD.',
        createdAt: '2026-03-01T09:00:00Z'
      },
      {
        id: 'hist-09',
        pengajuanId: 'pg-2026-004',
        userId: 'usr-cv-01',
        userName: 'Admin CV Graha Pustaka',
        userRole: 'CV',
        statusSebelumnya: 'DISETUJUI',
        statusBaru: 'SELESAI REKAP',
        catatan: 'Sudah selesai direkap ke dalam Buku Besar Perencanaan ARKAS wilayah Cikarang Timur.',
        createdAt: '2026-03-02T16:00:00Z'
      }
    ],
    createdAt: '2026-02-28T10:00:00Z',
    updatedAt: '2026-03-02T16:00:00Z'
  }
];

// Audit Log Awal
export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'aud-01',
    userId: 'usr-lem-01',
    userName: 'Rahmat Hidayat (SDN Sukamaju 01)',
    userRole: 'LEMBAGA',
    aktivitas: 'Operator Lembaga membuat pengajuan baru PB-2026-0001',
    referensiId: 'PB-2026-0001',
    createdAt: '2026-02-10T09:15:00Z'
  },
  {
    id: 'aud-02',
    userId: 'usr-cv-01',
    userName: 'Admin CV Graha Pustaka',
    userRole: 'CV',
    aktivitas: 'Admin CV menyetujui pengajuan PB-2026-0001 milik SDN Sukamaju 01',
    referensiId: 'PB-2026-0001',
    createdAt: '2026-02-12T14:30:00Z'
  },
  {
    id: 'aud-03',
    userId: 'usr-lem-02',
    userName: 'Ahmad Fauzi (SMPN 2 Tambun)',
    userRole: 'LEMBAGA',
    aktivitas: 'Operator Lembaga mengirim Pengajuan PB-2026-0002',
    referensiId: 'PB-2026-0002',
    createdAt: '2026-02-18T10:00:00Z'
  },
  {
    id: 'aud-04',
    userId: 'usr-cv-01',
    userName: 'Admin CV Graha Pustaka',
    userRole: 'CV',
    aktivitas: 'Admin CV mengubah status PB-2026-0002 menjadi PERLU REVISI',
    referensiId: 'PB-2026-0002',
    createdAt: '2026-02-19T11:20:00Z'
  }
];

// Keys untuk localStorage
const STORAGE_KEYS = {
  USERS: 'arkas_users_v1',
  LEMBAGA: 'arkas_lembaga_v1',
  CV_PROFILE: 'arkas_cv_profile_v1',
  BUKU: 'arkas_buku_v1',
  PENGAJUAN: 'arkas_pengajuan_v1',
  AUDIT_LOGS: 'arkas_audit_logs_v1',
  CURRENT_USER: 'arkas_current_user_v1',
  SYSTEM_SETTINGS: 'arkas_system_settings_v1'
};

class ArkasStorageService {
  private users: User[] = [];
  private lembaga: Lembaga[] = [];
  private cvProfile: CVProfile = INITIAL_CV_PROFILE;
  private systemSettings: SystemSettings = INITIAL_SYSTEM_SETTINGS;
  private buku: Buku[] = [];
  private pengajuan: Pengajuan[] = [];
  private auditLogs: AuditLog[] = [];
  private currentUser: User | null = null;
  private listeners: (() => void)[] = [];

  constructor() {
    this.init();
  }

  private init() {
    try {
      const storedUsers = localStorage.getItem(STORAGE_KEYS.USERS);
      const storedLembaga = localStorage.getItem(STORAGE_KEYS.LEMBAGA);
      const storedCv = localStorage.getItem(STORAGE_KEYS.CV_PROFILE);
      const storedSettings = localStorage.getItem(STORAGE_KEYS.SYSTEM_SETTINGS);
      const storedBuku = localStorage.getItem(STORAGE_KEYS.BUKU);
      const storedPengajuan = localStorage.getItem(STORAGE_KEYS.PENGAJUAN);
      const storedLogs = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      const storedCurrentUser = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);

      this.users = storedUsers ? JSON.parse(storedUsers) : [...INITIAL_USERS];
      this.lembaga = storedLembaga ? JSON.parse(storedLembaga) : [...INITIAL_LEMBAGA];
      this.cvProfile = storedCv ? JSON.parse(storedCv) : { ...INITIAL_CV_PROFILE };
      this.systemSettings = storedSettings ? { ...INITIAL_SYSTEM_SETTINGS, ...JSON.parse(storedSettings) } : { ...INITIAL_SYSTEM_SETTINGS };
      this.buku = storedBuku ? JSON.parse(storedBuku) : [...INITIAL_BUKU];
      this.pengajuan = storedPengajuan ? JSON.parse(storedPengajuan) : [...INITIAL_PENGAJUAN];
      this.auditLogs = storedLogs ? JSON.parse(storedLogs) : [...INITIAL_AUDIT_LOGS];

      // Pastikan akun CV Super Admin selalu ada dan terbarui dengan password admin123@
      const superAdminIndex = this.users.findIndex(u => u.username === 'admin@superadmin' || u.email === 'admin@superadmin');
      if (superAdminIndex >= 0) {
        this.users[superAdminIndex] = {
          ...this.users[superAdminIndex],
          username: 'admin@superadmin',
          email: 'admin@superadmin',
          password: 'admin123@',
          role: 'CV',
          status: 'ACTIVE'
        };
      } else {
        this.users.unshift({
          id: 'usr-cv-superadmin',
          username: 'admin@superadmin',
          email: 'admin@superadmin',
          password: 'admin123@',
          role: 'CV',
          status: 'ACTIVE',
          createdAt: new Date().toISOString()
        });
      }

      // Pastikan profil CV terbarui dan kata Garut dibersihkan
      if (this.cvProfile.namaCv?.includes('GARUT') || this.cvProfile.namaCv === 'CV GRAHA PUSTAKA NUSANTARA') {
        this.cvProfile.namaCv = 'CV GRAHA PUSTAKA UTAMA';
      }
      if (this.cvProfile.alamat?.includes('Garut')) {
        this.cvProfile.alamat = this.cvProfile.alamat.replace(/,?\s*Kabupaten Garut/gi, '').replace(/,?\s*Garut/gi, '');
      }
      if (this.cvProfile.keterangan?.includes('GARUT')) {
        this.cvProfile.keterangan = this.cvProfile.keterangan.replace(/GARUT\s*-?\s*/gi, '');
      }

      // Bersihkan teks lama disclaimer yang mengandung frasa non transaksional, tanpa pembayaran, dll
      const currentDisclaimer = this.systemSettings?.disclaimerDokumen || '';
      if (
        !currentDisclaimer ||
        currentDisclaimer.includes('bukan sistem transaksi') ||
        currentDisclaimer.toLowerCase().includes('tanpa pembayaran') ||
        currentDisclaimer.toLowerCase().includes('non transaksional') ||
        currentDisclaimer.toLowerCase().includes('non-transaksional') ||
        currentDisclaimer.includes('perencanaan dan penganggaran ARKAS') ||
        currentDisclaimer.includes('GARUT') ||
        !currentDisclaimer.includes('SIPLah')
      ) {
        this.systemSettings.disclaimerDokumen = INITIAL_SYSTEM_SETTINGS.disclaimerDokumen;
      }

      if (!this.cvProfile.keterangan || !this.cvProfile.keterangan.includes('SIPLah')) {
        this.cvProfile.keterangan = INITIAL_CV_PROFILE.keterangan;
      }

      // Bersihkan pernyataan registrasi jika masih berisi teks lama atau kata GARUT
      if (
        this.systemSettings?.registrationSettings?.teksPernyataan &&
        (this.systemSettings.registrationSettings.teksPernyataan.includes('perencanaan ARKAS') ||
         this.systemSettings.registrationSettings.teksPernyataan.includes('tanpa pembayaran') ||
         this.systemSettings.registrationSettings.teksPernyataan.includes('GARUT') ||
         this.systemSettings.registrationSettings.teksPernyataan.toLowerCase().includes('non transaksional'))
      ) {
        this.systemSettings.registrationSettings.teksPernyataan = INITIAL_REGISTRATION_SETTINGS.teksPernyataan;
      }

      if (this.systemSettings?.registrationSettings?.defaultKabupaten?.toLowerCase().includes('garut')) {
        this.systemSettings.registrationSettings.defaultKabupaten = '';
      }

      if (this.systemSettings?.templatePesanWaAdmin?.includes('GARUT')) {
        this.systemSettings.templatePesanWaAdmin = this.systemSettings.templatePesanWaAdmin.replace(/GARUT\s*/g, '');
      }

      // Pastikan jenjang registrasi tidak memuat TK dan PAUD
      if (this.systemSettings?.registrationSettings?.jenjangDiizinkan) {
        this.systemSettings.registrationSettings.jenjangDiizinkan = 
          this.systemSettings.registrationSettings.jenjangDiizinkan.filter(j => j !== 'TK' && j !== 'PAUD');
      }

      if (storedCurrentUser) {
        try {
          const parsed = JSON.parse(storedCurrentUser);
          const found = this.users.find(u => u.id === parsed.id || u.username === parsed.username);
          this.currentUser = (found && found.status === 'ACTIVE') ? found : null;
        } catch {
          this.currentUser = null;
        }
      } else {
        // Jangan auto-login demo. Pengguna diarahkan untuk login
        this.currentUser = null;
      }

      this.persist();
    } catch (e) {
      console.error('Error initializing ArkasStorage:', e);
      this.users = [...INITIAL_USERS];
      this.lembaga = [...INITIAL_LEMBAGA];
      this.cvProfile = { ...INITIAL_CV_PROFILE };
      this.systemSettings = { ...INITIAL_SYSTEM_SETTINGS };
      this.buku = [...INITIAL_BUKU];
      this.pengajuan = [...INITIAL_PENGAJUAN];
      this.auditLogs = [...INITIAL_AUDIT_LOGS];
      this.currentUser = null;
    }
  }

  private persist() {
    try {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(this.users));
      localStorage.setItem(STORAGE_KEYS.LEMBAGA, JSON.stringify(this.lembaga));
      localStorage.setItem(STORAGE_KEYS.CV_PROFILE, JSON.stringify(this.cvProfile));
      localStorage.setItem(STORAGE_KEYS.SYSTEM_SETTINGS, JSON.stringify(this.systemSettings));
      localStorage.setItem(STORAGE_KEYS.BUKU, JSON.stringify(this.buku));
      localStorage.setItem(STORAGE_KEYS.PENGAJUAN, JSON.stringify(this.pengajuan));
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(this.auditLogs));
      if (this.currentUser) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(this.currentUser));
      }
    } catch (e) {
      console.warn('Failed to save to localStorage:', e);
    }
    this.notify();
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(fn => fn());
  }

  // --- Auth & Users ---
  public getCurrentUser(): User | null {
    return this.currentUser;
  }

  public getCurrentLembaga(): Lembaga | null {
    if (!this.currentUser || this.currentUser.role !== 'LEMBAGA') return null;
    return this.lembaga.find(l => l.id === this.currentUser?.lembagaId) || null;
  }

  public setCurrentUser(user: User | null) {
    this.currentUser = user;
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
    this.notify();
  }

  public switchRole(role: 'LEMBAGA' | 'CV', specificLembagaId?: string) {
    if (role === 'CV') {
      const cvUser = this.users.find(u => u.role === 'CV') || this.users[0];
      this.setCurrentUser(cvUser);
    } else {
      const lemUser = specificLembagaId 
        ? this.users.find(u => u.lembagaId === specificLembagaId)
        : this.users.find(u => u.role === 'LEMBAGA');
      if (lemUser) {
        this.setCurrentUser(lemUser);
      }
    }
  }

  public login(identifier: string, password?: string): { success: boolean; user?: User; error?: string } {
    const cleanId = identifier.trim().toLowerCase();
    
    // Cari berdasarkan username, email, atau NPSN
    let foundUser = this.users.find(u => 
      u.username.toLowerCase() === cleanId || 
      u.email.toLowerCase() === cleanId
    );

    if (!foundUser) {
      // Cek apakah identifier adalah NPSN
      const foundLembaga = this.lembaga.find(l => l.npsn === identifier.trim());
      if (foundLembaga) {
        foundUser = this.users.find(u => u.id === foundLembaga.userId);
      }
    }

    if (!foundUser) {
      return { success: false, error: 'Username, Email, atau NPSN tidak ditemukan.' };
    }

    // Validasi Password
    if (!password || !password.trim()) {
      return { success: false, error: 'Password wajib diisi.' };
    }

    // Cek kecocokan password jika akun memiliki password tersimpan
    if (foundUser.password && foundUser.password !== password) {
      return { success: false, error: 'Password yang Anda masukkan salah. Silakan periksa kembali.' };
    }

    if (foundUser.status === 'INACTIVE') {
      return { success: false, error: 'Akun ini sedang dinonaktifkan oleh administrator.' };
    }

    if (foundUser.status === 'PENDING') {
      const reg = this.getRegistrationSettings();
      return { 
        success: false, 
        error: reg.pesanPendingVerifikasi || 'Akun Anda sedang dalam proses verifikasi oleh tim CV Penyedia. Silakan tunggu konfirmasi persetujuan dari Super Admin.' 
      };
    }

    this.setCurrentUser(foundUser);
    this.logActivity(foundUser.id, foundUser.username, foundUser.role, `Pengguna berhasil login`);
    return { success: true, user: foundUser };
  }

  public registerLembaga(data: {
    namaLembaga: string;
    npsn: string;
    jenjang: Lembaga['jenjang'];
    statusLembaga: Lembaga['statusLembaga'];
    kepalaSekolah: string;
    nipKepalaSekolah?: string;
    operator: string;
    email: string;
    whatsapp: string;
    telepon: string;
    alamat: string;
    desa: string;
    kecamatan: string;
    kabupaten: string;
    provinsi: string;
    username: string;
    password?: string;
  }): { 
    success: boolean; 
    error?: string; 
    user?: User; 
    lembaga?: Lembaga; 
    isPending?: boolean; 
    pendingMessage?: string; 
  } {
    const regSettings = this.getRegistrationSettings();

    // 1. Cek status buka/tutup pendaftaran
    if (!regSettings.bukaRegistrasi) {
      return { 
        success: false, 
        error: regSettings.pesanRegistrasiTutup || 'Pendaftaran akun satuan pendidikan baru sedang ditutup sementara oleh CV Penyedia.' 
      };
    }

    // 2. Validasi jenjang yang diizinkan
    if (regSettings.jenjangDiizinkan && regSettings.jenjangDiizinkan.length > 0) {
      if (!regSettings.jenjangDiizinkan.includes(data.jenjang)) {
        return {
          success: false,
          error: `Pendaftaran untuk jenjang ${data.jenjang} saat ini tidak dibuka oleh CV Penyedia.`
        };
      }
    }

    // 3. Validasi status lembaga (Negeri/Swasta)
    if (regSettings.statusLembagaDiizinkan === 'NEGERI_SAJA' && data.statusLembaga !== 'Negeri') {
      return { success: false, error: 'Hanya satuan pendidikan Negeri yang dapat mendaftar saat ini.' };
    }
    if (regSettings.statusLembagaDiizinkan === 'SWASTA_SAJA' && data.statusLembaga !== 'Swasta') {
      return { success: false, error: 'Hanya satuan pendidikan Swasta yang dapat mendaftar saat ini.' };
    }

    // 4. Validasi 8 digit NPSN
    if (regSettings.wajibValidasiNpsn8Digit) {
      if (!/^\d{8}$/.test(data.npsn.trim())) {
        return { success: false, error: 'Format NPSN tidak valid. NPSN Indonesia terdiri dari 8 digit angka sesuai standar Dapodik.' };
      }
    }

    // 5. Validasi minimal panjang password
    if (data.password && data.password.length < (regSettings.minPanjangPassword || 6)) {
      return { success: false, error: `Password minimal terdiri dari ${regSettings.minPanjangPassword || 6} karakter.` };
    }

    // Validasi NPSN unik
    const existingNpsn = this.lembaga.find(l => l.npsn === data.npsn.trim());
    if (existingNpsn) {
      return { success: false, error: `NPSN ${data.npsn} telah terdaftar untuk ${existingNpsn.namaLembaga}. Satu NPSN hanya dapat digunakan oleh satu akun lembaga.` };
    }

    // Validasi username unik
    const existingUser = this.users.find(u => u.username.toLowerCase() === data.username.trim().toLowerCase());
    if (existingUser) {
      return { success: false, error: `Username "${data.username}" sudah digunakan. Silakan gunakan username lain.` };
    }

    const userId = `usr-lem-${Date.now()}`;
    const lembagaId = `lem-${Date.now()}`;
    const isAutoApprove = regSettings.autoApprove;
    const initialStatus: 'ACTIVE' | 'PENDING' = isAutoApprove ? 'ACTIVE' : 'PENDING';

    const newLembaga: Lembaga = {
      id: lembagaId,
      userId: userId,
      npsn: data.npsn.trim(),
      namaLembaga: data.namaLembaga.trim(),
      jenjang: data.jenjang,
      statusLembaga: data.statusLembaga,
      kepalaSekolah: data.kepalaSekolah.trim(),
      nipKepalaSekolah: data.nipKepalaSekolah?.trim() || '',
      operator: data.operator.trim(),
      email: data.email.trim(),
      whatsapp: data.whatsapp.trim(),
      telepon: data.telepon.trim(),
      alamat: data.alamat.trim(),
      desa: data.desa.trim(),
      kecamatan: data.kecamatan.trim(),
      kabupaten: data.kabupaten.trim(),
      provinsi: data.provinsi.trim(),
      createdAt: new Date().toISOString()
    };

    const newUser: User = {
      id: userId,
      username: data.username.trim(),
      email: data.email.trim(),
      password: data.password || 'password123',
      role: 'LEMBAGA',
      status: initialStatus,
      lembagaId: lembagaId,
      createdAt: new Date().toISOString()
    };

    this.lembaga.push(newLembaga);
    this.users.push(newUser);

    if (isAutoApprove) {
      this.setCurrentUser(newUser);
    }

    this.logActivity(
      userId, 
      newUser.username, 
      'LEMBAGA', 
      `Registrasi akun lembaga baru (${initialStatus}): ${newLembaga.namaLembaga} (NPSN: ${newLembaga.npsn})`, 
      newLembaga.npsn
    );
    this.persist();

    return { 
      success: true, 
      user: newUser, 
      lembaga: newLembaga,
      isPending: !isAutoApprove,
      pendingMessage: regSettings.pesanPendingVerifikasi
    };
  }

  public updateLembagaProfile(lembagaId: string, data: Partial<Lembaga>): { success: boolean; error?: string } {
    const index = this.lembaga.findIndex(l => l.id === lembagaId);
    if (index === -1) return { success: false, error: 'Data lembaga tidak ditemukan' };

    // Cek NPSN jika berubah
    if (data.npsn && data.npsn !== this.lembaga[index].npsn) {
      const dup = this.lembaga.find(l => l.npsn === data.npsn?.trim() && l.id !== lembagaId);
      if (dup) return { success: false, error: `NPSN ${data.npsn} sudah digunakan sekolah lain.` };
    }

    this.lembaga[index] = { ...this.lembaga[index], ...data };
    this.persist();
    if (this.currentUser) {
      this.logActivity(this.currentUser.id, this.currentUser.username, this.currentUser.role, `Memperbarui profil lembaga ${this.lembaga[index].namaLembaga}`);
    }
    return { success: true };
  }

  // --- CV & Profil ---
  public getCVProfile(): CVProfile {
    return this.cvProfile;
  }

  public updateCVProfile(data: Partial<CVProfile>) {
    this.cvProfile = { ...this.cvProfile, ...data };
    this.persist();
    if (this.currentUser) {
      this.logActivity(this.currentUser.id, this.currentUser.username, this.currentUser.role, 'Memperbarui profil informasi CV penyedia');
    }
  }

  // --- Master Buku ---
  public getAllBuku(): Buku[] {
    return [...this.buku];
  }

  public getActiveBuku(): Buku[] {
    return this.buku.filter(b => b.status === 'ACTIVE');
  }

  public saveBuku(bukuData: Omit<Buku, 'id'> & { id?: string }): { success: boolean; buku: Buku } {
    if (bukuData.id) {
      const idx = this.buku.findIndex(b => b.id === bukuData.id);
      if (idx !== -1) {
        this.buku[idx] = { ...this.buku[idx], ...bukuData, id: bukuData.id };
        this.persist();
        if (this.currentUser) {
          this.logActivity(this.currentUser.id, this.currentUser.username, this.currentUser.role, `Memperbarui data buku: ${this.buku[idx].judul}`);
        }
        return { success: true, buku: this.buku[idx] };
      }
    }
    const newBuku: Buku = {
      ...bukuData,
      id: `bk-${Date.now()}`
    };
    this.buku.unshift(newBuku);
    this.persist();
    if (this.currentUser) {
      this.logActivity(this.currentUser.id, this.currentUser.username, this.currentUser.role, `Menambahkan buku baru ke master: ${newBuku.judul}`);
    }
    return { success: true, buku: newBuku };
  }

  public toggleBukuStatus(bukuId: string) {
    const b = this.buku.find(item => item.id === bukuId);
    if (b) {
      b.status = b.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
      this.persist();
      if (this.currentUser) {
        this.logActivity(this.currentUser.id, this.currentUser.username, this.currentUser.role, `Mengubah status buku ${b.judul} menjadi ${b.status}`);
      }
    }
  }

  public importMasterBuku(
    bukuItems: (Omit<Buku, 'id'> & { id?: string })[],
    mode: 'APPEND' | 'OVERWRITE' = 'APPEND'
  ): { success: boolean; count: number; updatedCount: number; newCount: number; message: string } {
    let newCount = 0;
    let updatedCount = 0;

    if (mode === 'OVERWRITE') {
      this.buku = bukuItems.map((b, idx) => ({
        ...b,
        id: b.id || `bk-imp-${Date.now()}-${idx + 1}`
      }));
      newCount = this.buku.length;
    } else {
      const newBukuToAdd: Buku[] = [];
      for (const item of bukuItems) {
        // Cek apakah sudah ada buku dengan kode atau judul & kelas yang sama
        const cleanJudul = item.judul.trim().toLowerCase();
        const existing = this.buku.find(
          b => (item.kodeBuku && b.kodeBuku.toLowerCase() === item.kodeBuku.toLowerCase()) ||
               (b.judul.trim().toLowerCase() === cleanJudul && b.kelas === item.kelas)
        );

        if (existing) {
          // Update data yang sudah ada
          existing.hargaReferensi = item.hargaReferensi || existing.hargaReferensi;
          existing.status = 'ACTIVE';
          if (item.penulis && item.penulis !== 'Tim Penulis Kemdikbudristek') existing.penulis = item.penulis;
          if (item.penerbit && item.penerbit !== 'Pusat Perbukuan Kemdikbudristek') existing.penerbit = item.penerbit;
          if (item.kurikulum) existing.kurikulum = item.kurikulum;
          updatedCount++;
        } else {
          newBukuToAdd.push({
            ...item,
            id: item.id || `bk-imp-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
          });
          newCount++;
        }
      }
      this.buku = [...newBukuToAdd, ...this.buku];
    }

    this.persist();
    if (this.currentUser) {
      this.logActivity(
        this.currentUser.id,
        this.currentUser.username,
        this.currentUser.role,
        `Mengimpor ${bukuItems.length} data buku ke Master Katalog (Baru: ${newCount}, Diperbarui: ${updatedCount}, Mode: ${mode})`
      );
    }

    return {
      success: true,
      count: bukuItems.length,
      newCount,
      updatedCount,
      message: `Berhasil mengimpor data buku: ${newCount} buku baru ditambahkan, ${updatedCount} buku diperbarui.`
    };
  }

  // --- Data Lembaga (Untuk CV) ---
  public getAllLembaga(): Lembaga[] {
    return [...this.lembaga];
  }

  public getLembagaById(id: string): Lembaga | undefined {
    return this.lembaga.find(l => l.id === id);
  }

  // --- Pengajuan Buku ---
  public generateNomorPengajuan(year?: string): string {
    const yr = year || this.systemSettings.tahunAnggaranAktif || '2026';
    const prefixStr = this.systemSettings.prefixNomorPengajuan || 'PB';
    const prefix = `${prefixStr}-${yr}-`;
    const digits = this.systemSettings.digitNomorUrut || 4;
    const count = this.pengajuan.filter(p => p.nomorPengajuan.startsWith(prefix)).length + 1;
    return `${prefix}${String(count).padStart(digits, '0')}`;
  }

  public getAllPengajuan(filter?: RekapFilterOptions): Pengajuan[] {
    let result = [...this.pengajuan];

    if (filter) {
      if (filter.tahunAnggaran) {
        result = result.filter(p => p.tahunAnggaran === filter.tahunAnggaran);
      }
      if (filter.lembagaId) {
        result = result.filter(p => p.lembagaId === filter.lembagaId);
      }
      if (filter.status) {
        result = result.filter(p => p.status === filter.status);
      }
      if (filter.jenjang) {
        result = result.filter(p => {
          const lem = this.getLembagaById(p.lembagaId);
          return lem && lem.jenjang === filter.jenjang;
        });
      }
      if (filter.kecamatan) {
        result = result.filter(p => {
          const lem = this.getLembagaById(p.lembagaId);
          return lem && lem.kecamatan.toLowerCase().includes(filter.kecamatan!.toLowerCase());
        });
      }
      if (filter.searchQuery) {
        const q = filter.searchQuery.toLowerCase();
        result = result.filter(p => {
          const lem = this.getLembagaById(p.lembagaId);
          return (
            p.nomorPengajuan.toLowerCase().includes(q) ||
            (lem && lem.namaLembaga.toLowerCase().includes(q)) ||
            (lem && lem.npsn.includes(q)) ||
            p.items.some(it => it.judul.toLowerCase().includes(q) || it.isbn.includes(q))
          );
        });
      }
    }

    return result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public getPengajuanByLembaga(lembagaId: string): Pengajuan[] {
    return this.pengajuan
      .filter(p => p.lembagaId === lembagaId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public getPengajuanById(id: string): Pengajuan | undefined {
    return this.pengajuan.find(p => p.id === id);
  }

  public savePengajuan(
    data: {
      id?: string;
      lembagaId: string;
      tahunAnggaran: string;
      keteranganUmum?: string;
      items: PengajuanItem[];
      submitImmediately?: boolean;
    }
  ): { success: boolean; pengajuan: Pengajuan; error?: string } {
    if (!data.items || data.items.length === 0) {
      return { success: false, pengajuan: {} as Pengajuan, error: 'Minimal harus ada 1 buku dalam daftar pengajuan.' };
    }

    // Cek status periode pengajuan dibuka/ditutup oleh Super Admin
    if (data.submitImmediately && !this.systemSettings.periodePengajuanBuka) {
      return { 
        success: false, 
        pengajuan: {} as Pengajuan, 
        error: 'Periode pengajuan buku saat ini sedang DITUTUP oleh Super Admin CV. Pengajuan hanya dapat disimpan sebagai draf sementara.' 
      };
    }

    const calculatedItems = data.items.map(item => ({
      ...item,
      jumlah: Number(item.jumlah) || 1,
      hargaSatuan: Number(item.hargaSatuan) || 0,
      total: (Number(item.jumlah) || 1) * (Number(item.hargaSatuan) || 0)
    }));

    // Cek batas eksemplar per item
    const minQty = this.systemSettings.minEksemplarPerItem || 1;
    const maxQty = this.systemSettings.maxEksemplarPerItem || 1000;
    for (const it of calculatedItems) {
      if (it.jumlah < minQty) {
        return { success: false, pengajuan: {} as Pengajuan, error: `Jumlah eksemplar buku "${it.judul}" minimal ${minQty} eksemplar.` };
      }
      if (it.jumlah > maxQty) {
        return { success: false, pengajuan: {} as Pengajuan, error: `Jumlah eksemplar buku "${it.judul}" melebihi batas maksimum (${maxQty} eksemplar).` };
      }
    }

    const totalJenis = calculatedItems.length;
    const totalQty = calculatedItems.reduce((acc, curr) => acc + curr.jumlah, 0);
    const grandTotal = calculatedItems.reduce((acc, curr) => acc + curr.total, 0);

    const now = new Date().toISOString();
    const lembaga = this.getLembagaById(data.lembagaId);
    const lemName = lembaga ? lembaga.namaLembaga : 'Lembaga';

    if (data.id) {
      // Update pengajuan yang sudah ada (Draft atau Revisi)
      const idx = this.pengajuan.findIndex(p => p.id === data.id);
      if (idx === -1) return { success: false, pengajuan: {} as Pengajuan, error: 'Pengajuan tidak ditemukan' };

      const existing = this.pengajuan[idx];
      const newStatus: StatusPengajuan = data.submitImmediately ? 'DIKIRIM LEMBAGA' : existing.status;

      const newHistoryItem: PengajuanHistory = {
        id: `hist-${Date.now()}`,
        pengajuanId: existing.id,
        userId: this.currentUser?.id || 'usr',
        userName: this.currentUser?.username || 'Operator',
        userRole: 'LEMBAGA',
        statusSebelumnya: existing.status,
        statusBaru: newStatus,
        catatan: data.submitImmediately 
          ? (existing.status === 'PERLU REVISI' ? 'Lembaga telah memperbaiki pengajuan dan mengirimkan kembali ke CV.' : 'Pengajuan dikirim ke CV untuk diperiksa.')
          : 'Pengajuan disimpan sebagai draf.',
        createdAt: now
      };

      const updated: Pengajuan = {
        ...existing,
        tahunAnggaran: data.tahunAnggaran,
        keteranganUmum: data.keteranganUmum,
        items: calculatedItems,
        totalJenisBuku: totalJenis,
        totalBuku: totalQty,
        totalNilai: grandTotal,
        status: newStatus,
        updatedAt: now,
        history: [...existing.history, newHistoryItem]
      };

      this.pengajuan[idx] = updated;
      this.persist();

      this.logActivity(
        this.currentUser?.id || 'usr',
        this.currentUser?.username || 'Operator',
        'LEMBAGA',
        `Memperbarui pengajuan ${updated.nomorPengajuan} (${newStatus})`,
        updated.nomorPengajuan
      );

      return { success: true, pengajuan: updated };
    } else {
      // Buat pengajuan baru
      const nomor = this.generateNomorPengajuan(data.tahunAnggaran);
      const newId = `pg-${Date.now()}`;
      const status: StatusPengajuan = data.submitImmediately ? 'DIKIRIM LEMBAGA' : 'DRAFT';

      const history: PengajuanHistory[] = [
        {
          id: `hist-${Date.now()}`,
          pengajuanId: newId,
          userId: this.currentUser?.id || 'usr',
          userName: `${this.currentUser?.username} (${lemName})`,
          userRole: 'LEMBAGA',
          statusBaru: status,
          catatan: data.submitImmediately
            ? 'Pengajuan baru dibuat dan langsung dikirim ke CV.'
            : 'Pengajuan dibuat dan disimpan sebagai draf.',
          createdAt: now
        }
      ];

      const newPengajuan: Pengajuan = {
        id: newId,
        nomorPengajuan: nomor,
        lembagaId: data.lembagaId,
        tahunAnggaran: data.tahunAnggaran,
        tanggalPengajuan: now.split('T')[0],
        status,
        keteranganUmum: data.keteranganUmum || '',
        items: calculatedItems,
        totalJenisBuku: totalJenis,
        totalBuku: totalQty,
        totalNilai: grandTotal,
        history,
        createdAt: now,
        updatedAt: now
      };

      this.pengajuan.unshift(newPengajuan);
      this.persist();

      this.logActivity(
        this.currentUser?.id || 'usr',
        this.currentUser?.username || 'Operator',
        'LEMBAGA',
        `Membuat pengajuan baru ${nomor} untuk ${lemName} (${status})`,
        nomor
      );

      return { success: true, pengajuan: newPengajuan };
    }
  }

  public updatePengajuanStatusByCV(
    pengajuanId: string,
    statusBaru: StatusPengajuan,
    catatan: string
  ): { success: boolean; error?: string } {
    const idx = this.pengajuan.findIndex(p => p.id === pengajuanId);
    if (idx === -1) return { success: false, error: 'Pengajuan tidak ditemukan' };

    const p = this.pengajuan[idx];
    const prevStatus = p.status;
    const now = new Date().toISOString();

    const hist: PengajuanHistory = {
      id: `hist-${Date.now()}`,
      pengajuanId: p.id,
      userId: this.currentUser?.id || 'cv-admin',
      userName: this.currentUser?.username || 'Admin CV',
      userRole: 'CV',
      statusSebelumnya: prevStatus,
      statusBaru,
      catatan: catatan.trim(),
      createdAt: now
    };

    p.status = statusBaru;
    p.catatanCv = catatan.trim();
    p.updatedAt = now;
    p.history.push(hist);

    this.persist();

    this.logActivity(
      this.currentUser?.id || 'cv-admin',
      this.currentUser?.username || 'Admin CV',
      'CV',
      `Admin CV mengubah status pengajuan ${p.nomorPengajuan} dari ${prevStatus} menjadi ${statusBaru}`,
      p.nomorPengajuan
    );

    return { success: true };
  }

  // --- Audit Log ---
  public getAuditLogs(): AuditLog[] {
    return [...this.auditLogs].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public logActivity(userId: string, userName: string, userRole: 'LEMBAGA' | 'CV', aktivitas: string, referensiId?: string) {
    const log: AuditLog = {
      id: `aud-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      userId,
      userName,
      userRole,
      aktivitas,
      referensiId,
      createdAt: new Date().toISOString()
    };
    this.auditLogs.unshift(log);
    if (this.auditLogs.length > 200) {
      this.auditLogs.pop();
    }
    this.persist();
  }

  // --- Pengaturan Sistem (Super Admin CV) ---
  public getSystemSettings(): SystemSettings {
    const regSettings: RegistrationSettings = {
      ...INITIAL_REGISTRATION_SETTINGS,
      ...(this.systemSettings.registrationSettings || {}),
      fields: {
        ...INITIAL_REGISTRATION_SETTINGS.fields,
        ...(this.systemSettings.registrationSettings?.fields || {})
      }
    };

    return { 
      ...this.systemSettings,
      registrationSettings: regSettings
    };
  }

  public getRegistrationSettings(): RegistrationSettings {
    return this.getSystemSettings().registrationSettings || INITIAL_REGISTRATION_SETTINGS;
  }

  public updateRegistrationSettings(data: Partial<RegistrationSettings>): { success: boolean; settings: RegistrationSettings } {
    const current = this.getRegistrationSettings();
    const updated: RegistrationSettings = {
      ...current,
      ...data,
      fields: {
        ...current.fields,
        ...(data.fields || {})
      }
    };
    this.systemSettings.registrationSettings = updated;
    this.persist();
    if (this.currentUser) {
      this.logActivity(
        this.currentUser.id,
        this.currentUser.username,
        'CV',
        'Super Admin CV memperbarui Pengaturan Data Isian Formulir Registrasi'
      );
    }
    return { success: true, settings: updated };
  }

  public updateSystemSettings(data: Partial<SystemSettings>): { success: boolean; settings: SystemSettings } {
    this.systemSettings = { ...this.systemSettings, ...data };
    if (data.tahunAnggaranAktif) {
      this.cvProfile.tahunAnggaranAktif = data.tahunAnggaranAktif;
    }
    this.persist();
    if (this.currentUser) {
      this.logActivity(
        this.currentUser.id,
        this.currentUser.username,
        'CV',
        'Super Admin CV memperbarui Pengaturan Sistem ARKAS'
      );
    }
    return { success: true, settings: this.getSystemSettings() };
  }

  // --- Manajemen Pengguna (Super Admin CV) ---
  public getAllUsers(): User[] {
    return [...this.users];
  }

  public toggleUserStatus(userId: string): { success: boolean; user?: User } {
    const u = this.users.find(item => item.id === userId);
    if (!u) return { success: false };
    u.status = u.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    this.persist();
    if (this.currentUser) {
      this.logActivity(
        this.currentUser.id,
        this.currentUser.username,
        'CV',
        `Super Admin mengubah status pengguna ${u.username} menjadi ${u.status}`,
        u.id
      );
    }
    return { success: true, user: u };
  }

  public setUserStatus(userId: string, newStatus: 'ACTIVE' | 'INACTIVE' | 'PENDING'): { success: boolean; user?: User } {
    const u = this.users.find(item => item.id === userId);
    if (!u) return { success: false };
    const oldStatus = u.status;
    u.status = newStatus;
    this.persist();
    if (this.currentUser) {
      this.logActivity(
        this.currentUser.id,
        this.currentUser.username,
        'CV',
        `Super Admin memperbarui status akun ${u.username} dari ${oldStatus} menjadi ${newStatus}`,
        u.id
      );
    }
    return { success: true, user: u };
  }

  public resetUserPassword(userId: string, newPassword?: string): { success: boolean; message: string } {
    const u = this.users.find(item => item.id === userId);
    if (!u) return { success: false, message: 'Pengguna tidak ditemukan.' };
    
    const pwd = newPassword || 'arkas12345';
    this.persist();
    if (this.currentUser) {
      this.logActivity(
        this.currentUser.id,
        this.currentUser.username,
        'CV',
        `Super Admin mereset password akun ${u.username}`,
        u.id
      );
    }
    return { success: true, message: `Password akun "${u.username}" berhasil direset menjadi: ${pwd}` };
  }

  public addCVAdminUser(data: { username: string; email: string }): { success: boolean; user?: User; error?: string } {
    const dup = this.users.find(u => u.username.toLowerCase() === data.username.toLowerCase().trim());
    if (dup) return { success: false, error: 'Username sudah digunakan.' };

    const newUser: User = {
      id: `usr-cv-${Date.now()}`,
      username: data.username.trim(),
      email: data.email.trim(),
      role: 'CV',
      status: 'ACTIVE',
      createdAt: new Date().toISOString()
    };
    this.users.push(newUser);
    this.persist();
    if (this.currentUser) {
      this.logActivity(this.currentUser.id, this.currentUser.username, 'CV', `Super Admin menambahkan user admin CV baru: ${newUser.username}`);
    }
    return { success: true, user: newUser };
  }

  // --- Cadangkan & Pulihkan Database (Backup & Restore) ---
  public backupDatabase(): string {
    const backupObj = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      systemSettings: this.systemSettings,
      cvProfile: this.cvProfile,
      users: this.users,
      lembaga: this.lembaga,
      buku: this.buku,
      pengajuan: this.pengajuan,
      auditLogs: this.auditLogs
    };
    return JSON.stringify(backupObj, null, 2);
  }

  public restoreDatabase(jsonString: string): { success: boolean; error?: string } {
    try {
      const data = JSON.parse(jsonString);
      if (!data.users || !data.lembaga || !data.buku || !data.pengajuan) {
        return { success: false, error: 'Format file cadangan JSON tidak valid atau struktur tabel tidak sesuai.' };
      }
      this.users = data.users;
      this.lembaga = data.lembaga;
      if (data.cvProfile) this.cvProfile = data.cvProfile;
      if (data.systemSettings) this.systemSettings = data.systemSettings;
      this.buku = data.buku;
      this.pengajuan = data.pengajuan;
      if (data.auditLogs) this.auditLogs = data.auditLogs;
      this.persist();
      if (this.currentUser) {
        this.logActivity(this.currentUser.id, this.currentUser.username, 'CV', 'Super Admin memulihkan (restore) database dari file cadangan.');
      }
      return { success: true };
    } catch (e: any) {
      return { success: false, error: e.message || 'Gagal memproses file JSON cadangan.' };
    }
  }

  // Reset Data Demo
  public resetToDefaultDemo() {
    this.users = [...INITIAL_USERS];
    this.lembaga = [...INITIAL_LEMBAGA];
    this.cvProfile = { ...INITIAL_CV_PROFILE };
    this.systemSettings = { ...INITIAL_SYSTEM_SETTINGS };
    this.buku = [...INITIAL_BUKU];
    this.pengajuan = [...INITIAL_PENGAJUAN];
    this.auditLogs = [...INITIAL_AUDIT_LOGS];
    this.currentUser = this.users[0];
    this.persist();
  }
}

export const arkasStorage = new ArkasStorageService();

// Helper Rupiah & Formatter
export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function formatDateIndo(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    return new Intl.DateTimeFormat('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(d);
  } catch {
    return dateStr;
  }
}

export function formatDateTimeIndo(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    return new Intl.DateTimeFormat('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(d);
  } catch {
    return dateStr;
  }
}
