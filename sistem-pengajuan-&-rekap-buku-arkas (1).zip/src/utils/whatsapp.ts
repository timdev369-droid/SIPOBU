import { Pengajuan, Lembaga, CVProfile } from '../types/index.ts';
import { formatRupiah, formatDateIndo } from '../lib/storage.ts';

/**
 * Membersihkan format nomor telepon Indonesia menjadi format internasional WhatsApp (62xxxxxxxx)
 */
export function formatWhatsAppNumber(phone: string): string {
  if (!phone) return '';
  // Hapus semua karakter selain angka
  let cleaned = phone.replace(/[^0-9]/g, '');
  
  // Jika diawali '0', ganti dengan '62'
  if (cleaned.startsWith('0')) {
    cleaned = '62' + cleaned.slice(1);
  } else if (cleaned.startsWith('62')) {
    // Sudah benar
  } else if (cleaned.startsWith('8')) {
    cleaned = '62' + cleaned;
  }
  
  return cleaned;
}

/**
 * Menyusun pesan WhatsApp otomatis saat pengajuan/pemesanan buku baru dikirim ke CV Admin
 */
export function buildWhatsAppProposalMessage(
  pengajuan: Pengajuan,
  lembaga: Lembaga,
  cvProfile: CVProfile,
  customIntro?: string
): string {
  const cleanOperatorWa = formatWhatsAppNumber(lembaga.whatsapp || lembaga.telepon || '');
  const operatorWaLink = cleanOperatorWa ? `https://wa.me/${cleanOperatorWa}` : '-';

  // Ambil hingga 5 item buku pertama untuk ringkasan di WA
  const sampleItems = pengajuan.items.slice(0, 6).map((it, idx) => {
    return `${idx + 1}. *${it.judul}* (${it.kelas})\n   └ ${it.jumlah} eks @ ${formatRupiah(it.hargaSatuan)} = *${formatRupiah(it.total)}*`;
  });

  const moreItemsCount = pengajuan.items.length - 6;
  const itemsText = sampleItems.join('\n') + (moreItemsCount > 0 ? `\n   └ _...dan ${moreItemsCount} judul buku lainnya._` : '');

  const introText = customIntro?.trim() || `Yth. Tim Admin *${cvProfile.namaCv}*,\nTelah masuk pengajuan kebutuhan buku baru untuk perencanaan dan penganggaran ARKAS:`;

  return `📚 *NOTIFIKASI PENGAJUAN BUKU ARKAS MASUK*
────────────────────────
${introText}

🏫 *DATA LEMBAGA / SEKOLAH:*
• Nama: *${lembaga.namaLembaga}*
• NPSN: ${lembaga.npsn} (${lembaga.statusLembaga} - ${lembaga.jenjang})
• Wilayah: Kec. ${lembaga.kecamatan}, ${lembaga.kabupaten}
• Kepala Sekolah: ${lembaga.kepalaSekolah}
• Operator: ${lembaga.operator}
• Kontak WA Operator: ${lembaga.whatsapp} (${operatorWaLink})

📋 *RINCIAN PENGAJUAN:*
• No. Pengajuan: *${pengajuan.nomorPengajuan}*
• Tahun Anggaran: *TA ${pengajuan.tahunAnggaran}*
• Tanggal Pengajuan: ${formatDateIndo(pengajuan.tanggalPengajuan)}
• Status Berkas: *${pengajuan.status}*

📦 *VOLUME & ESTIMASI NILAI ARKAS:*
• Total Judul Buku: *${pengajuan.totalJenisBuku} Judul*
• Total Kebutuhan: *${pengajuan.totalBuku.toLocaleString('id-ID')} Eksemplar*
• Total Nilai Rencana: *${formatRupiah(pengajuan.totalNilai)}*

📖 *RINGKASAN ITEM BUKU:*
${itemsText}

📝 *Keterangan Sekolah:*
"${pengajuan.keteranganUmum || 'Tidak ada catatan tambahan.'}"

────────────────────────
📌 *Mohon untuk membuka aplikasi web SIPOBU untuk memeriksa dan memverifikasi pengajuan buku ini.*
_Pesan otomatis dikirim melalui SIPOBU._`;
}

/**
 * Menghasilkan link WhatsApp Web/App langsung
 */
export function getWhatsAppUrl(phone: string, message: string): string {
  const cleanPhone = formatWhatsAppNumber(phone);
  return `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(message)}`;
}

/**
 * Memicu pembukaan link WhatsApp di tab baru secara aman
 */
export function openWhatsAppDirect(phone: string, message: string): boolean {
  try {
    const url = getWhatsAppUrl(phone, message);
    const win = window.open(url, '_blank', 'noopener,noreferrer');
    if (win) {
      win.focus();
      return true;
    }
    return false;
  } catch (err) {
    console.error('Gagal membuka WhatsApp otomatis:', err);
    return false;
  }
}

/**
 * Menyusun pesan WhatsApp otomatis saat ada sekolah/lembaga baru yang mendaftar ke sistem
 */
export function buildWhatsAppNewRegistrationMessage(
  lembaga: Lembaga,
  cvProfile: CVProfile,
  isPending: boolean
): string {
  const cleanOperatorWa = formatWhatsAppNumber(lembaga.whatsapp || lembaga.telepon || '');
  const operatorWaLink = cleanOperatorWa ? `https://wa.me/${cleanOperatorWa}` : '-';

  return `🏫 *NOTIFIKASI REGISTRASI SEKOLAH BARU*
────────────────────────
Yth. Tim Administrator *${cvProfile.namaCv}*,
Terdapat pendaftaran akun satuan pendidikan baru di Sistem Perencanaan ARKAS:

📌 *IDENTITAS SATUAN PENDIDIKAN:*
• Nama Lembaga: *${lembaga.namaLembaga}*
• NPSN: *${lembaga.npsn}* (${lembaga.statusLembaga} - ${lembaga.jenjang})
• Wilayah: Kec. ${lembaga.kecamatan}, ${lembaga.kabupaten}, ${lembaga.provinsi}
• Alamat: ${lembaga.alamat || '-'}

👤 *PIMPINAN & OPERATOR:*
• Kepala Sekolah: *${lembaga.kepalaSekolah}* ${lembaga.nipKepalaSekolah ? `(NIP: ${lembaga.nipKepalaSekolah})` : ''}
• Operator ARKAS: *${lembaga.operator}*
• WhatsApp Operator: ${lembaga.whatsapp} (${operatorWaLink})
• Email Sekolah: ${lembaga.email}
• Telepon Kantor: ${lembaga.telepon || '-'}

⚡ *STATUS KREDENSIAL AKUN:*
• Status Akun: *${isPending ? '⏳ MENUNGGU VERIFIKASI / PERSETUJUAN CV' : '✅ AKTIF LANGSUNG (DAPAT LOGIN)'}*

────────────────────────
_Pesan otomatis registrasi akun baru Sistem Pengajuan Buku ARKAS._`;
}

/**
 * Menyusun pesan WhatsApp saat PO telah Disetujui atau Final (Selesai Rekap) untuk dikirim ke WA Admin CV
 */
export function buildWhatsAppApprovedPOMessage(
  pengajuan: Pengajuan,
  lembaga: Lembaga,
  cvProfile: CVProfile,
  fileName: string,
  catatan?: string
): string {
  const isFinal = pengajuan.status === 'SELESAI REKAP';
  const statusLabel = isFinal ? 'FINAL (SELESAI REKAP)' : 'DISETUJUI (RESMI)';

  return `📋 *BERKAS PURCHASE ORDER (PO) ${statusLabel}*
────────────────────────
Yth. Tim Pengadaan & Administrator *${cvProfile.namaCv}*,
Berikut berkas PO Pemesanan Buku Satuan Pendidikan yang telah berstatus *${statusLabel}*:

🏫 *IDENTITAS SATUAN PENDIDIKAN:*
• Nama Lembaga: *${lembaga.namaLembaga}*
• NPSN: *${lembaga.npsn}* (${lembaga.jenjang} - ${lembaga.statusLembaga})
• Wilayah: Kec. ${lembaga.kecamatan}, ${lembaga.kabupaten}
• Kepala Sekolah: *${lembaga.kepalaSekolah}*
• Operator: ${lembaga.operator} (${lembaga.whatsapp})

📋 *RINCIAN PURCHASE ORDER (PO):*
• No. PO / Pengajuan: *${pengajuan.nomorPengajuan}*
• Tahun Anggaran: *TA ${pengajuan.tahunAnggaran}*
• Tanggal Pengajuan: ${formatDateIndo(pengajuan.tanggalPengajuan)}
• Status Resmi: *✅ ${statusLabel}*

📦 *VOLUME & ESTIMASI BIAYA:*
• Total Judul Buku: *${pengajuan.totalJenisBuku} Judul*
• Total Kebutuhan: *${pengajuan.totalBuku.toLocaleString('id-ID')} Eksemplar*
• Total Nilai Rencana: *${formatRupiah(pengajuan.totalNilai)}*

📄 *BERKAS LAMPIRAN PO (PDF):*
• Nama File: *${fileName}*
• Catatan: "${catatan || pengajuan.catatanCv || 'Berkas telah disetujui sesuai rincian pemesanan buku.'}"

📌 _File PDF rincian PO telah dibuat/diunduh otomatis dari portal SIPOBU dan siap diproses untuk transaksi pemesanan SIPLah._
────────────────────────
_Pesan otomatis berkas PO SIPOBU._`;
}

/**
 * Mengirim berkas PDF ke WhatsApp menggunakan Web Share API (jika didukung) atau mengunduh PDF + membuka WhatsApp Web
 */
export async function shareOrSendWhatsAppWithPdf(
  file: File,
  phone: string,
  message: string,
  title: string = 'Purchase Order Buku SIPOBU'
): Promise<{ method: 'share' | 'whatsapp'; success: boolean }> {
  // Cek apakah browser mendukung Web Share API dengan File
  if (
    typeof navigator !== 'undefined' &&
    navigator.canShare &&
    navigator.canShare({ files: [file] })
  ) {
    try {
      await navigator.share({
        title,
        text: message,
        files: [file]
      });
      return { method: 'share', success: true };
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.warn('Web Share dibatalkan atau gagal, beralih ke WhatsApp link:', err);
      }
    }
  }

  // Fallback: buka link WhatsApp
  const opened = openWhatsAppDirect(phone, message);
  return { method: 'whatsapp', success: opened };
}
