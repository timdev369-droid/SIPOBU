import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Pengajuan, Lembaga, CVProfile } from '../types/index.ts';
import { formatRupiah, formatDateIndo } from '../lib/storage.ts';

export function getPengajuanPdfFileName(pengajuan: Pengajuan, lembaga: Lembaga): string {
  const safeNumber = pengajuan.nomorPengajuan.replace(/[^a-zA-Z0-9_-]/g, '_');
  return `PO_RESMI_${safeNumber}_${lembaga.npsn}.pdf`;
}

export function generatePengajuanPdfDoc(
  pengajuan: Pengajuan,
  lembaga: Lembaga,
  cvProfile: CVProfile
): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // Kop Header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text('REKAPITULASI PEMESANAN BUKU', pageWidth / 2, 16, { align: 'center' });
  doc.setFontSize(10.5);
  doc.text('SIPOBU - SISTEM INFORMASI PEMESANAN BUKU', pageWidth / 2, 22, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(60, 60, 60);
  doc.text(`CV Penyedia SIPLah: ${cvProfile.namaCv} | Alamat: ${cvProfile.alamat}`, pageWidth / 2, 28, { align: 'center' });
  doc.text(`Kontak: ${cvProfile.telepon} / WA: ${cvProfile.whatsapp} | Email: ${cvProfile.email}`, pageWidth / 2, 33, { align: 'center' });

  // Divider Line
  doc.setLineWidth(0.6);
  doc.setDrawColor(30, 41, 59);
  doc.line(14, 37, pageWidth - 14, 37);
  doc.setLineWidth(0.2);
  doc.line(14, 38, pageWidth - 14, 38);

  // Informasi Pengajuan & Lembaga (2 Kolom)
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);

  const startY = 44;
  const col1Left = 14;
  const col2Left = 110;

  // Kolom 1 (Data Lembaga)
  doc.setFont('helvetica', 'bold');
  doc.text('Nama Lembaga', col1Left, startY);
  doc.setFont('helvetica', 'normal');
  doc.text(`: ${lembaga.namaLembaga} (${lembaga.statusLembaga})`, col1Left + 28, startY);

  doc.setFont('helvetica', 'bold');
  doc.text('NPSN', col1Left, startY + 5);
  doc.setFont('helvetica', 'normal');
  doc.text(`: ${lembaga.npsn} / Jenjang: ${lembaga.jenjang}`, col1Left + 28, startY + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('Kecamatan', col1Left, startY + 10);
  doc.setFont('helvetica', 'normal');
  doc.text(`: ${lembaga.kecamatan}, ${lembaga.kabupaten}`, col1Left + 28, startY + 10);

  doc.setFont('helvetica', 'bold');
  doc.text('Kepala Sekolah', col1Left, startY + 15);
  doc.setFont('helvetica', 'normal');
  doc.text(`: ${lembaga.kepalaSekolah}`, col1Left + 28, startY + 15);

  // Kolom 2 (Data Pengajuan)
  doc.setFont('helvetica', 'bold');
  doc.text('Nomor Pengajuan', col2Left, startY);
  doc.setFont('helvetica', 'normal');
  doc.text(`: ${pengajuan.nomorPengajuan}`, col2Left + 30, startY);

  doc.setFont('helvetica', 'bold');
  doc.text('Tahun Anggaran', col2Left, startY + 5);
  doc.setFont('helvetica', 'normal');
  doc.text(`: ${pengajuan.tahunAnggaran}`, col2Left + 30, startY + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('Tanggal Pengajuan', col2Left, startY + 10);
  doc.setFont('helvetica', 'normal');
  doc.text(`: ${formatDateIndo(pengajuan.tanggalPengajuan)}`, col2Left + 30, startY + 10);

  doc.setFont('helvetica', 'bold');
  doc.text('Status Pengajuan', col2Left, startY + 15);
  doc.setFont('helvetica', 'normal');
  doc.text(`: ${pengajuan.status}`, col2Left + 30, startY + 15);

  // Tabel Daftar Buku
  const tableData = pengajuan.items.map((it, idx) => [
    idx + 1,
    `${it.judul}\n(${it.kurikulum} - ${it.kelas})`,
    it.isbn || '-',
    it.penerbit,
    `${it.jumlah} eks`,
    formatRupiah(it.hargaSatuan),
    formatRupiah(it.total)
  ]);

  autoTable(doc, {
    startY: startY + 22,
    head: [['No', 'Judul Buku & Spesifikasi', 'ISBN', 'Penerbit', 'Jumlah', 'Harga Satuan', 'Total Rencana']],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 64, 175], // Blue-800
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'center'
    },
    bodyStyles: {
      fontSize: 8,
      cellPadding: 2.5,
      textColor: [30, 30, 30]
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { cellWidth: 65 },
      2: { cellWidth: 26, fontSize: 7.5 },
      3: { cellWidth: 30 },
      4: { halign: 'center', cellWidth: 16 },
      5: { halign: 'right', cellWidth: 22 },
      6: { halign: 'right', cellWidth: 25, fontStyle: 'bold' }
    },
    margin: { left: 14, right: 14 }
  });

  const finalY = (doc as any).lastAutoTable?.finalY || 180;

  // Box Total Nilai Rencana
  doc.setFillColor(241, 245, 249); // slate-100
  doc.rect(14, finalY + 4, pageWidth - 28, 12, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.rect(14, finalY + 4, pageWidth - 28, 12, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(30, 41, 59);
  doc.text(`TOTAL KEBUTUHAN: ${pengajuan.totalJenisBuku} Judul (${pengajuan.totalBuku} Eksemplar)`, 18, finalY + 11.5);
  doc.text(`TOTAL NILAI RENCANA: ${formatRupiah(pengajuan.totalNilai)}`, pageWidth - 18, finalY + 11.5, { align: 'right' });

  // Catatan Dokumen Resmi
  const disclaimerY = finalY + 20;
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(
    'CATATAN: Dokumen ini merupakan rekapitulasi resmi pemesanan buku melalui SIPOBU - Portal Satuan Pendidikan & CV Penyedia SIPLah.',
    pageWidth / 2,
    disclaimerY,
    { align: 'center' }
  );

  // Lembar Tanda Tangan Administratif (2 Kolom)
  let sigY = disclaimerY + 12;
  if (sigY > 240) {
    doc.addPage();
    sigY = 25;
  }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(30, 41, 59);

  doc.text('Mengetahui / Memverifikasi,', pageWidth / 2, sigY, { align: 'center' });

  const sigCol1 = 40;
  const sigCol2 = pageWidth - 40;

  doc.setFont('helvetica', 'bold');
  doc.text('Pihak Lembaga / Sekolah', sigCol1, sigY + 8, { align: 'center' });
  doc.text('Pihak CV Penyedia SIPLah', sigCol2, sigY + 8, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.text(lembaga.namaLembaga, sigCol1, sigY + 13, { align: 'center' });
  doc.text(cvProfile.namaCv, sigCol2, sigY + 13, { align: 'center' });

  // Space for sign
  const lineY = sigY + 36;
  doc.text('( .................................................... )', sigCol1, lineY, { align: 'center' });
  doc.text('( .................................................... )', sigCol2, lineY, { align: 'center' });

  doc.setFont('helvetica', 'bold');
  doc.text(lembaga.kepalaSekolah, sigCol1, lineY + 5, { align: 'center' });
  doc.text(cvProfile.direktur, sigCol2, lineY + 5, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.text(`Kepala Sekolah (NIP: ${lembaga.nipKepalaSekolah || '-'})`, sigCol1, lineY + 9, { align: 'center' });
  doc.text('Pimpinan CV Penyedia SIPLah', sigCol2, lineY + 9, { align: 'center' });

  return doc;
}

/**
 * Ekspor / Unduh langsung berkas PDF PO Pengajuan
 */
export function exportPengajuanToPdf(
  pengajuan: Pengajuan,
  lembaga: Lembaga,
  cvProfile: CVProfile
): { doc: jsPDF; fileName: string } {
  const doc = generatePengajuanPdfDoc(pengajuan, lembaga, cvProfile);
  const fileName = getPengajuanPdfFileName(pengajuan, lembaga);
  doc.save(fileName);
  return { doc, fileName };
}

/**
 * Membuat Blob dan File objek PDF PO untuk pengiriman / lampiran otomatis WhatsApp
 */
export function getPengajuanPdfBlobAndFile(
  pengajuan: Pengajuan,
  lembaga: Lembaga,
  cvProfile: CVProfile
): {
  doc: jsPDF;
  blob: Blob;
  file: File;
  fileName: string;
  downloadPdf: () => void;
} {
  const doc = generatePengajuanPdfDoc(pengajuan, lembaga, cvProfile);
  const fileName = getPengajuanPdfFileName(pengajuan, lembaga);
  const blob = doc.output('blob');
  const file = new File([blob], fileName, { type: 'application/pdf' });
  return {
    doc,
    blob,
    file,
    fileName,
    downloadPdf: () => doc.save(fileName)
  };
}

export function exportRekapKeseluruhanToPdf(
  pengajuanList: Pengajuan[],
  lembagaList: Lembaga[],
  cvProfile: CVProfile,
  filterYear: string = '2026'
) {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text('REKAPITULASI KESELURUHAN PENGAJUAN BUKU ARKAS', pageWidth / 2, 14, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Penyedia: ${cvProfile.namaCv} | Tahun Anggaran: ${filterYear} | Tanggal Cetak: ${formatDateIndo(new Date().toISOString())}`, pageWidth / 2, 20, { align: 'center' });

  doc.setLineWidth(0.4);
  doc.line(14, 23, pageWidth - 14, 23);

  const tableData = pengajuanList.map((p, idx) => {
    const lem = lembagaList.find(l => l.id === p.lembagaId);
    return [
      idx + 1,
      lem ? lem.namaLembaga : '-',
      lem ? lem.npsn : '-',
      lem ? lem.jenjang : '-',
      lem ? lem.kecamatan : '-',
      p.nomorPengajuan,
      formatDateIndo(p.tanggalPengajuan),
      `${p.totalJenisBuku} Judul`,
      `${p.totalBuku} Eks`,
      formatRupiah(p.totalNilai),
      p.status
    ];
  });

  const grandTotalBuku = pengajuanList.reduce((a, b) => a + b.totalBuku, 0);
  const grandTotalNilai = pengajuanList.reduce((a, b) => a + b.totalNilai, 0);

  autoTable(doc, {
    startY: 26,
    head: [[
      'No',
      'Lembaga / Sekolah',
      'NPSN',
      'Jenjang',
      'Kecamatan',
      'Nomor Pengajuan',
      'Tanggal',
      'Jenis Buku',
      'Jumlah Buku',
      'Total Nilai Rencana',
      'Status'
    ]],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 58, 138],
      textColor: [255, 255, 255],
      fontSize: 8.5,
      halign: 'center'
    },
    bodyStyles: {
      fontSize: 8,
      cellPadding: 2
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { cellWidth: 50 },
      2: { halign: 'center', cellWidth: 20 },
      3: { halign: 'center', cellWidth: 16 },
      4: { cellWidth: 28 },
      5: { halign: 'center', cellWidth: 28, fontStyle: 'bold' },
      6: { halign: 'center', cellWidth: 26 },
      7: { halign: 'center', cellWidth: 20 },
      8: { halign: 'center', cellWidth: 22 },
      9: { halign: 'right', cellWidth: 32, fontStyle: 'bold' },
      10: { halign: 'center', cellWidth: 24 }
    },
    margin: { left: 14, right: 14 }
  });

  const finalY = (doc as any).lastAutoTable?.finalY || 160;

  // Box Total
  doc.setFillColor(241, 245, 249);
  doc.rect(14, finalY + 4, pageWidth - 28, 10, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(`TOTAL KESELURUHAN: ${pengajuanList.length} Pengajuan | ${grandTotalBuku} Eksemplar`, 18, finalY + 10.5);
  doc.text(`GRAND TOTAL NILAI RENCANA: ${formatRupiah(grandTotalNilai)}`, pageWidth - 18, finalY + 10.5, { align: 'right' });

  // Catatan Dokumen
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(
    'Catatan: Dokumen rekapitulasi resmi pemesanan buku melalui SIPOBU - Portal Satuan Pendidikan & CV Penyedia SIPLah.',
    pageWidth / 2,
    finalY + 18,
    { align: 'center' }
  );

  doc.save(`Rekapitulasi_SIPOBU_Semua_Lembaga_${filterYear}.pdf`);
}
