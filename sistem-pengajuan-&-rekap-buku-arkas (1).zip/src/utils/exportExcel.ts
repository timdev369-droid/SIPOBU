import * as XLSX from 'xlsx';
import { Pengajuan, Lembaga, CVProfile } from '../types/index.ts';

export function exportRekapToExcel(
  pengajuanList: Pengajuan[],
  lembagaList: Lembaga[],
  cvProfile: CVProfile,
  filterYear: string = '2026'
) {
  // 1. Data Sheet 1: Rekap Pengajuan / Pemesanan
  const sheet1Data: any[] = [];
  sheet1Data.push(['REKAPITULASI PEMESANAN BUKU SIPOBU']);
  sheet1Data.push([`CV Penyedia SIPLah: ${cvProfile.namaCv} | Tahun Anggaran: ${filterYear}`]);
  sheet1Data.push(['SIPOBU - Portal Satuan Pendidikan & CV Penyedia SIPLah']);
  sheet1Data.push([]); // blank row

  const sheet1Headers = [
    'No',
    'Tahun Anggaran',
    'Tanggal Pengajuan',
    'Nama Lembaga / Sekolah',
    'NPSN',
    'Jenjang',
    'Kecamatan',
    'Nomor Pengajuan',
    'Status Pengajuan',
    'Total Buku (Eks)',
    'Total Nilai Rencana (Rp)'
  ];
  sheet1Data.push(sheet1Headers);

  let grandTotalBuku = 0;
  let grandTotalNilai = 0;

  pengajuanList.forEach((p, idx) => {
    const lem = lembagaList.find(l => l.id === p.lembagaId);
    grandTotalBuku += p.totalBuku;
    grandTotalNilai += p.totalNilai;

    sheet1Data.push([
      idx + 1,
      p.tahunAnggaran,
      p.tanggalPengajuan,
      lem ? lem.namaLembaga : '-',
      lem ? lem.npsn : '-',
      lem ? lem.jenjang : '-',
      lem ? lem.kecamatan : '-',
      p.nomorPengajuan,
      p.status,
      p.totalBuku,
      p.totalNilai
    ]);
  });

  // Total Row Sheet 1
  sheet1Data.push([
    'TOTAL',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    grandTotalBuku,
    grandTotalNilai
  ]);

  // 2. Data Sheet 2: Detail Buku
  const sheet2Data: any[] = [];
  sheet2Data.push(['DETAIL ITEM KEBUTUHAN BUKU PERENCANAAN ARKAS']);
  sheet2Data.push([`CV Penyedia SIPLah: ${cvProfile.namaCv} | Tanggal Export: ${new Date().toLocaleDateString('id-ID')}`]);
  sheet2Data.push([]);

  const sheet2Headers = [
    'No',
    'Nomor Pengajuan',
    'Nama Lembaga',
    'NPSN',
    'Kode Buku',
    'ISBN',
    'Judul Buku',
    'Penerbit',
    'Jenjang',
    'Kelas',
    'Mata Pelajaran',
    'Kurikulum',
    'Jumlah (Eks)',
    'Harga Satuan (Rp)',
    'Total Rencana (Rp)',
    'Keterangan'
  ];
  sheet2Data.push(sheet2Headers);

  let rowCount = 1;
  pengajuanList.forEach(p => {
    const lem = lembagaList.find(l => l.id === p.lembagaId);
    p.items.forEach(item => {
      sheet2Data.push([
        rowCount++,
        p.nomorPengajuan,
        lem ? lem.namaLembaga : '-',
        lem ? lem.npsn : '-',
        item.kodeBuku,
        item.isbn,
        item.judul,
        item.penerbit,
        item.jenjang,
        item.kelas,
        item.mataPelajaran,
        item.kurikulum,
        item.jumlah,
        item.hargaSatuan,
        item.total,
        item.keterangan || '-'
      ]);
    });
  });

  // 3. Data Sheet 3: Rekap Per Lembaga
  const sheet3Data: any[] = [];
  sheet3Data.push(['REKAPITULASI KEBUTUHAN BUKU PER LEMBAGA / SEKOLAH']);
  sheet3Data.push([`CV Penyedia SIPLah: ${cvProfile.namaCv} | Wilayah Pengajuan ARKAS`]);
  sheet3Data.push([]);

  const sheet3Headers = [
    'No',
    'Nama Lembaga',
    'NPSN',
    'Jenjang',
    'Kecamatan',
    'Nama Kepala Sekolah',
    'Kontak Operator',
    'Jumlah Pengajuan',
    'Jumlah Jenis Buku',
    'Total Buku (Eks)',
    'Total Nilai Rencana (Rp)'
  ];
  sheet3Data.push(sheet3Headers);

  const lembagaGrouped = lembagaList.map((lem, idx) => {
    const lemPengajuan = pengajuanList.filter(p => p.lembagaId === lem.id);
    const countPengajuan = lemPengajuan.length;
    let totalJenis = 0;
    let totalBuku = 0;
    let totalNilai = 0;

    lemPengajuan.forEach(p => {
      totalJenis += p.totalJenisBuku;
      totalBuku += p.totalBuku;
      totalNilai += p.totalNilai;
    });

    return [
      idx + 1,
      lem.namaLembaga,
      lem.npsn,
      lem.jenjang,
      lem.kecamatan,
      lem.kepalaSekolah,
      `${lem.operator} (${lem.whatsapp})`,
      countPengajuan,
      totalJenis,
      totalBuku,
      totalNilai
    ];
  });

  sheet3Data.push(...lembagaGrouped);

  // Buat Worksheets
  const ws1 = XLSX.utils.aoa_to_sheet(sheet1Data);
  const ws2 = XLSX.utils.aoa_to_sheet(sheet2Data);
  const ws3 = XLSX.utils.aoa_to_sheet(sheet3Data);

  // Auto column widths
  const calcCols = (data: any[][]) => {
    return data[3] || data[4] ? Object.keys(data[3] || {}).map((_, colIdx) => {
      let maxLen = 12;
      data.forEach(row => {
        const val = row[colIdx];
        if (val) {
          const str = String(val);
          if (str.length > maxLen) maxLen = Math.min(str.length, 45);
        }
      });
      return { wch: maxLen + 2 };
    }) : [];
  };

  ws1['!cols'] = calcCols(sheet1Data);
  ws2['!cols'] = calcCols(sheet2Data);
  ws3['!cols'] = calcCols(sheet3Data);

  // Buat Workbook & Append
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws1, 'Rekap Pengajuan');
  XLSX.utils.book_append_sheet(wb, ws2, 'Detail Buku');
  XLSX.utils.book_append_sheet(wb, ws3, 'Rekap Per Lembaga');

  const todayStr = new Date().toISOString().split('T')[0];
  const fileName = `Rekap_Pengajuan_Buku_ARKAS_${filterYear}_${todayStr}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

export function exportSinglePengajuanToExcel(
  pengajuan: Pengajuan,
  lembaga: Lembaga,
  cvProfile: CVProfile
) {
  const data: any[] = [];
  data.push(['FORMULIR PENGAJUAN KEBUTUHAN BUKU ARKAS']);
  data.push([`Penyedia: ${cvProfile.namaCv}`]);
  data.push([]);
  data.push(['Nomor Pengajuan', pengajuan.nomorPengajuan]);
  data.push(['Tahun Anggaran', pengajuan.tahunAnggaran]);
  data.push(['Tanggal Pengajuan', pengajuan.tanggalPengajuan]);
  data.push(['Status', pengajuan.status]);
  data.push(['Nama Lembaga', lembaga.namaLembaga]);
  data.push(['NPSN', lembaga.npsn]);
  data.push(['Jenjang', lembaga.jenjang]);
  data.push(['Kecamatan', lembaga.kecamatan]);
  data.push(['Kepala Sekolah', lembaga.kepalaSekolah]);
  data.push(['Operator', lembaga.operator]);
  data.push(['Keterangan Umum', pengajuan.keteranganUmum || '-']);
  data.push([]);

  data.push([
    'No',
    'Kode Buku',
    'ISBN',
    'Judul Buku',
    'Penerbit',
    'Jenjang',
    'Kelas',
    'Mata Pelajaran',
    'Kurikulum',
    'Jumlah (Eks)',
    'Harga Satuan (Rp)',
    'Total (Rp)',
    'Keterangan'
  ]);

  pengajuan.items.forEach((item, idx) => {
    data.push([
      idx + 1,
      item.kodeBuku,
      item.isbn,
      item.judul,
      item.penerbit,
      item.jenjang,
      item.kelas,
      item.mataPelajaran,
      item.kurikulum,
      item.jumlah,
      item.hargaSatuan,
      item.total,
      item.keterangan || '-'
    ]);
  });

  data.push([
    'TOTAL',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    pengajuan.totalBuku,
    '',
    pengajuan.totalNilai,
    ''
  ]);

  data.push([]);
  data.push(['CATATAN: Dokumen ini merupakan rekapitulasi resmi pengajuan kebutuhan buku untuk perencanaan dan penganggaran ARKAS.']);

  const ws = XLSX.utils.aoa_to_sheet(data);
  ws['!cols'] = [
    { wch: 6 },
    { wch: 16 },
    { wch: 18 },
    { wch: 40 },
    { wch: 25 },
    { wch: 10 },
    { wch: 12 },
    { wch: 20 },
    { wch: 18 },
    { wch: 14 },
    { wch: 18 },
    { wch: 20 },
    { wch: 25 }
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Pengajuan Buku');
  XLSX.writeFile(wb, `Pengajuan_${pengajuan.nomorPengajuan}_${lembaga.npsn}.xlsx`);
}
