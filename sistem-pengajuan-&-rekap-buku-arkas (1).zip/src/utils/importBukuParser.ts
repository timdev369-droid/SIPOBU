import * as XLSX from 'xlsx';
import { Buku, JenjangPendidikan } from '../types/index.ts';

export interface ParsedBukuRow {
  no: number;
  judulBuku: string;
  keterangan: string;
  harga: number;
  dipesan: number;
  jumlah: number;
  
  // Hasil ekstraksi pintar
  jenjang: JenjangPendidikan;
  kelas: string;
  mataPelajaran: string;
  kurikulum: 'Kurikulum Merdeka' | 'Kurikulum 2013' | 'Lainnya';
  kodeBuku: string;
  isbn: string;
  penerbit: string;
  penulis: string;
  isValid: boolean;
  error?: string;
}

/**
 * Membersihkan format teks harga Rupiah menjadi angka murni
 * Contoh: "Rp 25.000", "25.000,00", "Rp25000", 25000
 */
export function parseCurrency(val: any): number {
  if (typeof val === 'number') return isNaN(val) ? 0 : Math.round(val);
  if (!val) return 0;

  const str = String(val).trim();
  // Hapus "Rp", spasi, dan titik ribuan
  let cleaned = str.replace(/rp/gi, '').replace(/\s+/g, '');
  
  // Jika format Indonesia "25.000,00" atau "25.000"
  if (cleaned.includes(',') && cleaned.includes('.')) {
    // 25.000,00 -> hapus titik, ganti koma dengan titik
    cleaned = cleaned.replace(/\./g, '').replace(/,/g, '.');
  } else if (cleaned.includes('.') && !cleaned.includes(',')) {
    // Jika 25.000 (titik ribuan biasa)
    const parts = cleaned.split('.');
    if (parts.length > 1 && parts[parts.length - 1].length === 3) {
      cleaned = cleaned.replace(/\./g, '');
    } else {
      // e.g. 25000.50
    }
  } else if (cleaned.includes(',') && !cleaned.includes('.')) {
    // e.g. 25000,00
    cleaned = cleaned.replace(/,/g, '.');
  }

  // Hapus semua non-angka kecuali titik desimal
  cleaned = cleaned.replace(/[^0-9.]/g, '');
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : Math.round(num);
}

/**
 * Parsing kuantitas/jumlah eksemplar
 */
export function parseQty(val: any): number {
  if (typeof val === 'number') return isNaN(val) ? 0 : Math.round(val);
  if (!val) return 0;
  const str = String(val).replace(/[^0-9]/g, '');
  const num = parseInt(str, 10);
  return isNaN(num) ? 0 : num;
}

/**
 * Mendeteksi Jenjang Pendidikan dari teks judul dan keterangan
 */
export function detectJenjang(title: string, desc: string, defaultJenjang: JenjangPendidikan = 'SD'): JenjangPendidikan {
  const combined = `${title} ${desc}`.toLowerCase();

  if (/\b(sd|sekolah dasar|mi|madrasah ibtidaiyah)\b/i.test(combined)) return 'SD';
  if (/\b(smp|sekolah menengah pertama|mts|madrasah tsanawiyah)\b/i.test(combined)) return 'SMP';
  if (/\b(smk|kejuruan|mak)\b/i.test(combined)) return 'SMK';
  if (/\b(sma|sekolah menengah atas|ma|madrasah aliyah)\b/i.test(combined)) return 'SMA';
  if (/\b(paud|pendidikan anak usia dini)\b/i.test(combined)) return 'PAUD';
  if (/\b(tk|taman kanak)\b/i.test(combined)) return 'TK';
  if (/\b(pkbm|paket a|paket b|paket c)\b/i.test(combined)) return 'PKBM';

  // Deteksi berdasarkan kelas
  if (/\b(kelas|kls)\s*(1|2|3|4|5|6|i|ii|iii|iv|v|vi)\b/i.test(combined)) return 'SD';
  if (/\b(kelas|kls)\s*(7|8|9|vii|viii|ix)\b/i.test(combined)) return 'SMP';
  if (/\b(kelas|kls)\s*(10|11|12|x|xi|xii)\b/i.test(combined)) return 'SMA';

  return defaultJenjang;
}

/**
 * Mendeteksi Kelas dari teks judul dan keterangan
 */
export function detectKelas(title: string, desc: string, jenjang: JenjangPendidikan = 'SD'): string {
  const combined = `${title} ${desc}`;

  // Angka biasa
  const matchNum = combined.match(/\b(?:kelas|kls|tingkat)\s*(\d{1,2})\b/i);
  if (matchNum && matchNum[1]) {
    const k = parseInt(matchNum[1], 10);
    if (k >= 1 && k <= 12) return `Kelas ${k}`;
  }

  // Romawi
  const romanMap: Record<string, string> = {
    'i': 'Kelas 1',
    'ii': 'Kelas 2',
    'iii': 'Kelas 3',
    'iv': 'Kelas 4',
    'v': 'Kelas 5',
    'vi': 'Kelas 6',
    'vii': 'Kelas 7',
    'viii': 'Kelas 8',
    'ix': 'Kelas 9',
    'x': 'Kelas 10',
    'xi': 'Kelas 11',
    'xii': 'Kelas 12'
  };

  const matchRoman = combined.match(/\b(?:kelas|kls)\s*(xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii|i)\b/i);
  if (matchRoman && matchRoman[1]) {
    const r = matchRoman[1].toLowerCase();
    if (romanMap[r]) return romanMap[r];
  }

  // Cek angka tunggal di akhir kata jika ada
  const singleNum = combined.match(/\b(1|2|3|4|5|6|7|8|9|10|11|12)\b/);
  if (singleNum && singleNum[1]) {
    return `Kelas ${singleNum[1]}`;
  }

  // Fallback berdasarkan jenjang
  if (jenjang === 'SMP') return 'Kelas 7';
  if (jenjang === 'SMA' || jenjang === 'SMK') return 'Kelas 10';
  if (jenjang === 'PAUD' || jenjang === 'TK') return 'Kelompok B';
  return 'Kelas 1';
}

/**
 * Mendeteksi Mata Pelajaran dari judul buku
 */
export function detectMataPelajaran(title: string): string {
  const t = title.toLowerCase();

  if (t.includes('matematika')) return 'Matematika';
  if (t.includes('bahasa indonesia')) return 'Bahasa Indonesia';
  if (t.includes('bahasa inggris') || t.includes('english')) return 'Bahasa Inggris';
  if (t.includes('ipas') || (t.includes('alam') && t.includes('sosial'))) return 'IPAS';
  if (t.includes('ipa') || t.includes('ilmu pengetahuan alam')) return 'IPA';
  if (t.includes('ips') || t.includes('ilmu pengetahuan sosial')) return 'IPS';
  if (t.includes('pancasila') || t.includes('ppkn')) return 'Pendidikan Pancasila';
  if (t.includes('agama islam') || t.includes('pai')) return 'Pendidikan Agama Islam';
  if (t.includes('agama kristen')) return 'Pendidikan Agama Kristen';
  if (t.includes('agama katolik')) return 'Pendidikan Agama Katolik';
  if (t.includes('agama hindu')) return 'Pendidikan Agama Hindu';
  if (t.includes('agama buddha')) return 'Pendidikan Agama Buddha';
  if (t.includes('pjok') || t.includes('jasmani') || t.includes('olahraga')) return 'PJOK';
  if (t.includes('seni rupa')) return 'Seni Rupa';
  if (t.includes('seni musik')) return 'Seni Musik';
  if (t.includes('seni tari')) return 'Seni Tari';
  if (t.includes('seni teater')) return 'Seni Teater';
  if (t.includes('seni budaya')) return 'Seni Budaya';
  if (t.includes('informatika') || t.includes('komputer')) return 'Informatika';
  if (t.includes('prakarya')) return 'Prakarya';
  if (t.includes('sejarah')) return 'Sejarah';
  if (t.includes('geografi')) return 'Geografi';
  if (t.includes('ekonomi')) return 'Ekonomi';
  if (t.includes('sosiologi')) return 'Sosiologi';
  if (t.includes('fisika')) return 'Fisika';
  if (t.includes('kimia')) return 'Kimia';
  if (t.includes('biologi')) return 'Biologi';

  // Fallback: Ambil kata pertama hingga ketiga yang relevan
  const words = title.split(' ').slice(0, 3).join(' ');
  return words || 'Buku Teks Utama';
}

/**
 * Mendeteksi Kurikulum
 */
export function detectKurikulum(title: string, desc: string): 'Kurikulum Merdeka' | 'Kurikulum 2013' | 'Lainnya' {
  const combined = `${title} ${desc}`.toLowerCase();
  if (combined.includes('merdeka') || combined.includes('km') || combined.includes('profil pelajar')) {
    return 'Kurikulum Merdeka';
  }
  if (combined.includes('2013') || combined.includes('k13') || combined.includes('k-13') || combined.includes('revisi 2018')) {
    return 'Kurikulum 2013';
  }
  return 'Kurikulum Merdeka';
}

/**
 * Parsing data matrix baris & kolom (baik dari file Excel/Sheet maupun hasil split teks)
 * Format yang didukung: NO | JUDUL BUKU | KETERANGAN | HARGA | DIPESAN | JUMLAH
 */
export function parseMasterBukuMatrix(
  rows: any[][],
  defaultJenjang: JenjangPendidikan = 'SD'
): ParsedBukuRow[] {
  if (!rows || rows.length === 0) return [];

  // 1. Cari baris header jika ada
  let headerRowIndex = -1;
  let colIndices = {
    no: 0,
    judul: 1,
    keterangan: 2,
    harga: 3,
    dipesan: 4,
    jumlah: 5
  };

  for (let r = 0; r < Math.min(rows.length, 10); r++) {
    const rowStr = rows[r].map(c => String(c || '').toLowerCase().trim());
    const hasJudul = rowStr.some(c => c.includes('judul') || c.includes('nama buku') || c.includes('buku'));
    const hasHarga = rowStr.some(c => c.includes('harga') || c.includes('het') || c.includes('satuan'));

    if (hasJudul || hasHarga) {
      headerRowIndex = r;
      // Map kolom berdasarkan nama header
      rowStr.forEach((col, idx) => {
        if (/^(no|nomor|no\.)$/i.test(col)) colIndices.no = idx;
        else if (col.includes('judul') || col.includes('nama buku')) colIndices.judul = idx;
        else if (col.includes('ket') || col.includes('deskripsi') || col.includes('kurikulum')) colIndices.keterangan = idx;
        else if (col.includes('harga') || col.includes('het') || col.includes('tarif')) colIndices.harga = idx;
        else if (col.includes('pesan') || col.includes('dipesan') || col.includes('qty') || col.includes('volume') || col.includes('eks')) colIndices.dipesan = idx;
        else if (col.includes('jumlah') || col.includes('total') || col.includes('subtotal') || col.includes('nilai')) colIndices.jumlah = idx;
      });
      break;
    }
  }

  const startRow = headerRowIndex !== -1 ? headerRowIndex + 1 : 0;
  const result: ParsedBukuRow[] = [];

  for (let r = startRow; r < rows.length; r++) {
    const row = rows[r];
    if (!row || row.length === 0) continue;

    // Ambil nilai setiap kolom
    const rawNo = row[colIndices.no];
    const rawJudul = row[colIndices.judul];
    const rawKet = row[colIndices.keterangan];
    const rawHarga = row[colIndices.harga];
    const rawDipesan = row[colIndices.dipesan];
    const rawJumlah = row[colIndices.jumlah];

    const judulStr = String(rawJudul || '').trim();
    if (!judulStr) continue;

    // Abaikan jika baris adalah rekap total
    if (/^(total|grand total|jumlah total)/i.test(judulStr)) continue;

    const noVal = parseInt(String(rawNo || '').replace(/[^0-9]/g, ''), 10) || (result.length + 1);
    const ketStr = String(rawKet || '').trim();
    const hargaVal = parseCurrency(rawHarga);
    const dipesanVal = parseQty(rawDipesan);
    let jumlahVal = parseCurrency(rawJumlah);
    if (!jumlahVal && hargaVal && dipesanVal) {
      jumlahVal = hargaVal * dipesanVal;
    }

    const jenjangDetected = detectJenjang(judulStr, ketStr, defaultJenjang);
    const kelasDetected = detectKelas(judulStr, ketStr, jenjangDetected);
    const mapelDetected = detectMataPelajaran(judulStr);
    const kurikulumDetected = detectKurikulum(judulStr, ketStr);

    const jenjangCode = jenjangDetected.toLowerCase();
    const kurikulumCode = kurikulumDetected === 'Kurikulum Merdeka' ? 'km' : 'k13';
    const randCode = Math.floor(100 + Math.random() * 900);
    const kodeBukuGenerated = `BK-${kurikulumCode.toUpperCase()}-${jenjangDetected}-${String(noVal).padStart(3, '0')}`;
    const isbnGenerated = `978-602-244-${randCode}-1`;

    const isValid = !!judulStr && hargaVal > 0;
    const errorMsg = !judulStr 
      ? 'Judul buku kosong' 
      : hargaVal <= 0 
      ? 'Harga belum ditentukan' 
      : undefined;

    result.push({
      no: noVal,
      judulBuku: judulStr,
      keterangan: ketStr || `${kurikulumDetected} - ${kelasDetected}`,
      harga: hargaVal,
      dipesan: dipesanVal,
      jumlah: jumlahVal,
      jenjang: jenjangDetected,
      kelas: kelasDetected,
      mataPelajaran: mapelDetected,
      kurikulum: kurikulumDetected,
      kodeBuku: kodeBukuGenerated,
      isbn: isbnGenerated,
      penerbit: 'Pusat Perbukuan Kemdikbudristek',
      penulis: 'Tim Penulis Kemdikbudristek',
      isValid,
      error: errorMsg
    });
  }

  return result;
}

/**
 * Parsing teks langsung yang di-copy-paste (Tab-separated TSV atau CSV)
 */
export function parseFromRawText(
  rawText: string,
  defaultJenjang: JenjangPendidikan = 'SD'
): ParsedBukuRow[] {
  if (!rawText.trim()) return [];

  const lines = rawText.split(/\r?\n/).filter(l => l.trim().length > 0);
  const matrix: any[][] = [];

  for (const line of lines) {
    let cells: string[] = [];
    if (line.includes('\t')) {
      // Tab separated (hasil copy paste Excel / Google Sheets)
      cells = line.split('\t');
    } else if (line.includes(';') && line.split(';').length >= 4) {
      cells = line.split(';');
    } else if (line.includes(',') && line.split(',').length >= 4) {
      cells = line.split(',');
    } else if (line.includes('|')) {
      cells = line.split('|').map(c => c.trim());
    } else {
      // Fallback split spasi lebih dari 2
      cells = line.split(/\s{2,}/);
    }
    matrix.push(cells.map(c => c.trim()));
  }

  return parseMasterBukuMatrix(matrix, defaultJenjang);
}

/**
 * Parsing dari File Excel ArrayBuffer menggunakan SheetJS
 */
export function parseFromExcelFile(
  fileBuffer: ArrayBuffer,
  defaultJenjang: JenjangPendidikan = 'SD'
): ParsedBukuRow[] {
  try {
    const workbook = XLSX.read(fileBuffer, { type: 'array' });
    const firstSheetName = workbook.SheetNames[0];
    if (!firstSheetName) return [];

    const worksheet = workbook.Sheets[firstSheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' }) as any[][];

    return parseMasterBukuMatrix(jsonData, defaultJenjang);
  } catch (err) {
    console.error('Gagal membaca file Excel:', err);
    throw new Error('Format file Excel tidak dapat dibaca. Pastikan file berformat .xlsx, .xls, atau .csv');
  }
}

/**
 * Mengonversi parsed rows menjadi objek Buku untuk disimpan ke storage
 */
export function convertParsedRowsToBuku(parsedRows: ParsedBukuRow[]): Buku[] {
  return parsedRows.map((r, idx) => ({
    id: `bk-imp-${Date.now()}-${idx + 1}`,
    kodeBuku: r.kodeBuku,
    isbn: r.isbn,
    judul: r.judulBuku,
    penulis: r.penulis,
    penerbit: r.penerbit,
    jenjang: r.jenjang,
    kelas: r.kelas,
    mataPelajaran: r.mataPelajaran,
    kurikulum: r.kurikulum,
    hargaReferensi: r.harga,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  }));
}

/**
 * Menghasilkan file Excel (.xlsx) contoh template impor
 */
export function downloadExcelTemplate() {
  const headers = ['NO', 'JUDUL BUKU', 'KETERANGAN', 'HARGA', 'DIPESAN', 'JUMLAH'];
  const sampleData = [
    [1, 'Matematika: Belajar Bersama Temanmu untuk SD Kelas 1', 'Kurikulum Merdeka - Buku Siswa', 21500, 60, 1290000],
    [2, 'Bahasa Indonesia: Aku Bisa! untuk SD Kelas 1', 'Kurikulum Merdeka - Buku Siswa', 23000, 60, 1380000],
    [3, 'Pendidikan Agama Islam dan Budi Pekerti untuk SD Kelas 1', 'Kurikulum Merdeka - Kemdikbud', 24500, 60, 1470000],
    [4, 'Pendidikan Pancasila untuk SD/MI Kelas 1', 'Kurikulum Merdeka - Buku Utama', 20000, 60, 1200000],
    [5, 'Bahasa Inggris: My Next Words Grade 1 - Siswa', 'Kurikulum Merdeka - Edisi Revisi', 18500, 60, 1110000],
    [6, 'Ilmu Pengetahuan Alam dan Sosial (IPAS) untuk SD Kelas 4', 'Kurikulum Merdeka - Buku Siswa', 27500, 55, 1512500],
    [7, 'Matematika untuk SD/MI Kelas 4 Volume 1', 'Kurikulum Merdeka - Gakkosho', 22000, 55, 1210000],
    [8, 'Pendidikan Jasmani, Olahraga, dan Kesehatan (PJOK) SD Kelas 4', 'Kurikulum Merdeka - Kemdikbud', 25000, 55, 1375000],
    [9, 'Seni Rupa untuk SD Kelas 4', 'Kurikulum Merdeka - Buku Utama', 19500, 55, 1072500],
    [10, 'Ilmu Pengetahuan Alam (IPA) untuk SMP Kelas 7', 'Kurikulum Merdeka - SMP/MTs', 31000, 120, 3720000]
  ];

  const ws = XLSX.utils.aoa_to_sheet([headers, ...sampleData]);
  
  // Format lebar kolom
  ws['!cols'] = [
    { wch: 6 },
    { wch: 55 },
    { wch: 32 },
    { wch: 14 },
    { wch: 12 },
    { wch: 16 }
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Template_Master_Buku');
  XLSX.writeFile(wb, 'Template_Import_Master_Buku_ARKAS.xlsx');
}

/**
 * Contoh teks Tab-Separated (TSV) untuk salin ke clipboard
 */
export function getSampleTsvText(): string {
  return `NO\tJUDUL BUKU\tKETERANGAN\tHARGA\tDIPESAN\tJUMLAH
1\tMatematika: Belajar Bersama Temanmu untuk SD Kelas 1\tKurikulum Merdeka - Buku Siswa\t21500\t60\t1290000
2\tBahasa Indonesia: Aku Bisa! untuk SD Kelas 1\tKurikulum Merdeka - Buku Siswa\t23000\t60\t1380000
3\tPendidikan Agama Islam dan Budi Pekerti untuk SD Kelas 1\tKurikulum Merdeka - Kemdikbud\t24500\t60\t1470000
4\tPendidikan Pancasila untuk SD/MI Kelas 1\tKurikulum Merdeka - Buku Utama\t20000\t60\t1200000
5\tBahasa Inggris: My Next Words Grade 1 - Siswa\tKurikulum Merdeka - Edisi Revisi\t18500\t60\t1110000
6\tIlmu Pengetahuan Alam dan Sosial (IPAS) untuk SD Kelas 4\tKurikulum Merdeka - Buku Siswa\t27500\t55\t1512500
7\tMatematika untuk SD/MI Kelas 4 Volume 1\tKurikulum Merdeka - Gakkosho\t22000\t55\t1210000
8\tPendidikan Jasmani, Olahraga, dan Kesehatan (PJOK) SD Kelas 4\tKurikulum Merdeka - Kemdikbud\t25000\t55\t1375000
9\tSeni Rupa untuk SD Kelas 4\tKurikulum Merdeka - Buku Utama\t19500\t55\t1072500
10\tIlmu Pengetahuan Alam (IPA) untuk SMP Kelas 7\tKurikulum Merdeka - SMP/MTs\t31000\t120\t3720000`;
}
