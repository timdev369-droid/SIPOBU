import React, { useState } from 'react';
import { 
  Lock, 
  User, 
  BookOpenCheck, 
  ArrowRight, 
  ShieldCheck, 
  AlertCircle,
  Eye,
  EyeOff,
  Building2,
  School,
  Sparkles,
  FileText,
  CheckCircle2,
  Phone,
  HelpCircle,
  UserCheck,
  X
} from 'lucide-react';
import { arkasStorage } from '../../lib/storage.ts';
import { User as UserType } from '../../types/index.ts';

interface Props {
  onSuccess: (user: UserType) => void;
  onOpenRegister: () => void;
}

export const AuthModal: React.FC<Props> = ({ onSuccess, onOpenRegister }) => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');
  const [showForgot, setShowForgot] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'CV' | 'LEMBAGA'>('LEMBAGA');

  const cvProfile = arkasStorage.getCVProfile();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!identifier.trim()) {
      setError(
        selectedRole === 'CV'
          ? 'Harap masukkan Username atau Email Super Admin.'
          : 'Harap masukkan NPSN atau Username Satuan Pendidikan.'
      );
      return;
    }

    if (!password.trim()) {
      setError('Kata sandi (password) wajib diisi.');
      return;
    }

    const res = arkasStorage.login(identifier, password);
    if (res.success && res.user) {
      onSuccess(res.user);
    } else {
      setError(res.error || 'Login gagal. Periksa kembali username/NPSN dan password Anda.');
    }
  };

  const handleSelectRole = (type: 'CV' | 'LEMBAGA') => {
    setError('');
    setSelectedRole(type);
    // Tidak mengisi otomatis username atau password, membiarkan pengguna mengisi sendiri
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Background Ambient Glow Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200/80 overflow-hidden my-auto grid grid-cols-1 lg:grid-cols-12 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Left Side: Brand Showcase & Value Proposition */}
        <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden">
          {/* Subtle geometric pattern overlay */}
          <div className="absolute inset-0 opacity-[0.04] bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
          
          <div className="relative z-10 space-y-6">
            {/* Top Badge */}
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-[11px] font-semibold tracking-wide border border-blue-400/30 backdrop-blur-xs">
                <Sparkles className="w-3.5 h-3.5 text-blue-300" />
                <span>Portal Resmi • SIPLah</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">T.A. 2026</span>
            </div>

            {/* Brand Logo & Headline */}
            <div>
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 text-white flex items-center justify-center mb-4 shadow-lg shadow-blue-500/30 ring-4 ring-white/10">
                <BookOpenCheck className="w-8 h-8" />
              </div>
              <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
                SIPOBU
              </h1>
              <p className="text-xs sm:text-sm font-semibold text-blue-200 mt-1">
                Sistem Informasi Pemesanan Buku
              </p>
              <div className="mt-2 text-[11px] text-slate-300 leading-relaxed font-light">
                Portal terintegrasi pengelolaan pemesanan buku resmi bagi Satuan Pendidikan dan CV Penyedia SIPLah.
              </div>
            </div>

            {/* Feature Highlights */}
            <div className="space-y-3 pt-2">
              <div className="flex items-start gap-3 bg-white/5 p-2.5 rounded-xl border border-white/10 backdrop-blur-xs">
                <div className="p-1.5 rounded-lg bg-blue-500/20 text-blue-300 shrink-0 mt-0.5">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">Katalog Kurikulum Lengkap</h4>
                  <p className="text-[11px] text-slate-300 leading-tight">
                    Kurikulum Merdeka & 2013 jenjang SD, SMP, SMA, SMK, PKBM.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white/5 p-2.5 rounded-xl border border-white/10 backdrop-blur-xs">
                <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">Ekspor Rekapitulasi Rapi</h4>
                  <p className="text-[11px] text-slate-300 leading-tight">
                    Dokumen cetak instan format PDF resmi dan spreadsheet Excel.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white/5 p-2.5 rounded-xl border border-white/10 backdrop-blur-xs">
                <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 shrink-0 mt-0.5">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">Verifikasi & Pengesahan</h4>
                  <p className="text-[11px] text-slate-300 leading-tight">
                    Persetujuan terpusat langsung oleh pimpinan CV Penyedia SIPLah.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Security Badge */}
          <div className="relative z-10 pt-6 mt-4 border-t border-white/10 flex items-center gap-2 text-[11px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Aman, akuntabel, dan sesuai standar perbukuan nasional.</span>
          </div>
        </div>

        {/* Right Side: Modern Login Form */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-10 flex flex-col justify-between">
          <div>
            {/* Header Form */}
            <div className="mb-6">
              <h2 className="text-2xl font-bold tracking-tight text-slate-900">
                Selamat Datang
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Silakan masuk dengan kredensial akun Anda untuk mengakses portal SIPOBU.
              </p>
            </div>

            {/* Pemilihan Peran Akun */}
            <div className="mb-5 p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-center justify-between text-[11px] font-semibold text-slate-600 mb-2">
                <span className="flex items-center gap-1.5">
                  <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                  <span>Pilih Peran Akun:</span>
                </span>
                <span className="text-[10px] text-slate-400 font-normal">
                  {selectedRole === 'CV' ? 'Mode Super Admin CV' : 'Mode Satuan Pendidikan'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleSelectRole('CV')}
                  className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                    selectedRole === 'CV'
                      ? 'bg-purple-600 text-white border-purple-600 shadow-xs ring-2 ring-purple-300'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5" />
                  <span>Super Admin CV</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectRole('LEMBAGA')}
                  className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                    selectedRole === 'LEMBAGA'
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs ring-2 ring-blue-300'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  <School className="w-3.5 h-3.5" />
                  <span>Satuan Pendidikan</span>
                </button>
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 flex items-start gap-2.5 text-xs animate-in fade-in duration-150">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
                <span className="leading-snug">{error}</span>
              </div>
            )}

            {/* Forgot Password Mode */}
            {showForgot ? (
              <div className="space-y-4 text-xs">
                <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-blue-950 space-y-2">
                  <h3 className="font-bold text-sm text-blue-900 flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-blue-600" />
                    <span>Layanan Pemulihan Akun SIPOBU</span>
                  </h3>
                  <p className="text-slate-600 leading-relaxed text-[11px]">
                    Untuk menjaga keabsahan data pemesanan buku sekolah, reset kredensial akun divalidasi langsung oleh tim pengelola CV Penyedia SIPLah dengan verifikasi NPSN dan identitas resmi sekolah.
                  </p>
                  
                  <div className="pt-2 border-t border-blue-200/60 space-y-1.5 text-[11px]">
                    <div className="font-semibold text-slate-800">Kontak Resmi Layanan Bantuan:</div>
                    <div className="flex items-center gap-2 text-slate-700">
                      <Phone className="w-3.5 h-3.5 text-emerald-600" />
                      <span>WhatsApp Layanan: <strong>{cvProfile.whatsapp || '0812-9876-5432'}</strong></span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-700">
                      <Building2 className="w-3.5 h-3.5 text-blue-600" />
                      <span>Penyedia: <strong>{cvProfile.namaCv}</strong></span>
                    </div>
                    <div className="text-slate-600 pl-5.5">
                      Email: {cvProfile.email || 'admin@superadmin'}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowForgot(false)}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl transition-colors text-xs"
                >
                  ← Kembali ke Halaman Login
                </button>
              </div>
            ) : (
              /* Standard Login Form */
              <form onSubmit={handleLogin} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1.5">
                    {selectedRole === 'CV' ? 'Username atau Email Super Admin' : 'NPSN Sekolah atau Username'} <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      placeholder={
                        selectedRole === 'CV'
                          ? 'Masukkan username atau email super admin'
                          : 'Masukkan 8 digit NPSN sekolah atau username'
                      }
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 placeholder:text-slate-400 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all font-medium"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="font-semibold text-slate-700">
                      Kata Sandi (Password) <span className="text-rose-500">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowForgot(true)}
                      className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 transition-colors cursor-pointer"
                    >
                      Lupa Password?
                    </button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="Masukkan password akun Anda"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 placeholder:text-slate-400 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all font-medium"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                      tabIndex={-1}
                      title={showPassword ? 'Sembunyikan password' : 'Lihat password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-slate-600 text-xs">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                    />
                    <span>Ingat kredensial saya di perangkat ini</span>
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-blue-500/25 text-xs transition-all flex items-center justify-center gap-2 cursor-pointer hover:shadow-indigo-500/35 active:scale-[0.99]"
                >
                  <span>Masuk ke Portal SIPOBU</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>

          {/* Bottom Register CTA */}
          <div className="pt-6 mt-6 border-t border-slate-100 text-center text-xs">
            <span className="text-slate-500">Satuan Pendidikan Anda belum terdaftar? </span>
            <button
              type="button"
              onClick={onOpenRegister}
              className="font-bold text-blue-600 hover:text-blue-800 transition-colors cursor-pointer inline-flex items-center gap-1"
            >
              <span>Daftarkan Satuan Pendidikan Baru</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
