import React, { useState } from 'react';
import { 
  X, 
  School, 
  Check, 
  AlertCircle, 
  ShieldCheck, 
  ArrowRight,
  Building2,
  Lock,
  User,
  Phone,
  Mail,
  MapPin,
  Send,
  CheckCircle2,
  Info,
  Clock,
  ExternalLink,
  MessageSquare
} from 'lucide-react';
import { JenjangPendidikan, StatusLembaga, User as UserType } from '../../types/index.ts';
import { arkasStorage } from '../../lib/storage.ts';
import { buildWhatsAppNewRegistrationMessage, openWhatsAppDirect } from '../../utils/whatsapp.ts';

interface Props {
  onClose: () => void;
  onSuccess: (user: UserType) => void;
  onSwitchToLogin: () => void;
}

export const RegisterModal: React.FC<Props> = ({
  onClose,
  onSuccess,
  onSwitchToLogin
}) => {
  const regSettings = arkasStorage.getRegistrationSettings();
  const cvProfile = arkasStorage.getCVProfile();

  // Filter jenjang yang diizinkan Super Admin (tanpa TK dan PAUD)
  const allowedJenjang = (regSettings.jenjangDiizinkan && regSettings.jenjangDiizinkan.length > 0
    ? regSettings.jenjangDiizinkan
    : (['SD', 'SMP', 'SMA', 'SMK', 'PKBM', 'Lainnya'] as JenjangPendidikan[])
  ).filter(j => j !== 'TK' && j !== 'PAUD');

  // Initial Jenjang
  const initialJenjang: JenjangPendidikan = 
    allowedJenjang.includes('SD') ? 'SD' : (allowedJenjang[0] || 'SD');

  // Initial Status Lembaga
  const initialStatusLembaga: StatusLembaga = 
    regSettings.statusLembagaDiizinkan === 'SWASTA_SAJA' ? 'Swasta' : 'Negeri';

  const [formData, setFormData] = useState({
    namaLembaga: '',
    npsn: '',
    jenjang: initialJenjang,
    statusLembaga: initialStatusLembaga,
    kepalaSekolah: '',
    nipKepalaSekolah: '',
    operator: '',
    email: '',
    whatsapp: '',
    telepon: '',
    alamat: '',
    desa: '',
    kecamatan: '',
    kabupaten: regSettings.defaultKabupaten || '',
    provinsi: regSettings.defaultProvinsi || 'Jawa Barat',
    username: '',
    password: ''
  });

  const [setujuPernyataan, setSetujuPernyataan] = useState(false);
  const [error, setError] = useState('');
  const [pendingSuccess, setPendingSuccess] = useState<{
    namaLembaga: string;
    npsn: string;
    pendingMessage: string;
    lembagaData: any;
  } | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validasi field pokok
    if (!formData.namaLembaga.trim()) {
      setError('Harap isi Nama Lembaga / Satuan Pendidikan.');
      return;
    }

    if (!formData.npsn.trim()) {
      setError('Harap isi NPSN sekolah.');
      return;
    }

    if (regSettings.wajibValidasiNpsn8Digit && !/^\d{8}$/.test(formData.npsn.trim())) {
      setError('Format NPSN tidak valid. NPSN Indonesia terdiri dari tepat 8 digit angka sesuai Dapodik.');
      return;
    }

    if (!formData.kepalaSekolah.trim()) {
      setError('Harap isi Nama Kepala Sekolah / Pimpinan Lembaga.');
      return;
    }

    // Validasi field dinamis berdasarkan konfigurasi Super Admin
    const f = regSettings.fields;

    if (f.nipKepalaSekolah.tampilkan && f.nipKepalaSekolah.wajib && !formData.nipKepalaSekolah.trim()) {
      setError(`Harap isi ${f.nipKepalaSekolah.label || 'NIP/NIK Kepala Sekolah'}.`);
      return;
    }

    if (f.namaOperator.tampilkan && f.namaOperator.wajib && !formData.operator.trim()) {
      setError(`Harap isi ${f.namaOperator.label || 'Nama Operator Sekolah'}.`);
      return;
    }

    if (f.whatsappOperator.tampilkan && f.whatsappOperator.wajib && !formData.whatsapp.trim()) {
      setError(`Harap isi ${f.whatsappOperator.label || 'Nomor WhatsApp Operator'}.`);
      return;
    }

    if (f.emailSekolah.tampilkan && f.emailSekolah.wajib && !formData.email.trim()) {
      setError(`Harap isi ${f.emailSekolah.label || 'Email Resmi Sekolah'}.`);
      return;
    }

    if (f.teleponKantor.tampilkan && f.teleponKantor.wajib && !formData.telepon.trim()) {
      setError(`Harap isi ${f.teleponKantor.label || 'Nomor Telepon Kantor'}.`);
      return;
    }

    if (f.alamatJalan.tampilkan && f.alamatJalan.wajib && !formData.alamat.trim()) {
      setError(`Harap isi ${f.alamatJalan.label || 'Alamat Jalan'}.`);
      return;
    }

    if (f.desa.tampilkan && f.desa.wajib && !formData.desa.trim()) {
      setError(`Harap isi ${f.desa.label || 'Desa/Kelurahan'}.`);
      return;
    }

    if (f.kecamatan.tampilkan && f.kecamatan.wajib && !formData.kecamatan.trim()) {
      setError(`Harap isi ${f.kecamatan.label || 'Kecamatan'}.`);
      return;
    }

    // Validasi Kredensial Login
    if (!formData.username.trim()) {
      setError('Harap tentukan Username baru untuk login.');
      return;
    }

    const minPwd = regSettings.minPanjangPassword || 6;
    if (!formData.password || formData.password.length < minPwd) {
      setError(`Password minimal terdiri dari ${minPwd} karakter demi keamanan akun.`);
      return;
    }

    // Validasi Pernyataan
    if (regSettings.wajibCentangPernyataan && !setujuPernyataan) {
      setError('Anda harus mencentang pernyataan keabsahan data sebelum mendaftarkan akun.');
      return;
    }

    // Lakukan Registrasi
    const res = arkasStorage.registerLembaga(formData);

    if (res.success && res.user && res.lembaga) {
      // Jika mode notifikasi WA admin aktif, tawarkan/buka kirim pesan WA ke admin
      if (regSettings.notifWaAdminRegistrasi && cvProfile.whatsapp) {
        try {
          const waMsg = buildWhatsAppNewRegistrationMessage(res.lembaga, cvProfile, !!res.isPending);
          openWhatsAppDirect(cvProfile.whatsapp, waMsg);
        } catch (e) {
          console.error('Gagal memicu WA:', e);
        }
      }

      if (res.isPending) {
        // Tampilkan layar pending
        setPendingSuccess({
          namaLembaga: res.lembaga.namaLembaga,
          npsn: res.lembaga.npsn,
          pendingMessage: res.pendingMessage || regSettings.pesanPendingVerifikasi,
          lembagaData: res.lembaga
        });
      } else {
        // Langsung aktif
        alert(`Registrasi Berhasil! Akun ${formData.namaLembaga} (NPSN: ${formData.npsn}) telah aktif dan siap digunakan.`);
        onSuccess(res.user);
      }
    } else {
      setError(res.error || 'Gagal melakukan registrasi.');
    }
  };

  // 1. Tampilan jika Pendaftaran Ditutup oleh Super Admin
  if (!regSettings.bukaRegistrasi) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
        <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 my-auto text-center space-y-5">
          <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto shadow-inner">
            <Lock className="w-8 h-8" />
          </div>

          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
              Pengumuman Super Admin
            </span>
            <h3 className="font-bold text-slate-900 text-lg mt-2">
              Pendaftaran Lembaga Ditutup Sementara
            </h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-200 text-left">
              {regSettings.pesanRegistrasiTutup || 'Pendaftaran akun satuan pendidikan baru saat ini sedang ditutup sementara oleh CV Penyedia SIPLah.'}
            </p>
          </div>

          <div className="bg-blue-50 p-3.5 rounded-xl border border-blue-200 text-left text-xs space-y-1">
            <span className="font-bold text-blue-900 block flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-blue-700" />
              <span>Kontak Layanan {cvProfile.namaCv}:</span>
            </span>
            <p className="text-slate-700">WhatsApp: <strong className="text-slate-900">{cvProfile.whatsapp || '-'}</strong></p>
            <p className="text-slate-700">Telepon: <strong className="text-slate-900">{cvProfile.telepon || '-'}</strong></p>
            <p className="text-slate-700">Email: <strong className="text-slate-900">{cvProfile.email || '-'}</strong></p>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
            <button
              onClick={onClose}
              className="w-full sm:w-1/2 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors"
            >
              Tutup
            </button>
            <button
              onClick={onSwitchToLogin}
              className="w-full sm:w-1/2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-1.5"
            >
              <span>Sudah Punya Akun? Masuk</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. Tampilan Sukses Menunggu Verifikasi Super Admin (Pending Mode)
  if (pendingSuccess) {
    const handleSendManualWa = () => {
      if (cvProfile.whatsapp && pendingSuccess.lembagaData) {
        const msg = buildWhatsAppNewRegistrationMessage(pendingSuccess.lembagaData, cvProfile, true);
        openWhatsAppDirect(cvProfile.whatsapp, msg);
      }
    };

    return (
      <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
        <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 my-auto text-center space-y-5">
          <div className="w-16 h-16 rounded-2xl bg-amber-500 text-white flex items-center justify-center mx-auto shadow-lg shadow-amber-500/30">
            <Clock className="w-8 h-8" />
          </div>

          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-700 text-xs font-bold border border-amber-200">
              <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
              <span>Registrasi Berhasil Terkirim</span>
            </div>
            <h3 className="font-bold text-slate-900 text-lg mt-2">
              Akun Menunggu Verifikasi Super Admin
            </h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Data satuan pendidikan <strong>{pendingSuccess.namaLembaga}</strong> (NPSN: {pendingSuccess.npsn}) telah tersimpan ke sistem. Sesuai kebijakan Super Admin, akun Anda memerlukan verifikasi sebelum dapat login.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-left space-y-2">
            <span className="font-bold text-slate-800 block">Petunjuk Verifikasi:</span>
            <p className="text-slate-600 leading-relaxed">
              {pendingSuccess.pendingMessage}
            </p>
            {cvProfile.whatsapp && (
              <p className="text-slate-600">
                Hubungi WhatsApp Admin CV: <strong className="text-emerald-700 font-mono">{cvProfile.whatsapp}</strong>
              </p>
            )}
          </div>

          <div className="space-y-2 pt-2">
            {cvProfile.whatsapp && (
              <button
                type="button"
                onClick={handleSendManualWa}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Kirim Notifikasi Pendaftaran ke WhatsApp Admin CV</span>
              </button>
            )}

            <button
              type="button"
              onClick={onSwitchToLogin}
              className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors"
            >
              Kembali ke Halaman Login
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 3. Tampilan Formulir Registrasi Standar
  const f = regSettings.fields;

  // Filter jenjang yang diizinkan Super Admin (tanpa TK dan PAUD)
  const jenjangOptions: JenjangPendidikan[] = allowedJenjang;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 my-auto">
        {/* Header Modal */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50/70 rounded-t-3xl">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-700 text-white flex items-center justify-center shadow-md">
              <School className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                Registrasi Akun Satuan Pendidikan
              </h3>
              <p className="text-xs text-slate-500">
                Portal Satuan Pendidikan & CV Penyedia SIPLah • SIPOBU
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
          {/* Petunjuk dari Super Admin */}
          {regSettings.petunjukRegistrasi && (
            <div className="p-3 rounded-xl bg-blue-50/80 border border-blue-200 text-blue-900 flex items-start gap-2 shadow-2xs">
              <Info className="w-4 h-4 shrink-0 mt-0.5 text-blue-600" />
              <div className="text-[11px] leading-relaxed">
                <strong className="block font-semibold">Petunjuk Pengisian Formulir:</strong>
                <span>{regSettings.petunjukRegistrasi}</span>
              </div>
            </div>
          )}

          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 flex items-start gap-2 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Section 1: Identitas Lembaga */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-1">
              <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider text-blue-800">
                1. Identitas Satuan Pendidikan
              </h4>
              <span className="text-[10px] text-slate-400">* Bidang Wajib</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">
                  Nama Lembaga / Sekolah *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: SD Negeri Mekarjaya 02"
                  value={formData.namaLembaga}
                  onChange={(e) => setFormData({ ...formData, namaLembaga: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  NPSN (Nomor Pokok Sekolah Nasional) *
                </label>
                <input
                  type="text"
                  required
                  maxLength={regSettings.wajibValidasiNpsn8Digit ? 8 : 12}
                  placeholder={regSettings.wajibValidasiNpsn8Digit ? "8 digit angka (Contoh: 20104501)" : "Nomor Pokok Sekolah Nasional"}
                  value={formData.npsn}
                  onChange={(e) => setFormData({ ...formData, npsn: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  {regSettings.wajibValidasiNpsn8Digit ? 'Wajib 8 digit angka unik sesuai Dapodik.' : 'NPSN harus unik dan belum terdaftar.'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenjang *</label>
                  <select
                    value={formData.jenjang}
                    onChange={(e) => setFormData({ ...formData, jenjang: e.target.value as any })}
                    className="w-full px-2.5 py-2 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500"
                  >
                    {jenjangOptions.map((j) => (
                      <option key={j} value={j}>{j}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Status *</label>
                  {regSettings.statusLembagaDiizinkan === 'SEMUA' ? (
                    <select
                      value={formData.statusLembaga}
                      onChange={(e) => setFormData({ ...formData, statusLembaga: e.target.value as any })}
                      className="w-full px-2.5 py-2 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Negeri">Negeri</option>
                      <option value="Swasta">Swasta</option>
                    </select>
                  ) : (
                    <input
                      type="text"
                      readOnly
                      disabled
                      value={regSettings.statusLembagaDiizinkan === 'NEGERI_SAJA' ? 'Negeri' : 'Swasta'}
                      className="w-full px-2.5 py-2 border border-slate-200 bg-slate-100 rounded-xl text-slate-700 font-semibold cursor-not-allowed"
                    />
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Pimpinan & Narahubung */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-slate-800 text-xs border-b border-slate-100 pb-1 uppercase tracking-wider text-blue-800">
              2. Kepala Sekolah & Operator ARKAS
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nama Kepala Sekolah / Pimpinan *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Nama Lengkap & Gelar Pimpinan"
                  value={formData.kepalaSekolah}
                  onChange={(e) => setFormData({ ...formData, kepalaSekolah: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              {/* Field NIP Kepala Sekolah */}
              {f.nipKepalaSekolah.tampilkan && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {f.nipKepalaSekolah.label || 'NIP / NIK Kepala Sekolah'} {f.nipKepalaSekolah.wajib ? '*' : '(Opsional)'}
                  </label>
                  <input
                    type="text"
                    required={f.nipKepalaSekolah.wajib}
                    placeholder="19xxxxxxxxxxxxxxxx / NIK"
                    value={formData.nipKepalaSekolah}
                    onChange={(e) => setFormData({ ...formData, nipKepalaSekolah: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono"
                  />
                  {f.nipKepalaSekolah.keterangan && (
                    <span className="text-[10px] text-slate-400 mt-0.5 block">{f.nipKepalaSekolah.keterangan}</span>
                  )}
                </div>
              )}

              {/* Field Nama Operator */}
              {f.namaOperator.tampilkan && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {f.namaOperator.label || 'Nama Operator Sekolah'} {f.namaOperator.wajib ? '*' : '(Opsional)'}
                  </label>
                  <input
                    type="text"
                    required={f.namaOperator.wajib}
                    placeholder="Nama Lengkap Staf Operator ARKAS"
                    value={formData.operator}
                    onChange={(e) => setFormData({ ...formData, operator: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
              )}

              {/* Field WhatsApp Operator */}
              {f.whatsappOperator.tampilkan && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {f.whatsappOperator.label || 'Nomor WhatsApp Operator'} {f.whatsappOperator.wajib ? '*' : '(Opsional)'}
                  </label>
                  <input
                    type="text"
                    required={f.whatsappOperator.wajib}
                    placeholder="08xxxxxxxxxx"
                    value={formData.whatsapp}
                    onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">Digunakan untuk notifikasi status pengajuan & verifikasi.</span>
                </div>
              )}

              {/* Field Email Sekolah */}
              {f.emailSekolah.tampilkan && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {f.emailSekolah.label || 'Email Resmi Sekolah'} {f.emailSekolah.wajib ? '*' : '(Opsional)'}
                  </label>
                  <input
                    type="email"
                    required={f.emailSekolah.wajib}
                    placeholder="sekolah@kemdikbud.id"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
              )}

              {/* Field Telepon Kantor */}
              {f.teleponKantor.tampilkan && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {f.teleponKantor.label || 'Nomor Telepon Kantor'} {f.teleponKantor.wajib ? '*' : '(Opsional)'}
                  </label>
                  <input
                    type="text"
                    required={f.teleponKantor.wajib}
                    placeholder="(021) xxxxxxxx"
                    value={formData.telepon}
                    onChange={(e) => setFormData({ ...formData, telepon: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Section 3: Alamat Domisili */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-slate-800 text-xs border-b border-slate-100 pb-1 uppercase tracking-wider text-blue-800">
              3. Alamat Domisili Satuan Pendidikan
            </h4>

            {f.alamatJalan.tampilkan && (
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {f.alamatJalan.label || 'Alamat Jalan & Nomor'} {f.alamatJalan.wajib ? '*' : '(Opsional)'}
                </label>
                <input
                  type="text"
                  required={f.alamatJalan.wajib}
                  placeholder="Jl. Raya Pendidikan No. 12"
                  value={formData.alamat}
                  onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {f.desa.tampilkan && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {f.desa.label || 'Desa/Kelurahan'} {f.desa.wajib ? '*' : ''}
                  </label>
                  <input
                    type="text"
                    required={f.desa.wajib}
                    placeholder="Desa"
                    value={formData.desa}
                    onChange={(e) => setFormData({ ...formData, desa: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg"
                  />
                </div>
              )}

              {f.kecamatan.tampilkan && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {f.kecamatan.label || 'Kecamatan'} {f.kecamatan.wajib ? '*' : ''}
                  </label>
                  <input
                    type="text"
                    required={f.kecamatan.wajib}
                    placeholder="Kecamatan"
                    value={formData.kecamatan}
                    onChange={(e) => setFormData({ ...formData, kecamatan: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg"
                  />
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1 flex items-center justify-between">
                  <span>Kab/Kota *</span>
                  {regSettings.kunciWilayahDefault && (
                    <span className="text-[9px] text-amber-700 font-normal flex items-center gap-0.5">
                      <Lock className="w-2.5 h-2.5" /> Binaan CV
                    </span>
                  )}
                </label>
                <input
                  type="text"
                  required
                  readOnly={regSettings.kunciWilayahDefault}
                  value={formData.kabupaten}
                  onChange={(e) => setFormData({ ...formData, kabupaten: e.target.value })}
                  className={`w-full px-2.5 py-1.5 border rounded-lg ${
                    regSettings.kunciWilayahDefault
                      ? 'border-amber-200 bg-amber-50/60 text-slate-700 font-medium'
                      : 'border-slate-300'
                  }`}
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1 flex items-center justify-between">
                  <span>Provinsi *</span>
                  {regSettings.kunciWilayahDefault && (
                    <span className="text-[9px] text-amber-700 font-normal flex items-center gap-0.5">
                      <Lock className="w-2.5 h-2.5" /> Binaan CV
                    </span>
                  )}
                </label>
                <input
                  type="text"
                  required
                  readOnly={regSettings.kunciWilayahDefault}
                  value={formData.provinsi}
                  onChange={(e) => setFormData({ ...formData, provinsi: e.target.value })}
                  className={`w-full px-2.5 py-1.5 border rounded-lg ${
                    regSettings.kunciWilayahDefault
                      ? 'border-amber-200 bg-amber-50/60 text-slate-700 font-medium'
                      : 'border-slate-300'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Section 4: Akun Login */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-slate-800 text-xs border-b border-slate-100 pb-1 uppercase tracking-wider text-blue-800">
              4. Kredensial Akses Akun
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Username Baru *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: sdn_mekarjaya02"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Password * (Min. {regSettings.minPanjangPassword || 6} Karakter)
                </label>
                <input
                  type="password"
                  required
                  placeholder={`Minimal ${regSettings.minPanjangPassword || 6} karakter`}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>
          </div>

          {/* Syarat & Pernyataan Integritas Data */}
          {regSettings.wajibCentangPernyataan && (
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <label className="flex items-start gap-2.5 cursor-pointer text-[11px] text-slate-700 select-none">
                <input
                  type="checkbox"
                  checked={setujuPernyataan}
                  onChange={(e) => setSetujuPernyataan(e.target.checked)}
                  className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500 mt-0.5 shrink-0"
                />
                <span className="leading-relaxed font-medium">
                  {regSettings.teksPernyataan || 'Saya menyatakan dengan sebenar-benarnya bahwa data satuan pendidikan di atas adalah valid dan merupakan perwakilan resmi untuk pemesanan buku melalui SIPOBU.'}
                </span>
              </label>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={onSwitchToLogin}
              className="text-xs font-semibold text-blue-600 hover:underline"
            >
              ← Sudah punya akun? Masuk di sini
            </button>

            <button
              type="submit"
              disabled={regSettings.wajibCentangPernyataan && !setujuPernyataan}
              className={`w-full sm:w-auto px-6 py-2.5 font-bold rounded-xl shadow-md text-xs transition-all flex items-center justify-center gap-2 ${
                regSettings.wajibCentangPernyataan && !setujuPernyataan
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-600/20'
              }`}
            >
              <span>{regSettings.autoApprove ? 'Daftarkan Lembaga & Masuk' : 'Kirim Pendaftaran Lembaga'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
