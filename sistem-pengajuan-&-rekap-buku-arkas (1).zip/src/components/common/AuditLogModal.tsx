import React, { useState } from 'react';
import { History, X, Search, Shield, User, Clock, ArrowRight } from 'lucide-react';
import { AuditLog } from '../../types/index.ts';
import { arkasStorage, formatDateTimeIndo } from '../../lib/storage.ts';

interface Props {
  onClose: () => void;
}

export const AuditLogModal: React.FC<Props> = ({ onClose }) => {
  const [logs] = useState<AuditLog[]>(arkasStorage.getAuditLogs());
  const [search, setSearch] = useState('');

  const filtered = logs.filter(l => 
    l.userName.toLowerCase().includes(search.toLowerCase()) ||
    l.aktivitas.toLowerCase().includes(search.toLowerCase()) ||
    (l.referensiId && l.referensiId.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 rounded-t-2xl">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                Riwayat Aktivitas & Log Audit Sistem
              </h3>
              <p className="text-[11px] text-slate-500">
                Pencatatan kronologis setiap aksi pengajuan, verifikasi, revisi, dan perubahan status ARKAS.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 border-b border-slate-100">
          <div className="relative text-xs">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Cari aktivitas, nama pengguna, atau nomor pengajuan..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 text-xs">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-slate-400">
              Tidak ada log aktivitas yang cocok.
            </div>
          ) : (
            filtered.map((log) => (
              <div key={log.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors flex items-start gap-3">
                <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                  log.userRole === 'CV' ? 'bg-purple-500' : 'bg-blue-500'
                }`} />
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-semibold text-slate-800">
                      {log.userName}
                      <span className={`ml-2 px-1.5 py-0.2 rounded text-[10px] font-bold ${
                        log.userRole === 'CV' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        {log.userRole}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDateTimeIndo(log.createdAt)}
                    </span>
                  </div>
                  <p className="text-slate-600 text-xs">{log.aktivitas}</p>
                  {log.referensiId && (
                    <span className="inline-block font-mono text-[10px] text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                      Ref: {log.referensiId}
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-4 border-t border-slate-200 bg-slate-50 rounded-b-2xl flex justify-end text-xs">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-lg"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
