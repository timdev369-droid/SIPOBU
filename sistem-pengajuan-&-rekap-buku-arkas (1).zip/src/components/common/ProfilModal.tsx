import React, { useState } from 'react';
import { X, Building2, School, Save, MapPin, Phone, Mail, User, ShieldCheck } from 'lucide-react';
import { Lembaga, CVProfile, UserRole } from '../../types/index.ts';
import { arkasStorage } from '../../lib/storage.ts';

interface Props {
  role: UserRole;
  lembaga: Lembaga | null;
  cvProfile: CVProfile;
  onClose: () => void;
  onProfileUpdated: () => void;
}

export const ProfilModal: React.FC<Props> = ({
  role,
  lembaga,
  cvProfile,
  onClose,
  onProfileUpdated
}) => {
  const [cvForm, setCvForm] = useState<CVProfile>({ ...cvProfile });
  const [lembagaForm, setLembagaForm] = useState<Lembaga | null>(
    lembaga ? { ...lembaga } : null
  );
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveCV = (e: React.FormEvent) => {
    e.preventDefault();
    arkasStorage.updateCVProfile(cvForm);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onProfileUpdated();
    }, 1500);
  };

  const handleSaveLembaga = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lembagaForm) return;
    const res = arkasStorage.updateLembagaProfile(lembagaForm.id, lembagaForm);
    if (res.success) {
      setSavedSuccess(true);
      setTimeout(() => {
        setSavedSuccess(false);
        onProfileUpdated();
      }, 1500);
    } else {
      alert(res.error || 'Gagal menyimpan profil');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 my-auto">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 rounded-t-3xl">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              {role === 'CV' ? <Building2 className="w-4 h-4" /> : <School className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                {role === 'CV' ? 'Profil Penyedia (CV)' : 'Profil Lembaga / Satuan Pendidikan'}
              </h3>
              <p className="text-xs text-slate-500">
                Informasi identitas resmi dan kontak administrasi penganggaran ARKAS
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
          {savedSuccess && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 font-bold text-center">
              ✓ Data profil berhasil diperbarui!
            </div>
          )}

          {role === 'CV' ? (
            <form onSubmit={handleSaveCV} className="space-y-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama CV Penyedia SIPLah</label>
                <input
                  type="text"
                  required
                  value={cvForm.namaCv}
                  onChange={(e) => setCvForm({ ...cvForm, namaCv: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Pimpinan / Direktur CV</label>
                  <input
                    type="text"
                    required
                    value={cvForm.direktur}
                    onChange={(e) => setCvForm({ ...cvForm, direktur: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tahun Anggaran Aktif</label>
                  <input
                    type="text"
                    required
                    value={cvForm.tahunAnggaranAktif}
                    onChange={(e) => setCvForm({ ...cvForm, tahunAnggaranAktif: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Alamat Kantor</label>
                <input
                  type="text"
                  required
                  value={cvForm.alamat}
                  onChange={(e) => setCvForm({ ...cvForm, alamat: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Telepon</label>
                  <input
                    type="text"
                    value={cvForm.telepon}
                    onChange={(e) => setCvForm({ ...cvForm, telepon: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">WhatsApp</label>
                  <input
                    type="text"
                    value={cvForm.whatsapp}
                    onChange={(e) => setCvForm({ ...cvForm, whatsapp: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={cvForm.email}
                    onChange={(e) => setCvForm({ ...cvForm, email: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Keterangan Profil</label>
                <textarea
                  rows={2}
                  value={cvForm.keterangan}
                  onChange={(e) => setCvForm({ ...cvForm, keterangan: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Tutup
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-xs"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>
          ) : lembagaForm ? (
            <form onSubmit={handleSaveLembaga} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Lembaga</label>
                  <input
                    type="text"
                    required
                    value={lembagaForm.namaLembaga}
                    onChange={(e) => setLembagaForm({ ...lembagaForm, namaLembaga: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">NPSN</label>
                  <input
                    type="text"
                    readOnly
                    value={lembagaForm.npsn}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono cursor-not-allowed text-slate-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kepala Sekolah</label>
                  <input
                    type="text"
                    required
                    value={lembagaForm.kepalaSekolah}
                    onChange={(e) => setLembagaForm({ ...lembagaForm, kepalaSekolah: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">NIP Kepala Sekolah</label>
                  <input
                    type="text"
                    value={lembagaForm.nipKepalaSekolah || ''}
                    onChange={(e) => setLembagaForm({ ...lembagaForm, nipKepalaSekolah: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Operator Sekolah</label>
                  <input
                    type="text"
                    required
                    value={lembagaForm.operator}
                    onChange={(e) => setLembagaForm({ ...lembagaForm, operator: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">WhatsApp Operator</label>
                  <input
                    type="text"
                    required
                    value={lembagaForm.whatsapp}
                    onChange={(e) => setLembagaForm({ ...lembagaForm, whatsapp: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Alamat Sekolah</label>
                <input
                  type="text"
                  required
                  value={lembagaForm.alamat}
                  onChange={(e) => setLembagaForm({ ...lembagaForm, alamat: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kecamatan</label>
                  <input
                    type="text"
                    required
                    value={lembagaForm.kecamatan}
                    onChange={(e) => setLembagaForm({ ...lembagaForm, kecamatan: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kabupaten/Kota</label>
                  <input
                    type="text"
                    required
                    value={lembagaForm.kabupaten}
                    onChange={(e) => setLembagaForm({ ...lembagaForm, kabupaten: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Provinsi</label>
                  <input
                    type="text"
                    required
                    value={lembagaForm.provinsi}
                    onChange={(e) => setLembagaForm({ ...lembagaForm, provinsi: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Tutup
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-xs"
                >
                  Simpan Perubahan Profil
                </button>
              </div>
            </form>
          ) : null}
        </div>
      </div>
    </div>
  );
};
