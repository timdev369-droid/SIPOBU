import React, { useState } from 'react';
import { ShieldCheck, Info, X } from 'lucide-react';

export const DisclaimerBanner: React.FC = () => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white px-4 py-2 text-xs border-b border-indigo-700/50 shadow-sm transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/40">
            <ShieldCheck className="w-3.5 h-3.5" />
          </span>
          <p className="leading-snug text-slate-200">
            <strong className="text-white font-semibold">SIPOBU:</strong> Sistem Informasi Pemesanan Buku — Portal Satuan Pendidikan & CV Penyedia SIPLah.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded bg-white/10 text-[11px] text-slate-300">
            <Info className="w-3 h-3 text-sky-400" /> SIPOBU
          </span>
          <button 
            onClick={() => setDismissed(true)} 
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/10 transition-colors"
            title="Sembunyikan pesan"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
