import React from 'react';
import { StatusPengajuan } from '../../types/index.ts';
import { 
  FileEdit, 
  Send, 
  Search, 
  AlertCircle, 
  CheckCircle2, 
  CheckCheck, 
  XCircle 
} from 'lucide-react';

interface Props {
  status: StatusPengajuan;
  size?: 'sm' | 'md' | 'lg';
}

export const StatusBadge: React.FC<Props> = ({ status, size = 'md' }) => {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-xs font-semibold px-2.5 py-1 gap-1.5',
    lg: 'text-sm font-semibold px-3 py-1.5 gap-2'
  };

  switch (status) {
    case 'DRAFT':
      return (
        <span className={`inline-flex items-center rounded-full bg-slate-100 text-slate-700 border border-slate-300 ${sizeClasses[size]}`}>
          <FileEdit className="w-3.5 h-3.5 text-slate-500" />
          <span>Draft</span>
        </span>
      );
    case 'DIKIRIM LEMBAGA':
      return (
        <span className={`inline-flex items-center rounded-full bg-blue-50 text-blue-700 border border-blue-200 ${sizeClasses[size]}`}>
          <Send className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
          <span>Menunggu CV</span>
        </span>
      );
    case 'DIPERIKSA CV':
      return (
        <span className={`inline-flex items-center rounded-full bg-amber-50 text-amber-800 border border-amber-300 ${sizeClasses[size]}`}>
          <Search className="w-3.5 h-3.5 text-amber-600" />
          <span>Diperiksa CV</span>
        </span>
      );
    case 'PERLU REVISI':
      return (
        <span className={`inline-flex items-center rounded-full bg-orange-100 text-orange-800 border border-orange-300 animate-bounce duration-1000 ${sizeClasses[size]}`}>
          <AlertCircle className="w-3.5 h-3.5 text-orange-600" />
          <span>Perlu Revisi</span>
        </span>
      );
    case 'DISETUJUI':
      return (
        <span className={`inline-flex items-center rounded-full bg-emerald-50 text-emerald-700 border border-emerald-300 ${sizeClasses[size]}`}>
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>Disetujui</span>
        </span>
      );
    case 'SELESAI REKAP':
      return (
        <span className={`inline-flex items-center rounded-full bg-indigo-50 text-indigo-700 border border-indigo-300 ${sizeClasses[size]}`}>
          <CheckCheck className="w-3.5 h-3.5 text-indigo-600" />
          <span>Selesai Rekap</span>
        </span>
      );
    case 'DITOLAK':
      return (
        <span className={`inline-flex items-center rounded-full bg-rose-50 text-rose-700 border border-rose-300 ${sizeClasses[size]}`}>
          <XCircle className="w-3.5 h-3.5 text-rose-600" />
          <span>Ditolak</span>
        </span>
      );
    default:
      return (
        <span className={`inline-flex items-center rounded-full bg-gray-100 text-gray-700 ${sizeClasses[size]}`}>
          {status}
        </span>
      );
  }
};
