import React from 'react';
import { 
  BookOpenCheck, 
  LogOut, 
  Bell, 
  History
} from 'lucide-react';
import { User, Lembaga, CVProfile } from '../../types/index.ts';
import { arkasStorage } from '../../lib/storage.ts';

interface Props {
  currentUser: User | null;
  currentLembaga: Lembaga | null;
  cvProfile: CVProfile;
  onOpenAuditLogs: () => void;
  onOpenProfile: () => void;
  onOpenNotifications: () => void;
  onLogout: () => void;
  onNavigateTab: (tab: string) => void;
}

export const Navbar: React.FC<Props> = ({
  currentUser,
  currentLembaga,
  cvProfile,
  onOpenAuditLogs,
  onOpenProfile,
  onOpenNotifications,
  onLogout,
  onNavigateTab
}) => {
  const allPengajuan = arkasStorage.getAllPengajuan();

  // Hitung notifikasi
  let notificationCount = 0;
  if (currentUser?.role === 'CV') {
    // Pengajuan yang perlu diperiksa
    notificationCount = allPengajuan.filter(p => p.status === 'DIKIRIM LEMBAGA').length;
  } else if (currentLembaga) {
    // Pengajuan yang perlu revisi
    notificationCount = allPengajuan.filter(p => p.lembagaId === currentLembaga.id && p.status === 'PERLU REVISI').length;
  }

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Logo & Brand */}
        <div 
          onClick={() => onNavigateTab('dashboard')} 
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-700 to-indigo-800 text-white flex items-center justify-center shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
            <BookOpenCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-slate-900 tracking-tight text-base sm:text-lg">
                SIPOBU
              </span>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold rounded-md bg-blue-50 text-blue-700 border border-blue-200 uppercase">
                Portal SIPLah
              </span>
            </div>
            <p className="text-[11px] text-slate-500 hidden md:block">
              Portal Satuan Pendidikan & CV Penyedia SIPLah
            </p>
          </div>
        </div>

        {/* Middle: Active User Status Badge */}
        <div className="hidden sm:flex items-center gap-2">
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-medium shadow-2xs ${
            currentUser?.role === 'CV' 
              ? 'bg-purple-50/70 border-purple-200 text-purple-900' 
              : 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
          }`}>
            <span className={`w-2 h-2 rounded-full animate-pulse ${
              currentUser?.role === 'CV' ? 'bg-purple-600' : 'bg-emerald-600'
            }`}></span>
            <span className="font-semibold">
              {currentUser?.role === 'CV' 
                ? 'Super Admin CV Penyedia SIPLah' 
                : currentLembaga?.namaLembaga || 'Satuan Pendidikan'}
            </span>
            {currentUser?.role === 'LEMBAGA' && currentLembaga?.npsn && (
              <span className="text-[10px] text-slate-500 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                NPSN: {currentLembaga.npsn}
              </span>
            )}
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Notification Button */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors"
            title="Notifikasi Pengajuan"
          >
            <Bell className="w-5 h-5" />
            {notificationCount > 0 && (
              <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white ring-2 ring-white">
                {notificationCount}
              </span>
            )}
          </button>

          {/* Audit Log Button */}
          <button
            onClick={onOpenAuditLogs}
            className="p-2 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors hidden sm:block"
            title="Riwayat Aktivitas & Audit Log"
          >
            <History className="w-5 h-5" />
          </button>

          {/* User Profile Info & Button */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-2 p-1.5 text-left rounded-lg hover:bg-slate-100 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-semibold text-xs border border-slate-300">
                {currentUser?.username?.slice(0, 2).toUpperCase() || 'US'}
              </div>
              <div className="hidden lg:block text-xs">
                <div className="font-semibold text-slate-800 leading-tight">
                  {currentUser?.role === 'CV' ? 'Admin CV Penyedia SIPLah' : currentLembaga?.namaLembaga || currentUser?.username}
                </div>
                <div className="text-[10px] text-slate-500">
                  {currentUser?.role === 'CV' ? cvProfile.direktur : `NPSN: ${currentLembaga?.npsn || '-'}`}
                </div>
              </div>
            </button>

            {/* Logout */}
            <button
              onClick={onLogout}
              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
