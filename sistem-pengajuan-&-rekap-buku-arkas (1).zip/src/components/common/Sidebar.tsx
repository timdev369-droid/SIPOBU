import React from 'react';
import { 
  LayoutDashboard, 
  Building2, 
  FileText, 
  PlusCircle, 
  History, 
  BarChart3, 
  FileSpreadsheet, 
  FileCheck, 
  Bell, 
  Settings, 
  LogOut, 
  Library, 
  Inbox, 
  AlertCircle, 
  CheckCircle2, 
  XCircle, 
  BookMarked, 
  School, 
  Activity, 
  ShieldCheck 
} from 'lucide-react';
import { UserRole } from '../../types/index.ts';

interface Props {
  role: UserRole;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onLogout: () => void;
  badgeCounts?: {
    masuk?: number;
    revisi?: number;
    disetujui?: number;
    ditolak?: number;
  };
}

export const Sidebar: React.FC<Props> = ({
  role,
  activeTab,
  onSelectTab,
  onLogout,
  badgeCounts = {}
}) => {
  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col shrink-0 min-h-[calc(100vh-4rem)] border-r border-slate-800">
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center justify-between gap-1 mb-1">
          <div className="text-[10px] font-extrabold text-blue-400 uppercase tracking-wider">
            SIPOBU
          </div>
          <span className="text-[9px] px-1.5 py-0.5 rounded font-bold bg-slate-800 text-slate-400 border border-slate-700">
            {role === 'CV' ? 'CV ADMIN' : 'LEMBAGA'}
          </span>
        </div>
        <div className="flex items-center gap-2 text-white font-semibold text-sm">
          {role === 'CV' ? (
            <>
              <Building2 className="w-4 h-4 text-blue-400" />
              <span>Portal CV Penyedia SIPLah</span>
            </>
          ) : (
            <>
              <School className="w-4 h-4 text-emerald-400" />
              <span>Portal Satuan Pendidikan</span>
            </>
          )}
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto text-xs">
        {role === 'LEMBAGA' ? (
          // Menu Role Lembaga (Requirement 21)
          <>
            <button
              onClick={() => onSelectTab('dashboard')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'dashboard' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Dashboard</span>
            </button>

            <button
              onClick={() => onSelectTab('profil-lembaga')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'profil-lembaga' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>Profil Lembaga</span>
            </button>

            <div className="pt-3 pb-1 px-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Pengajuan Kebutuhan
            </div>

            <button
              onClick={() => onSelectTab('pengajuan-buku')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'pengajuan-buku' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <FileText className="w-4 h-4" />
                <span>Pengajuan Buku</span>
              </div>
              {badgeCounts.revisi && badgeCounts.revisi > 0 ? (
                <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-orange-500 text-white font-bold animate-pulse">
                  {badgeCounts.revisi} Revisi
                </span>
              ) : null}
            </button>

            <button
              onClick={() => onSelectTab('pengajuan-baru')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'pengajuan-baru' ? 'bg-emerald-600 text-white shadow-xs' : 'hover:bg-slate-800 text-emerald-400 font-semibold'
              }`}
            >
              <PlusCircle className="w-4 h-4" />
              <span>+ Buat Pengajuan Baru</span>
            </button>

            <button
              onClick={() => onSelectTab('riwayat-pengajuan')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'riwayat-pengajuan' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Riwayat Pengajuan</span>
            </button>

            <div className="pt-3 pb-1 px-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Laporan & Output
            </div>

            <button
              onClick={() => onSelectTab('rekap')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'rekap' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Rekap Pengajuan</span>
            </button>

            <button
              onClick={() => onSelectTab('export-excel')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'export-excel' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>Export Excel</span>
            </button>

            <button
              onClick={() => onSelectTab('export-pdf')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'export-pdf' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <FileCheck className="w-4 h-4 text-rose-400" />
              <span>Export PDF Rekap</span>
            </button>

            <div className="pt-3 pb-1 px-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Sistem
            </div>

            <button
              onClick={() => onSelectTab('notifikasi')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'notifikasi' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <Bell className="w-4 h-4" />
                <span>Notifikasi</span>
              </div>
              {badgeCounts.revisi ? (
                <span className="w-2 h-2 rounded-full bg-rose-500"></span>
              ) : null}
            </button>

            <button
              onClick={() => onSelectTab('pengaturan-akun')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'pengaturan-akun' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Pengaturan Akun</span>
            </button>
          </>
        ) : (
          // Menu Role CV (Requirement 22)
          <>
            <button
              onClick={() => onSelectTab('dashboard')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'dashboard' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Dashboard CV</span>
            </button>

            <button
              onClick={() => onSelectTab('data-lembaga')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'data-lembaga' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <School className="w-4 h-4 text-sky-400" />
              <span>Data Lembaga / Sekolah</span>
            </button>

            <button
              onClick={() => onSelectTab('master-buku')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'master-buku' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Library className="w-4 h-4 text-amber-400" />
              <span>Master Katalog Buku</span>
            </button>

            <div className="pt-3 pb-1 px-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Verifikasi Pengajuan
            </div>

            <button
              onClick={() => onSelectTab('pengajuan-masuk')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'pengajuan-masuk' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <Inbox className="w-4 h-4 text-blue-400" />
                <span>Pengajuan Masuk</span>
              </div>
              {badgeCounts.masuk && badgeCounts.masuk > 0 ? (
                <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-blue-500 text-white font-bold">
                  {badgeCounts.masuk}
                </span>
              ) : null}
            </button>

            <button
              onClick={() => onSelectTab('perlu-revisi')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'perlu-revisi' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <AlertCircle className="w-4 h-4 text-orange-400" />
                <span>Perlu Revisi</span>
              </div>
              {badgeCounts.revisi && badgeCounts.revisi > 0 ? (
                <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-orange-500 text-white font-bold">
                  {badgeCounts.revisi}
                </span>
              ) : null}
            </button>

            <button
              onClick={() => onSelectTab('disetujui')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'disetujui' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Disetujui</span>
              </div>
              {badgeCounts.disetujui && badgeCounts.disetujui > 0 ? (
                <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-emerald-500 text-white font-bold">
                  {badgeCounts.disetujui}
                </span>
              ) : null}
            </button>

            <button
              onClick={() => onSelectTab('ditolak')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'ditolak' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <XCircle className="w-4 h-4 text-rose-400" />
                <span>Ditolak</span>
              </div>
              {badgeCounts.ditolak && badgeCounts.ditolak > 0 ? (
                <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-rose-500 text-white font-bold">
                  {badgeCounts.ditolak}
                </span>
              ) : null}
            </button>

            <div className="pt-3 pb-1 px-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Rekapitulasi ARKAS
            </div>

            <button
              onClick={() => onSelectTab('rekap-pengajuan')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'rekap-pengajuan' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-indigo-400" />
              <span>Rekap Pengajuan</span>
            </button>

            <button
              onClick={() => onSelectTab('rekap-buku')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'rekap-buku' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <BookMarked className="w-4 h-4 text-violet-400" />
              <span>Rekap Detail Buku</span>
            </button>

            <button
              onClick={() => onSelectTab('rekap-per-lembaga')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'rekap-per-lembaga' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Building2 className="w-4 h-4 text-sky-400" />
              <span>Rekap Per Lembaga</span>
            </button>

            <button
              onClick={() => onSelectTab('export-excel')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'export-excel' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>Export Excel (3 Sheets)</span>
            </button>

            <button
              onClick={() => onSelectTab('export-pdf')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'export-pdf' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <FileCheck className="w-4 h-4 text-rose-400" />
              <span>Export PDF Rekapitulasi</span>
            </button>

            <div className="pt-3 pb-1 px-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Administrasi & Audit
            </div>

            <button
              onClick={() => onSelectTab('riwayat-aktivitas')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'riwayat-aktivitas' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Activity className="w-4 h-4 text-teal-400" />
              <span>Riwayat Aktivitas (Log)</span>
            </button>

            <button
              onClick={() => onSelectTab('profil-cv')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'profil-cv' ? 'bg-blue-600 text-white shadow-xs' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>Profil CV Penyedia SIPLah</span>
            </button>

            <button
              onClick={() => onSelectTab('pengaturan')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium transition-colors ${
                activeTab === 'pengaturan' ? 'bg-amber-600 text-white shadow-xs font-semibold' : 'hover:bg-slate-800 text-amber-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <Settings className={`w-4 h-4 ${activeTab === 'pengaturan' ? 'text-white' : 'text-amber-400'}`} />
                <span>Pengaturan Super Admin</span>
              </div>
              <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold ${
                activeTab === 'pengaturan' ? 'bg-amber-800 text-amber-100' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              }`}>
                SUPER ADMIN
              </span>
            </button>
          </>
        )}
      </nav>

      {/* Footer Sidebar */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/60">
        <div className="flex items-center gap-2 text-[10px] text-slate-400 mb-2">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
          <span className="truncate">Portal Satuan Pendidikan & CV Penyedia SIPLah</span>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors text-xs font-medium"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Keluar (Logout)</span>
        </button>
      </div>
    </aside>
  );
};
