import React, { useState, useEffect } from 'react';
import { 
  X, 
  Send, 
  Download, 
  Share2, 
  CheckCircle2, 
  FileText, 
  PhoneCall, 
  Copy, 
  Check, 
  ExternalLink,
  Sparkles,
  Building2,
  School
} from 'lucide-react';
import { Pengajuan, Lembaga, CVProfile, SystemSettings } from '../../types/index.ts';
import { getPengajuanPdfBlobAndFile } from '../../utils/exportPdf.ts';
import { 
  buildWhatsAppApprovedPOMessage, 
  formatWhatsAppNumber, 
  getWhatsAppUrl, 
  openWhatsAppDirect,
  shareOrSendWhatsAppWithPdf 
} from '../../utils/whatsapp.ts';
import { formatRupiah } from '../../lib/storage.ts';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  pengajuan: Pengajuan;
  lembaga: Lembaga;
  cvProfile: CVProfile;
  systemSettings: SystemSettings;
  catatanReview?: string;
  autoTrigger?: boolean;
}

export const POFinalWhatsAppModal: React.FC<Props> = ({
  isOpen,
  onClose,
  pengajuan,
  lembaga,
  cvProfile,
  systemSettings,
  catatanReview,
  autoTrigger = true
}) => {
  const [copied, setCopied] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [shareSupported, setShareSupported] = useState(false);
  const [pdfFileObj, setPdfFileObj] = useState<File | null>(null);
  const [pdfFileName, setPdfFileName] = useState('');
  const [hasAutoFired, setHasAutoFired] = useState(false);

  const targetPhone = systemSettings.nomorWaAdmin || cvProfile.whatsapp || '0812-9876-5432';
  const cleanPhone = formatWhatsAppNumber(targetPhone);

  // Inisialisasi berkas PDF dan cek kapabilitas browser
  useEffect(() => {
    if (!isOpen) {
      setHasAutoFired(false);
      return;
    }

    try {
      const { file, fileName, downloadPdf } = getPengajuanPdfBlobAndFile(pengajuan, lembaga, cvProfile);
      setPdfFileObj(file);
      setPdfFileName(fileName);

      // Cek apakah browser mendukung Web Share API dengan lampiran file
      if (
        typeof navigator !== 'undefined' &&
        typeof navigator.canShare === 'function' &&
        navigator.canShare({ files: [file] })
      ) {
        setShareSupported(true);
      }

      // Auto unduh PDF dan auto buka WhatsApp jika autoTrigger aktif
      if (autoTrigger && !hasAutoFired) {
        setHasAutoFired(true);

        // 1. Unduh berkas PDF otomatis
        downloadPdf();
        setDownloaded(true);

        // 2. Buka WhatsApp Admin di tab baru setelah sedikit jeda agar unduhan berjalan mulus
        const messageText = buildWhatsAppApprovedPOMessage(
          pengajuan,
          lembaga,
          cvProfile,
          fileName,
          catatanReview
        );
        const timer = setTimeout(() => {
          openWhatsAppDirect(targetPhone, messageText);
        }, 700);

        return () => clearTimeout(timer);
      }
    } catch (err) {
      console.error('Gagal memproses berkas PDF PO otomatis:', err);
    }
  }, [isOpen, autoTrigger, hasAutoFired, pengajuan, lembaga, cvProfile, targetPhone, catatanReview]);

  if (!isOpen) return null;

  const messageText = buildWhatsAppApprovedPOMessage(
    pengajuan,
    lembaga,
    cvProfile,
    pdfFileName || `PO_${pengajuan.nomorPengajuan}.pdf`,
    catatanReview
  );

  const whatsappUrl = getWhatsAppUrl(targetPhone, messageText);

  const handleCopy = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadOnly = () => {
    try {
      const { downloadPdf } = getPengajuanPdfBlobAndFile(pengajuan, lembaga, cvProfile);
      downloadPdf();
      setDownloaded(true);
    } catch (err) {
      console.error('Gagal mengunduh berkas PDF:', err);
    }
  };

  const handleOpenWhatsApp = () => {
    openWhatsAppDirect(targetPhone, messageText);
  };

  const handleShareWithFile = async () => {
    if (!pdfFileObj) {
      handleOpenWhatsApp();
      return;
    }

    await shareOrSendWhatsAppWithPdf(
      pdfFileObj,
      targetPhone,
      messageText,
      `PO Resmi ${pengajuan.nomorPengajuan} - ${lembaga.namaLembaga}`
    );
  };

  const isFinal = pengajuan.status === 'SELESAI REKAP';

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-emerald-300 animate-in fade-in zoom-in-95 my-auto overflow-hidden">
        
        {/* Header Modal */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-emerald-600 via-teal-700 to-emerald-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center ring-2 ring-white/30 text-white shrink-0">
              <CheckCircle2 className="w-7 h-7 fill-white/20 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-white/25 text-white border border-white/20">
                  {isFinal ? 'PO FINAL SELESAI REKAP' : 'PO RESMI DISETUJUI'}
                </span>
                <span className="text-xs text-emerald-200 font-medium hidden sm:inline">
                  ● Otomatisasi PDF & WhatsApp
                </span>
              </div>
              <h3 className="font-bold text-base sm:text-lg text-white leading-tight mt-1">
                Kirim Berkas PDF PO ke WhatsApp Admin CV
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            title="Tutup Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-xs">
          {/* Status Box: Berkas PDF Otomatis Diunduh */}
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2.5">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-emerald-600 text-white shrink-0 mt-0.5 shadow-xs">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-emerald-950 text-sm flex items-center gap-2">
                    <span>Berkas PDF PO Resmi Telah Dibuat & Diunduh Otomatis!</span>
                    {downloaded && (
                      <span className="text-[10px] bg-emerald-200 text-emerald-900 font-semibold px-2 py-0.5 rounded-full">
                        Tersimpan di Perangkat
                      </span>
                    )}
                  </h4>
                  <p className="text-emerald-800 text-[11px] leading-relaxed mt-0.5">
                    Nama Berkas: <strong className="font-mono text-emerald-950">{pdfFileName || 'PO_Resmi.pdf'}</strong>
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleDownloadOnly}
                className="shrink-0 inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white border border-emerald-300 text-emerald-800 hover:bg-emerald-100 font-semibold text-xs shadow-2xs transition-colors"
                title="Unduh Ulang Berkas PDF"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh Ulang</span>
              </button>
            </div>

            <div className="pt-2 border-t border-emerald-200/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-emerald-900">
              <div className="flex items-center gap-1.5 font-medium">
                <PhoneCall className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Nomor WA Tujuan Admin CV:</span>
                <strong className="font-mono">{targetPhone}</strong>
                <span className="text-slate-400">({cleanPhone})</span>
              </div>
              <span className="text-[10px] bg-white px-2 py-0.5 rounded-md border border-emerald-200 text-slate-600 font-medium">
                {cvProfile.namaCv}
              </span>
            </div>
          </div>

          {/* Rincian Ringkas PO */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[10px] text-slate-500 block">No. PO</span>
              <strong className="text-xs font-mono text-blue-700 block truncate" title={pengajuan.nomorPengajuan}>
                {pengajuan.nomorPengajuan}
              </strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[10px] text-slate-500 block">Satuan Pendidikan</span>
              <strong className="text-xs text-slate-800 block truncate" title={lembaga.namaLembaga}>
                {lembaga.namaLembaga}
              </strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[10px] text-slate-500 block">Total Eksemplar</span>
              <strong className="text-xs text-slate-900 block">
                {pengajuan.totalBuku.toLocaleString('id-ID')} Eks
              </strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[10px] text-slate-500 block">Total Nilai Rencana</span>
              <strong className="text-xs text-emerald-700 block truncate">
                {formatRupiah(pengajuan.totalNilai)}
              </strong>
            </div>
          </div>

          {/* Preview Pesan WhatsApp */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <Send className="w-3.5 h-3.5 text-emerald-600" />
                <span>Pesan WhatsApp yang Dikirim ke Admin CV:</span>
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1 text-[11px] text-slate-600 hover:text-emerald-700 font-medium px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Tersalin!' : 'Salin Pesan'}</span>
              </button>
            </div>

            <div className="relative rounded-2xl bg-[#EFEAE2] p-3 sm:p-4 border border-slate-300 shadow-inner font-sans">
              <div className="bg-white rounded-2xl p-3 sm:p-4 shadow-xs border border-emerald-100 max-h-52 overflow-y-auto whitespace-pre-wrap text-[11px] text-slate-800 leading-relaxed font-mono">
                {messageText}
              </div>
              <div className="text-[10px] text-slate-500 text-right mt-1.5 flex items-center justify-end gap-1 font-sans">
                <Check className="w-3 h-3 text-emerald-600" />
                <span>Lampirkan file PDF yang sudah terunduh di chat WhatsApp</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Action Buttons */}
        <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50 rounded-b-3xl flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-200 font-semibold text-xs transition-colors order-3 sm:order-1"
          >
            Tutup
          </button>

          <div className="w-full sm:w-auto flex flex-wrap items-center gap-2 order-1 sm:order-2 justify-end">
            {shareSupported && (
              <button
                type="button"
                onClick={handleShareWithFile}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/20 transition-all"
                title="Kirim langsung berkas PDF melalui WhatsApp Web Share"
              >
                <Share2 className="w-4 h-4" />
                <span>Kirim Berkas PDF Langsung</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleOpenWhatsApp}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/25 transition-all"
            >
              <Send className="w-4 h-4" />
              <span>Buka WhatsApp Admin CV</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-80" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
