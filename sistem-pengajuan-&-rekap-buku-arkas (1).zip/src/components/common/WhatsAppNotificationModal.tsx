import React, { useState, useEffect } from 'react';
import { 
  X, 
  Send, 
  Copy, 
  Check, 
  ExternalLink, 
  MessageSquare, 
  Building2, 
  School, 
  CheckCircle2,
  Sparkles,
  PhoneCall
} from 'lucide-react';
import { Pengajuan, Lembaga, CVProfile, SystemSettings } from '../../types/index.ts';
import { 
  buildWhatsAppProposalMessage, 
  getWhatsAppUrl, 
  formatWhatsAppNumber 
} from '../../utils/whatsapp.ts';

interface Props {
  pengajuan: Pengajuan;
  lembaga: Lembaga;
  cvProfile: CVProfile;
  systemSettings: SystemSettings;
  isOpen: boolean;
  onClose: () => void;
  autoOpen?: boolean;
}

export const WhatsAppNotificationModal: React.FC<Props> = ({
  pengajuan,
  lembaga,
  cvProfile,
  systemSettings,
  isOpen,
  onClose,
  autoOpen = true
}) => {
  const [copied, setCopied] = useState(false);
  const [autoOpened, setAutoOpened] = useState(false);

  // Target WhatsApp number: prioritaskan dari systemSettings.nomorWaAdmin, fallback ke cvProfile.whatsapp
  const targetPhone = systemSettings.nomorWaAdmin || cvProfile.whatsapp || '0813-1122-3344';
  const cleanPhone = formatWhatsAppNumber(targetPhone);

  const messageText = buildWhatsAppProposalMessage(
    pengajuan,
    lembaga,
    cvProfile,
    systemSettings.templatePesanWaAdmin
  );

  const whatsappUrl = getWhatsAppUrl(targetPhone, messageText);

  // Auto trigger jika diizinkan browser
  useEffect(() => {
    if (isOpen && autoOpen && !autoOpened) {
      setAutoOpened(true);
      // Buka WA di tab baru
      const timer = setTimeout(() => {
        try {
          window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
        } catch (e) {
          console.log('Auto popup intercepted by browser:', e);
        }
      }, 600);
      return () => clearTimeout(timer);
    }
  }, [isOpen, autoOpen, autoOpened, whatsappUrl]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleOpenWhatsApp = () => {
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-emerald-200 animate-in fade-in zoom-in-95 my-auto">
        {/* Header Modal WhatsApp */}
        <div className="p-5 border-b border-emerald-100 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white rounded-t-3xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center ring-2 ring-white/30 text-white shrink-0">
              <MessageSquare className="w-6 h-6 fill-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/40 text-emerald-100 border border-white/20">
                  Notifikasi WA Otomatis
                </span>
                <span className="text-xs text-emerald-200 font-medium hidden sm:inline">● Terhubung</span>
              </div>
              <h3 className="font-bold text-base sm:text-lg text-white leading-tight mt-0.5">
                Pemberitahuan Pengajuan ke WA Admin CV
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            title="Tutup Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-xs">
          {/* Status Berhasil & Info Tujuan */}
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start gap-3.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="font-bold text-emerald-950 text-sm">
                Pengajuan Buku Berhasil Terkirim ke Sistem!
              </h4>
              <p className="text-emerald-800 leading-relaxed text-[11px]">
                Notifikasi rincian kebutuhan buku telah disiapkan untuk dikirim otomatis ke nomor WhatsApp resmi Admin{' '}
                <strong>{cvProfile.namaCv}</strong> di nomor:
              </p>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-emerald-300 shadow-2xs font-mono font-bold text-emerald-900 text-xs mt-1">
                <PhoneCall className="w-3.5 h-3.5 text-emerald-600" />
                <span>{targetPhone}</span>
                <span className="text-[10px] text-slate-400 font-normal">({cleanPhone})</span>
              </div>
            </div>
          </div>

          {/* Rincian Ringkas Pengajuan */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[10px] text-slate-500 block">Nomor Pengajuan</span>
              <strong className="text-xs font-mono text-blue-700 block truncate">{pengajuan.nomorPengajuan}</strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[10px] text-slate-500 block">Total Eksemplar</span>
              <strong className="text-xs text-slate-900 block">{pengajuan.totalBuku.toLocaleString('id-ID')} Eks</strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl col-span-2 sm:col-span-1">
              <span className="text-[10px] text-slate-500 block">Total Nilai Rencana</span>
              <strong className="text-xs text-emerald-700 block">{pengajuan.totalNilai ? `Rp ${pengajuan.totalNilai.toLocaleString('id-ID')}` : '-'}</strong>
            </div>
          </div>

          {/* Preview Bubble Pesan WhatsApp */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                <span>Tampilan Pesan WhatsApp (Otomatis Dikirim):</span>
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1 text-[11px] text-slate-600 hover:text-emerald-700 font-medium px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Tersalin ke Clipboard!' : 'Salin Pesan'}</span>
              </button>
            </div>

            <div className="relative rounded-2xl bg-[#EFEAE2] p-3 sm:p-4 border border-slate-300 shadow-inner font-sans">
              <div className="bg-white rounded-2xl p-3 sm:p-4 shadow-sm border border-emerald-100 max-h-56 overflow-y-auto whitespace-pre-wrap text-[11px] text-slate-800 leading-relaxed font-mono">
                {messageText}
              </div>
              <div className="text-[10px] text-slate-500 text-right mt-1.5 flex items-center justify-end gap-1 font-mono">
                <Check className="w-3 h-3 text-emerald-600" />
                <span>Format Resmi ARKAS Kemdikbud</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Action Buttons */}
        <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50 rounded-b-3xl flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-200 font-semibold text-xs transition-colors order-2 sm:order-1"
          >
            Selesai / Tutup
          </button>

          <div className="w-full sm:w-auto flex items-center gap-2 order-1 sm:order-2">
            <button
              type="button"
              onClick={handleCopy}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs shadow-2xs transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-500" />}
              <span>{copied ? 'Tersalin' : 'Salin Teks'}</span>
            </button>

            <button
              type="button"
              onClick={handleOpenWhatsApp}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/30 transition-all"
            >
              <Send className="w-4 h-4" />
              <span>Buka WhatsApp Admin CV</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-70" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
