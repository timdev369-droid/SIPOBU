import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  FileSpreadsheet, 
  Clipboard, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  Check, 
  Trash2, 
  Eye, 
  Sparkles,
  ArrowRight,
  BookOpen,
  Filter,
  FileCheck,
  Building2,
  ShoppingCart
} from 'lucide-react';
import { JenjangPendidikan, Lembaga } from '../../types/index.ts';
import { arkasStorage, formatRupiah } from '../../lib/storage.ts';
import { 
  ParsedBukuRow, 
  parseFromExcelFile, 
  parseFromRawText, 
  convertParsedRowsToBuku,
  downloadExcelTemplate,
  getSampleTsvText
} from '../../utils/importBukuParser.ts';

interface Props {
  onClose: () => void;
  onSuccess: () => void;
}

export const ImportMasterBukuModal: React.FC<Props> = ({
  onClose,
  onSuccess
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('paste');
  const [defaultJenjang, setDefaultJenjang] = useState<JenjangPendidikan>('SD');
  const [pasteText, setPasteText] = useState<string>('');
  const [parsedRows, setParsedRows] = useState<ParsedBukuRow[]>([]);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [importMode, setImportMode] = useState<'APPEND' | 'OVERWRITE'>('APPEND');
  
  // Opsi Tambahan: Sekaligus buatkan draf pengajuan pesanan buku
  const [buatDrafPengajuan, setBuatDrafPengajuan] = useState(false);
  const [selectedLembagaId, setSelectedLembagaId] = useState<string>('');
  const [lembagaList] = useState<Lembaga[]>(() => arkasStorage.getAllLembaga());

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string>('');
  const [isCopied, setIsCopied] = useState<boolean>(false);

  // Parse text on paste
  const handleParseText = (text: string, jenjang: JenjangPendidikan = defaultJenjang) => {
    setErrorMessage('');
    if (!text.trim()) {
      setParsedRows([]);
      return;
    }

    try {
      const rows = parseFromRawText(text, jenjang);
      if (rows.length === 0) {
        setErrorMessage('Tidak ditemukan baris data buku yang valid. Pastikan format kolom: NO | JUDUL BUKU | KETERANGAN | HARGA | DIPESAN | JUMLAH');
      }
      setParsedRows(rows);
    } catch (err: any) {
      setErrorMessage(err.message || 'Gagal memproses teks.');
    }
  };

  // Handle File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMessage('');
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const buffer = event.target?.result as ArrayBuffer;
        const rows = parseFromExcelFile(buffer, defaultJenjang);
        if (rows.length === 0) {
          setErrorMessage('File Excel terbaca namun tidak ada baris data buku yang cocok dengan kolom yang ditentukan.');
        }
        setParsedRows(rows);
      } catch (err: any) {
        setErrorMessage(err.message || 'Gagal membaca file spreadsheet.');
      }
    };

    reader.onerror = () => {
      setErrorMessage('Terjadi kesalahan saat membaca file.');
    };

    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  // Handle Load Sample Data
  const handleLoadSample = () => {
    const sample = getSampleTsvText();
    setPasteText(sample);
    setActiveTab('paste');
    handleParseText(sample, defaultJenjang);
  };

  // Handle Copy Sample to Clipboard
  const handleCopySample = () => {
    navigator.clipboard.writeText(getSampleTsvText());
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  // Hitung ringkasan
  const totalBuku = parsedRows.length;
  const validBuku = parsedRows.filter(r => r.isValid).length;
  const totalDipesan = parsedRows.reduce((acc, r) => acc + (r.dipesan || 0), 0);
  const totalNilai = parsedRows.reduce((acc, r) => acc + (r.jumlah || (r.harga * r.dipesan)), 0);

  // Submit Handler
  const handleExecuteImport = () => {
    if (parsedRows.length === 0) {
      alert('Belum ada data buku yang siap diimpor.');
      return;
    }

    const validRows = parsedRows.filter(r => r.isValid);
    if (validRows.length === 0) {
      alert('Tidak ada baris buku yang valid untuk diimpor. Periksa kolom judul dan harga.');
      return;
    }

    if (importMode === 'OVERWRITE') {
      if (!confirm('PERINGATAN: Mode Timpa Seluruh Master Buku (Overwrite) akan menghapus seluruh data buku yang ada sebelumnya dan menggantinya dengan data baru ini. Lanjutkan?')) {
        return;
      }
    }

    // 1. Simpan ke Master Buku
    const bukuToSave = convertParsedRowsToBuku(validRows);
    const res = arkasStorage.importMasterBuku(bukuToSave, importMode);

    // 2. Jika opsi Sekaligus Buat Draf Pengajuan dicentang
    if (buatDrafPengajuan && selectedLembagaId && totalDipesan > 0) {
      try {
        const lem = lembagaList.find(l => l.id === selectedLembagaId);
        if (lem) {
          const itemsPengajuan = validRows
            .filter(r => r.dipesan > 0)
            .map((r, idx) => ({
              id: `item-imp-${Date.now()}-${idx + 1}`,
              kodeBuku: r.kodeBuku,
              isbn: r.isbn,
              judul: r.judulBuku,
              penulis: r.penulis,
              penerbit: r.penerbit,
              jenjang: r.jenjang,
              kelas: r.kelas,
              mataPelajaran: r.mataPelajaran,
              kurikulum: r.kurikulum,
              jumlah: r.dipesan,
              hargaSatuan: r.harga,
              total: r.jumlah || (r.harga * r.dipesan),
              keterangan: r.keterangan
            }));

          if (itemsPengajuan.length > 0) {
            arkasStorage.savePengajuan({
              lembagaId: lem.id,
              tahunAnggaran: arkasStorage.getSystemSettings().tahunAnggaranAktif || '2026',
              keteranganUmum: `Draf pengajuan hasil impor katalog pesanan buku (${itemsPengajuan.length} judul)`,
              items: itemsPengajuan,
              submitImmediately: false
            });
          }
        }
      } catch (e) {
        console.error('Gagal membuat draf pengajuan:', e);
      }
    }

    if (res.success) {
      setSuccessMessage(res.message);
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1200);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[94vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 my-auto">
        {/* Header Modal */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-emerald-50 via-teal-50 to-blue-50/70 rounded-t-3xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold tracking-wide uppercase">
                <Sparkles className="w-3 h-3 text-emerald-600" />
                <span>Format Standar Pemesanan ARKAS</span>
              </div>
              <h3 className="font-bold text-slate-900 text-base">
                Impor Master Buku: <span className="font-mono text-emerald-800">NO • JUDUL BUKU • KETERANGAN • HARGA • DIPESAN • JUMLAH</span>
              </h3>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs">
          {/* Quick Actions & Format Template Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 bg-slate-50 p-3 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-700">Metode Input:</span>
              <div className="inline-flex rounded-xl bg-slate-200 p-0.5">
                <button
                  type="button"
                  onClick={() => setActiveTab('paste')}
                  className={`px-3 py-1.5 rounded-lg font-semibold text-xs transition-all flex items-center gap-1.5 ${
                    activeTab === 'paste'
                      ? 'bg-white text-emerald-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Clipboard className="w-3.5 h-3.5" />
                  <span>Tempel Teks (Paste)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('upload')}
                  className={`px-3 py-1.5 rounded-lg font-semibold text-xs transition-all flex items-center gap-1.5 ${
                    activeTab === 'upload'
                      ? 'bg-white text-emerald-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Unggah File (.xlsx/.csv)</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={downloadExcelTemplate}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-medium text-xs shadow-2xs transition-colors"
                title="Unduh file format Excel template resmi"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>Unduh Template Excel (.xlsx)</span>
              </button>

              <button
                type="button"
                onClick={handleLoadSample}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold text-xs transition-colors"
                title="Muat contoh data buku siap impor"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>Muat Contoh Data</span>
              </button>

              <button
                type="button"
                onClick={handleCopySample}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-medium text-xs transition-colors"
              >
                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Clipboard className="w-3.5 h-3.5 text-slate-500" />}
                <span>{isCopied ? 'Tersalin!' : 'Salin Format'}</span>
              </button>
            </div>
          </div>

          {/* Banner Error / Sukses */}
          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 flex items-start gap-2.5 shadow-2xs">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 flex items-center gap-2.5 shadow-2xs font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* TAB 1: PASTE TEXT */}
          {activeTab === 'paste' && (
            <div className="space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px] text-slate-600">
                <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                  <Clipboard className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Tempel Tabel Kolom (Salin langsung dari Microsoft Excel atau Google Sheets):</span>
                </span>
                <span className="text-slate-400">
                  Header kolom: <code className="bg-slate-100 px-1 py-0.5 rounded text-emerald-700 font-mono">NO [Tab] JUDUL BUKU [Tab] KETERANGAN [Tab] HARGA [Tab] DIPESAN [Tab] JUMLAH</code>
                </span>
              </div>

              <textarea
                rows={7}
                value={pasteText}
                onChange={(e) => {
                  setPasteText(e.target.value);
                  handleParseText(e.target.value, defaultJenjang);
                }}
                placeholder="1	Matematika untuk SD Kelas 1	Kurikulum Merdeka	21500	60	1290000
2	Bahasa Indonesia untuk SD Kelas 1	Kurikulum Merdeka	23000	60	1380000
3	Pendidikan Agama Islam SD Kelas 1	Kurikulum Merdeka	24500	60	1470000"
                className="w-full p-3 font-mono text-[11px] border border-slate-300 rounded-2xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden leading-relaxed text-slate-800"
              />

              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <span>* Sistem otomatis mendeteksi pemisah Tab, Titik Koma, atau Koma.</span>
                {pasteText && (
                  <button
                    type="button"
                    onClick={() => {
                      setPasteText('');
                      setParsedRows([]);
                    }}
                    className="text-rose-600 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" /> Bersihkan Teks
                  </button>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: UPLOAD FILE EXCEL */}
          {activeTab === 'upload' && (
            <div className="space-y-3">
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 rounded-3xl p-8 text-center cursor-pointer bg-emerald-50/30 hover:bg-emerald-50/60 transition-all space-y-3"
              >
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
                  <Upload className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">
                    {fileName ? `File Terpilih: ${fileName}` : 'Klik atau Tarik File Spreadsheet ke Sini'}
                  </h4>
                  <p className="text-slate-500 text-[11px] mt-1">
                    Mendukung file Microsoft Excel (<strong className="text-slate-700">.xlsx</strong>, <strong className="text-slate-700">.xls</strong>), CSV (<strong className="text-slate-700">.csv</strong>), atau TSV
                  </p>
                </div>

                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-semibold text-xs shadow-xs">
                  <span>Pilih File dari Komputer</span>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx, .xls, .csv, .tsv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>

              <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-[11px] flex items-center justify-between">
                <span>Belum punya formatnya? Unduh template resmi kami yang sudah siap diisi data buku sekolah.</span>
                <button
                  type="button"
                  onClick={downloadExcelTemplate}
                  className="font-bold text-blue-700 hover:underline shrink-0 ml-2"
                >
                  Unduh Template Excel →
                </button>
              </div>
            </div>
          )}

          {/* Pengaturan Bantuan Deteksi Default */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Jenjang Bawaan (Default jika tidak tertera di judul):
              </label>
              <select
                value={defaultJenjang}
                onChange={(e) => {
                  const val = e.target.value as JenjangPendidikan;
                  setDefaultJenjang(val);
                  if (pasteText) handleParseText(pasteText, val);
                }}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white text-xs font-semibold text-slate-800"
              >
                <option value="SD">SD (Sekolah Dasar / MI)</option>
                <option value="SMP">SMP (Sekolah Menengah Pertama / MTs)</option>
                <option value="SMA">SMA (Sekolah Menengah Atas / MA)</option>
                <option value="SMK">SMK (Sekolah Menengah Kejuruan)</option>
                <option value="PAUD">PAUD (Pendidikan Anak Usia Dini)</option>
                <option value="TK">TK (Taman Kanak-Kanak)</option>
                <option value="PKBM">PKBM (Pendidikan Kesetaraan)</option>
                <option value="Lainnya">Lainnya</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Mode Penambahan ke Master Katalog:
              </label>
              <select
                value={importMode}
                onChange={(e) => setImportMode(e.target.value as any)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white text-xs font-semibold text-slate-800"
              >
                <option value="APPEND">Gabungkan / Tambahkan ke Master Katalog (Aman)</option>
                <option value="OVERWRITE">Timpa & Ganti Seluruh Master Buku (Hapus Data Lama)</option>
              </select>
            </div>
          </div>

          {/* HASIL PEMBACAAN DATA LIVE PREVIEW */}
          {parsedRows.length > 0 && (
            <div className="space-y-3 pt-1">
              {/* Statistik Ringkasan */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200">
                  <span className="text-[10px] text-blue-700 font-semibold block uppercase">Total Judul Buku</span>
                  <span className="font-extrabold text-blue-900 text-lg">{totalBuku} Judul</span>
                </div>

                <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200">
                  <span className="text-[10px] text-emerald-700 font-semibold block uppercase">Total Dipesan (Qty)</span>
                  <span className="font-extrabold text-emerald-900 text-lg">{totalDipesan.toLocaleString('id-ID')} Eks</span>
                </div>

                <div className="p-3 rounded-2xl bg-purple-50 border border-purple-200">
                  <span className="text-[10px] text-purple-700 font-semibold block uppercase">Estimasi Nilai Total</span>
                  <span className="font-extrabold text-purple-900 text-base">{formatRupiah(totalNilai)}</span>
                </div>

                <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200">
                  <span className="text-[10px] text-amber-700 font-semibold block uppercase">Status Validasi</span>
                  <span className="font-extrabold text-amber-900 text-sm">
                    {validBuku} Valid {validBuku < totalBuku && `(${totalBuku - validBuku} Perlu Cek)`}
                  </span>
                </div>
              </div>

              {/* Tabel Pratinjau Baris */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-2xs">
                <div className="p-2.5 bg-slate-100 border-b border-slate-200 flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <Eye className="w-3.5 h-3.5 text-blue-600" />
                    <span>Pratinjau Data Buku yang Berhasil Dikenali ({parsedRows.length} baris):</span>
                  </span>
                  <span className="text-slate-500">
                    Format: <span className="font-mono">NO • JUDUL BUKU • KETERANGAN • HARGA • DIPESAN • JUMLAH</span>
                  </span>
                </div>

                <div className="max-h-72 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200 sticky top-0 z-10 text-[10px]">
                      <tr>
                        <th className="py-2 px-2.5 text-center w-10">No</th>
                        <th className="py-2 px-3 min-w-[220px]">Judul Buku & Hasil Deteksi</th>
                        <th className="py-2 px-3">Keterangan</th>
                        <th className="py-2 px-3 text-right">Harga Satuan</th>
                        <th className="py-2 px-3 text-center">Dipesan</th>
                        <th className="py-2 px-3 text-right">Jumlah Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-sans">
                      {parsedRows.map((r, idx) => (
                        <tr key={idx} className={`hover:bg-slate-50 ${!r.isValid ? 'bg-rose-50/50' : ''}`}>
                          <td className="py-2 px-2.5 text-center font-mono text-slate-500 font-semibold">
                            {r.no || idx + 1}
                          </td>
                          <td className="py-2 px-3">
                            <span className="font-bold text-slate-900 block leading-tight">{r.judulBuku}</span>
                            <div className="flex flex-wrap gap-1 mt-1 text-[9px]">
                              <span className="px-1.5 py-0.2 rounded bg-blue-100 text-blue-800 font-bold">
                                {r.jenjang} - {r.kelas}
                              </span>
                              <span className="px-1.5 py-0.2 rounded bg-purple-100 text-purple-800 font-medium">
                                Mapel: {r.mataPelajaran}
                              </span>
                              <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                                {r.kurikulum}
                              </span>
                            </div>
                          </td>
                          <td className="py-2 px-3 text-slate-600 text-[11px]">
                            {r.keterangan || '-'}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-slate-800">
                            {formatRupiah(r.harga)}
                          </td>
                          <td className="py-2 px-3 text-center font-mono font-bold text-emerald-700">
                            {r.dipesan > 0 ? `${r.dipesan} eks` : '-'}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-extrabold text-slate-900">
                            {formatRupiah(r.jumlah || (r.harga * r.dipesan))}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Opsi Opsional: Buat Draf Pengajuan Sekaligus */}
              {totalDipesan > 0 && lembagaList.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-2.5">
                  <label className="flex items-center gap-2 cursor-pointer text-xs select-none">
                    <input
                      type="checkbox"
                      checked={buatDrafPengajuan}
                      onChange={(e) => {
                        setBuatDrafPengajuan(e.target.checked);
                        if (e.target.checked && !selectedLembagaId) {
                          setSelectedLembagaId(lembagaList[0].id);
                        }
                      }}
                      className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="font-bold text-indigo-950 flex items-center gap-1.5">
                      <ShoppingCart className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Sekaligus Buatkan Draf Pengajuan Pemesanan Baru dari Data Kolom DIPESAN ({totalDipesan} Eksemplar)</span>
                    </span>
                  </label>

                  {buatDrafPengajuan && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          Pilih Sekolah / Satuan Pendidikan Tujuan:
                        </label>
                        <select
                          value={selectedLembagaId}
                          onChange={(e) => setSelectedLembagaId(e.target.value)}
                          className="w-full px-3 py-1.5 border border-indigo-300 rounded-xl bg-white text-xs text-slate-800 font-semibold"
                        >
                          {lembagaList.map(l => (
                            <option key={l.id} value={l.id}>
                              {l.namaLembaga} (NPSN: {l.npsn} - {l.kecamatan})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="flex items-end">
                        <span className="text-[10px] text-indigo-700 pb-2">
                          Sistem akan membuat berkas pengajuan baru berstatus <strong>DRAFT</strong> dengan rincian {parsedRows.filter(r => r.dipesan > 0).length} judul buku dan nilai total {formatRupiah(totalNilai)}.
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Footer Submit */}
          <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors"
            >
              Batal
            </button>

            <button
              type="button"
              onClick={handleExecuteImport}
              disabled={parsedRows.length === 0 || validBuku === 0}
              className={`w-full sm:w-auto px-6 py-2.5 font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2 ${
                parsedRows.length === 0 || validBuku === 0
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'
              }`}
            >
              <FileCheck className="w-4 h-4" />
              <span>
                {parsedRows.length > 0 
                  ? `Impor ${validBuku} Judul Buku ke Master Katalog` 
                  : 'Siapkan Data untuk Impor'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
