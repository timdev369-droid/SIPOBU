import React, { useState } from 'react';
import { 
  Settings, 
  Building2, 
  Calendar, 
  ShieldCheck, 
  FileText, 
  Users, 
  Database, 
  Save, 
  RotateCcw, 
  Download, 
  Upload, 
  Key, 
  CheckCircle, 
  AlertCircle, 
  Lock, 
  Unlock, 
  Plus, 
  Check, 
  X,
  Search,
  UserCheck,
  ShieldAlert,
  Sliders,
  MessageSquare,
  Send,
  PhoneCall,
  ExternalLink,
  UserPlus,
  Globe,
  School,
  MapPin,
  Info,
  Sparkles,
  CheckCircle2,
  Clock,
  FileCheck
} from 'lucide-react';
import { CVProfile, SystemSettings, User, Lembaga, RegistrationSettings, JenjangPendidikan } from '../../types/index.ts';
import { arkasStorage, formatDateTimeIndo, INITIAL_REGISTRATION_SETTINGS } from '../../lib/storage.ts';
import { 
  buildWhatsAppProposalMessage, 
  buildWhatsAppNewRegistrationMessage,
  getWhatsAppUrl, 
  openWhatsAppDirect, 
  formatWhatsAppNumber 
} from '../../utils/whatsapp.ts';

interface Props {
  cvProfile: CVProfile;
  onProfileUpdated: () => void;
}

export const SuperAdminSettingsView: React.FC<Props> = ({
  cvProfile,
  onProfileUpdated
}) => {
  const [activeSubTab, setActiveSubTab] = useState<
    'identitas' | 'periode' | 'penomoran' | 'disclaimer' | 'notifwa' | 'registrasi' | 'users' | 'backup'
  >('identitas');

  // Form Identitas CV
  const [cvForm, setCvForm] = useState<CVProfile>({ ...cvProfile });

  // Form Pengaturan Sistem
  const [settingsForm, setSettingsForm] = useState<SystemSettings>(
    arkasStorage.getSystemSettings()
  );

  // Form Pengaturan Isian Registrasi Lembaga
  const [regForm, setRegForm] = useState<RegistrationSettings>(
    () => arkasStorage.getRegistrationSettings()
  );

  // User management state
  const [usersList, setUsersList] = useState<User[]>(arkasStorage.getAllUsers());
  const [lembagaList] = useState<Lembaga[]>(arkasStorage.getAllLembaga());
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState('Semua');
  const [userStatusFilter, setUserStatusFilter] = useState('Semua');

  // Modal Reset Password
  const [resetModalUser, setResetModalUser] = useState<User | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('arkas12345');

  // Modal Tambah Admin CV
  const [showAddAdminModal, setShowAddAdminModal] = useState(false);
  const [newAdminForm, setNewAdminForm] = useState({ username: '', email: '' });

  // Notification state
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showNotify = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3500);
  };

  const handleSaveCVProfile = (e: React.FormEvent) => {
    e.preventDefault();
    arkasStorage.updateCVProfile(cvForm);
    onProfileUpdated();
    showNotify('success', 'Identitas resmi CV Penyedia SIPLah dan data pimpinan berhasil disimpan.');
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const res = arkasStorage.updateSystemSettings(settingsForm);
    if (res.success) {
      setSettingsForm(res.settings);
      onProfileUpdated();
      showNotify('success', 'Pengaturan sistem & kebijakan pengajuan ARKAS berhasil diperbarui.');
    }
  };

  const handleToggleUser = (userId: string) => {
    const res = arkasStorage.toggleUserStatus(userId);
    if (res.success && res.user) {
      setUsersList(arkasStorage.getAllUsers());
      showNotify('success', `Status akun ${res.user.username} diubah menjadi ${res.user.status}.`);
    }
  };

  const handleConfirmResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetModalUser) return;
    const res = arkasStorage.resetUserPassword(resetModalUser.id, newPasswordInput);
    if (res.success) {
      showNotify('success', res.message);
      setResetModalUser(null);
      setNewPasswordInput('arkas12345');
    }
  };

  const handleCreateAdminCV = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminForm.username.trim() || !newAdminForm.email.trim()) {
      alert('Harap isi username dan email.');
      return;
    }
    const res = arkasStorage.addCVAdminUser(newAdminForm);
    if (res.success) {
      setUsersList(arkasStorage.getAllUsers());
      setShowAddAdminModal(false);
      setNewAdminForm({ username: '', email: '' });
      showNotify('success', 'Admin CV baru berhasil didaftarkan ke sistem.');
    } else {
      alert(res.error || 'Gagal menambahkan admin CV.');
    }
  };

  // Backup & Restore
  const handleDownloadBackup = () => {
    const jsonStr = arkasStorage.backupDatabase();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Backup_Database_ARKAS_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showNotify('success', 'File cadangan (backup) database berhasil diunduh.');
  };

  const handleUploadRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (confirm('PERINGATAN: Memulihkan database akan menimpa seluruh data yang ada dengan isi file cadangan. Lanjutkan?')) {
        const res = arkasStorage.restoreDatabase(content);
        if (res.success) {
          setCvForm(arkasStorage.getCVProfile());
          setSettingsForm(arkasStorage.getSystemSettings());
          setRegForm(arkasStorage.getRegistrationSettings());
          setUsersList(arkasStorage.getAllUsers());
          onProfileUpdated();
          showNotify('success', 'Database berhasil dipulihkan dari file cadangan JSON!');
        } else {
          alert(res.error || 'Gagal memulihkan database.');
        }
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleSaveRegistrationSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const res = arkasStorage.updateRegistrationSettings(regForm);
    if (res.success) {
      setRegForm(res.settings);
      setSettingsForm(arkasStorage.getSystemSettings());
      onProfileUpdated();
      showNotify('success', 'Pengaturan data isian formulir registrasi sekolah berhasil disimpan.');
    }
  };

  const handleResetRegistrationSettings = () => {
    if (confirm('Kembalikan konfigurasi formulir registrasi ke pengaturan bawaan awal?')) {
      const res = arkasStorage.updateRegistrationSettings(INITIAL_REGISTRATION_SETTINGS);
      if (res.success) {
        setRegForm(res.settings);
        setSettingsForm(arkasStorage.getSystemSettings());
        onProfileUpdated();
        showNotify('success', 'Pengaturan data isian formulir registrasi dikembalikan ke pengaturan bawaan.');
      }
    }
  };

  const handleApproveUser = (userId: string) => {
    const res = arkasStorage.setUserStatus(userId, 'ACTIVE');
    if (res.success && res.user) {
      setUsersList(arkasStorage.getAllUsers());
      showNotify('success', `Akun sekolah "${res.user.username}" berhasil disetujui dan diaktifkan.`);
    }
  };

  // Preview Nomor Pengajuan Live
  const livePreviewNomor = `${settingsForm.prefixNomorPengajuan || 'PB'}-${settingsForm.tahunAnggaranAktif || '2026'}-${'1'.padStart(settingsForm.digitNomorUrut || 4, '0')}`;

  // Jumlah pengguna menunggu verifikasi (Pending)
  const pendingUsersCount = usersList.filter(u => u.status === 'PENDING').length;

  // Filtered Users
  const filteredUsers = usersList.filter(u => {
    const q = userSearch.toLowerCase();
    const lem = lembagaList.find(l => l.id === u.lembagaId);
    const matchSearch = 
      u.username.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      (lem && (lem.namaLembaga.toLowerCase().includes(q) || lem.npsn.includes(q)));

    const matchRole = userRoleFilter === 'Semua' || u.role === userRoleFilter;
    const matchStatus = userStatusFilter === 'Semua' || u.status === userStatusFilter;
    return matchSearch && matchRole && matchStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header Pusat Pengaturan Super Admin */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 rounded-2xl p-6 text-white shadow-xl border border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold ring-1 ring-amber-400/30">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Pusat Kendali Pengaturan Super Admin</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Pengaturan Sistem & Kebijakan ARKAS
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl">
              Kelola seluruh konfigurasi identitas CV penyedia, pembukaan periode anggaran, batas eksemplar, format penomoran berkas, disclaimer resmi, dan manajemen akun sekolah.
            </p>
          </div>

          <div className="text-right">
            <span className="text-[11px] text-slate-400 block">Tahun Anggaran Berjalan:</span>
            <span className="font-mono text-xl font-extrabold text-amber-400">
              TA {settingsForm.tahunAnggaranAktif}
            </span>
          </div>
        </div>
      </div>

      {/* Floating Notification */}
      {notification && (
        <div className={`p-4 rounded-xl border flex items-center gap-3 text-xs font-semibold shadow-md transition-all ${
          notification.type === 'success'
            ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
            : 'bg-rose-50 border-rose-300 text-rose-900'
        }`}>
          {notification.type === 'success' ? (
            <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Sub Tabs Navigation */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-1.5 flex flex-wrap gap-1 text-xs">
        <button
          onClick={() => setActiveSubTab('identitas')}
          className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all ${
            activeSubTab === 'identitas'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>1. Identitas CV & Kop</span>
        </button>

        <button
          onClick={() => setActiveSubTab('periode')}
          className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all ${
            activeSubTab === 'periode'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>2. Periode & Kebijakan</span>
        </button>

        <button
          onClick={() => setActiveSubTab('penomoran')}
          className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all ${
            activeSubTab === 'penomoran'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>3. Format Penomoran</span>
        </button>

        <button
          onClick={() => setActiveSubTab('disclaimer')}
          className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all ${
            activeSubTab === 'disclaimer'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>4. Disclaimer Dokumen</span>
        </button>

        <button
          onClick={() => setActiveSubTab('notifwa')}
          className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all ${
            activeSubTab === 'notifwa'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>5. Notifikasi WA Admin</span>
          <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${
            settingsForm.notifWaAdminAktif
              ? activeSubTab === 'notifwa' ? 'bg-emerald-800 text-emerald-100' : 'bg-emerald-100 text-emerald-800'
              : 'bg-slate-200 text-slate-600'
          }`}>
            {settingsForm.notifWaAdminAktif ? 'AKTIF' : 'OFF'}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('registrasi')}
          className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all ${
            activeSubTab === 'registrasi'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          <span>6. Data Isian Registrasi</span>
          <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${
            regForm.bukaRegistrasi
              ? activeSubTab === 'registrasi' ? 'bg-blue-800 text-blue-100' : 'bg-emerald-100 text-emerald-800'
              : 'bg-rose-100 text-rose-700'
          }`}>
            {regForm.bukaRegistrasi ? 'BUKA' : 'TUTUP'}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('users')}
          className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all relative ${
            activeSubTab === 'users'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>7. Manajemen Pengguna</span>
          {pendingUsersCount > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-[9px] font-extrabold bg-amber-400 text-amber-950 animate-pulse">
              {pendingUsersCount} Menunggu
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveSubTab('backup')}
          className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all ${
            activeSubTab === 'backup'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>8. Cadangan & Database</span>
        </button>
      </div>

      {/* TAB CONTENT 1: IDENTITAS CV & KOP SURAT */}
      {activeSubTab === 'identitas' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                Identitas Resmi CV Penyedia SIPLah & Pejabat Pengesahan Dokumen
              </h3>
              <p className="text-xs text-slate-500">
                Data ini dicetak resmi pada Kop Berkas Rekapitulasi ARKAS, Lembar Pengesahan PDF, dan Header Excel.
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveCVProfile} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nama Resmi CV Penyedia SIPLah *
                </label>
                <input
                  type="text"
                  required
                  value={cvForm.namaCv}
                  onChange={(e) => setCvForm({ ...cvForm, namaCv: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tahun Anggaran Aktif Berjalan *
                </label>
                <input
                  type="text"
                  required
                  value={cvForm.tahunAnggaranAktif}
                  onChange={(e) => setCvForm({ ...cvForm, tahunAnggaranAktif: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-blue-700"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nama Direktur / Pimpinan Terang *
                </label>
                <input
                  type="text"
                  required
                  value={cvForm.direktur}
                  onChange={(e) => setCvForm({ ...cvForm, direktur: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">Dicantumkan pada area tanda tangan Pihak CV di PDF.</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Jabatan Pimpinan
                  </label>
                  <input
                    type="text"
                    value={cvForm.jabatanDirektur || 'Direktur Utama'}
                    onChange={(e) => setCvForm({ ...cvForm, jabatanDirektur: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    NIP / NIK Pimpinan (Opsional)
                  </label>
                  <input
                    type="text"
                    value={cvForm.nipDirektur || ''}
                    onChange={(e) => setCvForm({ ...cvForm, nipDirektur: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">
                  Alamat Kantor Resmi CV *
                </label>
                <input
                  type="text"
                  required
                  value={cvForm.alamat}
                  onChange={(e) => setCvForm({ ...cvForm, alamat: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nomor Telepon Kantor
                </label>
                <input
                  type="text"
                  value={cvForm.telepon}
                  onChange={(e) => setCvForm({ ...cvForm, telepon: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nomor WhatsApp Pelayanan ARKAS
                </label>
                <input
                  type="text"
                  value={cvForm.whatsapp}
                  onChange={(e) => setCvForm({ ...cvForm, whatsapp: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Email Resmi Layanan ARKAS
                </label>
                <input
                  type="email"
                  value={cvForm.email}
                  onChange={(e) => setCvForm({ ...cvForm, email: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Keterangan Profil / Tagline Dokumen
                </label>
                <input
                  type="text"
                  value={cvForm.keterangan}
                  onChange={(e) => setCvForm({ ...cvForm, keterangan: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Identitas CV & Kop</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB CONTENT 2: KEBIJAKAN & PERIODE ANGGARAN */}
      {activeSubTab === 'periode' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-900 text-base">
              Kebijakan Pengajuan & Periode Anggaran ARKAS
            </h3>
            <p className="text-xs text-slate-500">
              Kendalikan status pembukaan pengajuan, batas tenggat waktu, dan kuota pemesanan buku per sekolah.
            </p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-5 text-xs">
            {/* Periode Buka/Tutup Switch */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 text-sm">Status Periode Pengajuan Buku</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    settingsForm.periodePengajuanBuka 
                      ? 'bg-emerald-100 text-emerald-800' 
                      : 'bg-rose-100 text-rose-800'
                  }`}>
                    {settingsForm.periodePengajuanBuka ? 'SEDANG DIBUKA' : 'DITUTUP'}
                  </span>
                </div>
                <p className="text-slate-500">
                  Jika ditutup, sekolah tidak dapat mengirim pengajuan baru ke CV (hanya dapat menyimpan draf).
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSettingsForm({ ...settingsForm, periodePengajuanBuka: !settingsForm.periodePengajuanBuka })}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  settingsForm.periodePengajuanBuka ? 'bg-blue-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                    settingsForm.periodePengajuanBuka ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tahun Anggaran Berjalan (Pagu ARKAS) *
                </label>
                <select
                  value={settingsForm.tahunAnggaranAktif}
                  onChange={(e) => setSettingsForm({ ...settingsForm, tahunAnggaranAktif: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold text-slate-900"
                >
                  <option value="2026">2026 (Tahun Berjalan)</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028</option>
                  <option value="2025">2025</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Batas Tenggat Waktu (Deadline) Pengajuan Berkas
                </label>
                <input
                  type="date"
                  value={settingsForm.batasWaktuPengajuan || ''}
                  onChange={(e) => setSettingsForm({ ...settingsForm, batasWaktuPengajuan: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-medium text-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Batas Minimum Eksemplar Per Judul Buku
                </label>
                <input
                  type="number"
                  min={1}
                  value={settingsForm.minEksemplarPerItem}
                  onChange={(e) => setSettingsForm({ ...settingsForm, minEksemplarPerItem: parseInt(e.target.value) || 1 })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Batas Maksimum Eksemplar Per Judul Buku
                </label>
                <input
                  type="number"
                  min={10}
                  value={settingsForm.maxEksemplarPerItem}
                  onChange={(e) => setSettingsForm({ ...settingsForm, maxEksemplarPerItem: parseInt(e.target.value) || 500 })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold text-slate-900"
                />
              </div>
            </div>

            {/* Izin Buku Custom */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-4">
              <div className="space-y-0.5">
                <span className="font-bold text-slate-900 text-sm">
                  Izinkan Sekolah Menambah Buku Custom (Di Luar Master CV)
                </span>
                <p className="text-slate-500">
                  Jika diaktifkan, tombol "+ Ajukan Buku Baru" akan muncul di formulir sekolah. Jika dinonaktifkan, sekolah wajib memilih buku yang ada di master katalog CV saja.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSettingsForm({ ...settingsForm, izinkanBukuCustom: !settingsForm.izinkanBukuCustom })}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  settingsForm.izinkanBukuCustom ? 'bg-blue-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                    settingsForm.izinkanBukuCustom ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Kebijakan Periode</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB CONTENT 3: FORMAT PENOMORAN OTOMATIS */}
      {activeSubTab === 'penomoran' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-900 text-base">
              Format Penomoran Berkas Pengajuan Otomatis (Requirement 23)
            </h3>
            <p className="text-xs text-slate-500">
              Konfigurasi kode awalan (prefix) dan digit nomor urut berkas pengajuan ARKAS.
            </p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-5 text-xs">
            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[10px] text-blue-700 font-bold uppercase tracking-wider block">Live Preview Nomor Pengajuan Baru:</span>
                <span className="font-mono text-2xl font-extrabold text-blue-900 mt-1 block">
                  {livePreviewNomor}
                </span>
                <span className="text-[11px] text-slate-500">Format sistem: [PREFIX]-[TAHUN]-[NOMOR URUT]</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Prefix Awalan Nomor Pengajuan *
                </label>
                <input
                  type="text"
                  required
                  value={settingsForm.prefixNomorPengajuan}
                  onChange={(e) => setSettingsForm({ ...settingsForm, prefixNomorPengajuan: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                  placeholder="Contoh: PB atau ARKAS-PB"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">Default Kemdikbud: PB (Pengajuan Buku).</span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Jumlah Digit Nomor Urut (Padding) *
                </label>
                <select
                  value={settingsForm.digitNomorUrut}
                  onChange={(e) => setSettingsForm({ ...settingsForm, digitNomorUrut: parseInt(e.target.value) || 4 })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                >
                  <option value={4}>4 Digit (0001, 0002, ...)</option>
                  <option value={5}>5 Digit (00001, 00002, ...)</option>
                  <option value={6}>6 Digit (000001, 000002, ...)</option>
                </select>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Format Penomoran</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB CONTENT 4: DISCLAIMER DOKUMEN & TEMPLATE CATATAN */}
      {activeSubTab === 'disclaimer' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-900 text-base">
              Catatan Resmi Dokumen & Template Verifikasi
            </h3>
            <p className="text-xs text-slate-500">
              Sesuaikan teks catatan resmi yang tercetak di dokumen PDF/Excel serta template pesan verifikasi CV.
            </p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Teks Catatan / Disclaimer Dokumen (Cetak di PDF & Excel) *
              </label>
              <textarea
                rows={3}
                required
                value={settingsForm.disclaimerDokumen}
                onChange={(e) => setSettingsForm({ ...settingsForm, disclaimerDokumen: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-800 leading-relaxed font-medium"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Catatan resmi yang dicantumkan pada lembar cetak dokumen pemesanan dan rekapitulasi buku SIPOBU.
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Template Standar Catatan CV Saat Menyetujui Pengajuan
              </label>
              <textarea
                rows={2}
                value={settingsForm.templateCatatanSetuju}
                onChange={(e) => setSettingsForm({ ...settingsForm, templateCatatanSetuju: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-800"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Template Standar Catatan CV Saat Meminta Revisi
              </label>
              <textarea
                rows={2}
                value={settingsForm.templateCatatanRevisi}
                onChange={(e) => setSettingsForm({ ...settingsForm, templateCatatanRevisi: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-800"
              />
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Disclaimer & Template</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB CONTENT 5: NOTIFIKASI OTOMATIS WHATSAPP ADMIN */}
      {activeSubTab === 'notifwa' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div className="border-b border-slate-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold mb-1">
                <MessageSquare className="w-3 h-3 text-emerald-600" />
                <span>WhatsApp Automation Dispatcher</span>
              </div>
              <h3 className="font-bold text-slate-900 text-base">
                Notifikasi Pemesanan & Pengajuan Buku ke WhatsApp Admin Otomatis
              </h3>
              <p className="text-xs text-slate-500">
                Setiap kali lembaga sekolah mengirim pengajuan buku baru atau revisi, sistem secara otomatis meneruskan pesan WhatsApp resmi ke nomor Admin CV.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                const sampleLembaga = lembagaList[0] || {
                  namaLembaga: 'SD Negeri Sukamaju 01',
                  npsn: '20104501',
                  statusLembaga: 'Negeri',
                  jenjang: 'SD',
                  kecamatan: 'Cikarang Pusat',
                  kabupaten: 'Bekasi',
                  kepalaSekolah: 'Dra. Hj. Siti Rohmah, M.Pd.',
                  operator: 'Rahmat Hidayat, S.Kom.',
                  whatsapp: '0813-1122-3344'
                };
                const samplePengajuan = {
                  id: 'test-pg',
                  nomorPengajuan: `${settingsForm.prefixNomorPengajuan || 'PB'}-${settingsForm.tahunAnggaranAktif || '2026'}-0001`,
                  tahunAnggaran: settingsForm.tahunAnggaranAktif || '2026',
                  tanggalPengajuan: new Date().toISOString().split('T')[0],
                  status: 'DIKIRIM LEMBAGA' as const,
                  totalJenisBuku: 3,
                  totalBuku: 180,
                  totalNilai: 4330000,
                  keteranganUmum: 'Uji coba pengiriman notifikasi pemesanan buku otomatis ke WA Admin CV.',
                  items: [
                    { id: '1', judul: 'Matematika Kelas 1 SD', kelas: 'Kelas 1', jumlah: 60, hargaSatuan: 21500, total: 1290000 },
                    { id: '2', judul: 'Bahasa Indonesia Kelas 1 SD', kelas: 'Kelas 1', jumlah: 60, hargaSatuan: 23000, total: 1380000 },
                    { id: '3', judul: 'IPAS Kelas 4 SD', kelas: 'Kelas 4', jumlah: 60, hargaSatuan: 27666, total: 1660000 }
                  ]
                };
                const msg = buildWhatsAppProposalMessage(
                  samplePengajuan as any,
                  sampleLembaga as any,
                  cvProfile,
                  settingsForm.templatePesanWaAdmin
                );
                openWhatsAppDirect(settingsForm.nomorWaAdmin || cvProfile.whatsapp, msg);
                showNotify('success', 'Jendela WhatsApp uji coba berhasil dibuka ke nomor admin!');
              }}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all self-start sm:self-auto shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Test Kirim WA ke Admin 🚀</span>
            </button>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-5 text-xs">
            {/* Sakelar Notifikasi Otomatis */}
            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 flex items-center justify-between gap-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 text-sm">
                    Status Pengiriman WhatsApp Otomatis ke Admin CV
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    settingsForm.notifWaAdminAktif 
                      ? 'bg-emerald-100 text-emerald-800' 
                      : 'bg-slate-200 text-slate-700'
                  }`}>
                    {settingsForm.notifWaAdminAktif ? 'AKTIF (OTOMATIS)' : 'NONAKTIF'}
                  </span>
                </div>
                <p className="text-slate-500">
                  Saat diaktifkan, setiap sekolah mengklik "Kirim Pengajuan ke CV", jendela konfirmasi WhatsApp otomatis muncul dan memuat seluruh ringkasan pengajuan ke nomor admin.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSettingsForm({ ...settingsForm, notifWaAdminAktif: !settingsForm.notifWaAdminAktif })}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  settingsForm.notifWaAdminAktif ? 'bg-emerald-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                    settingsForm.notifWaAdminAktif ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nomor WhatsApp Penerima Admin CV *
                </label>
                <div className="relative">
                  <PhoneCall className="w-4 h-4 text-emerald-600 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={settingsForm.nomorWaAdmin || cvForm.whatsapp}
                    onChange={(e) => setSettingsForm({ ...settingsForm, nomorWaAdmin: e.target.value })}
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    placeholder="Contoh: 0813-1122-3344"
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                  <span>Format WhatsApp Internasional:</span>
                  <span className="font-mono font-bold text-emerald-700">
                    +{formatWhatsAppNumber(settingsForm.nomorWaAdmin || cvForm.whatsapp)}
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nama Penerima / Layanan WhatsApp
                </label>
                <input
                  type="text"
                  value={cvForm.namaCv}
                  readOnly
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-600 font-semibold cursor-not-allowed"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Nama CV otomatis disematkan pada salam pengantar pesan WhatsApp.
                </span>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">
                  Format Salam & Teks Pengantar Pesan WhatsApp
                </label>
                <textarea
                  rows={2}
                  value={settingsForm.templatePesanWaAdmin || ''}
                  onChange={(e) => setSettingsForm({ ...settingsForm, templatePesanWaAdmin: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-800 leading-relaxed font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  placeholder="Yth. Tim Admin CV, telah masuk pengajuan kebutuhan buku baru untuk perencanaan anggaran ARKAS..."
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  Kalimat pembuka pesan sebelum data identitas sekolah dan rincian buku.
                </span>
              </div>
            </div>

            {/* Live Interactive WhatsApp Chat Preview */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Simulasi Live Teks WhatsApp yang Tiba di Nomor Admin:</span>
                </span>
                <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  Otomatis Tergenerate Lengkap
                </span>
              </div>

              <div className="relative rounded-2xl bg-[#EFEAE2] p-4 border border-slate-300 shadow-inner font-sans">
                <div className="bg-white rounded-2xl p-4 shadow-sm border border-emerald-100 max-h-60 overflow-y-auto whitespace-pre-wrap text-[11px] text-slate-800 leading-relaxed font-mono">
                  {buildWhatsAppProposalMessage(
                    {
                      id: 'demo-pg',
                      nomorPengajuan: `${settingsForm.prefixNomorPengajuan || 'PB'}-${settingsForm.tahunAnggaranAktif || '2026'}-0001`,
                      tahunAnggaran: settingsForm.tahunAnggaranAktif || '2026',
                      tanggalPengajuan: new Date().toISOString().split('T')[0],
                      status: 'DIKIRIM LEMBAGA',
                      totalJenisBuku: 3,
                      totalBuku: 180,
                      totalNilai: 4330000,
                      keteranganUmum: 'Pengadaan Buku Pelajaran Pokok Semester 1 & 2',
                      items: [
                        { id: '1', judul: 'Matematika Kelas 1 SD', kelas: 'Kelas 1', jumlah: 60, hargaSatuan: 21500, total: 1290000 },
                        { id: '2', judul: 'Bahasa Indonesia Kelas 1 SD', kelas: 'Kelas 1', jumlah: 60, hargaSatuan: 23000, total: 1380000 },
                        { id: '3', judul: 'IPAS Kelas 4 SD', kelas: 'Kelas 4', jumlah: 60, hargaSatuan: 27666, total: 1660000 }
                      ]
                    } as any,
                    lembagaList[0] || {
                      namaLembaga: 'SD Negeri Sukamaju 01',
                      npsn: '20104501',
                      statusLembaga: 'Negeri',
                      jenjang: 'SD',
                      kecamatan: 'Cikarang Pusat',
                      kabupaten: 'Bekasi',
                      kepalaSekolah: 'Dra. Hj. Siti Rohmah, M.Pd.',
                      operator: 'Rahmat Hidayat, S.Kom.',
                      whatsapp: '0813-1122-3344'
                    } as any,
                    cvProfile,
                    settingsForm.templatePesanWaAdmin
                  )}
                </div>
                <div className="text-[10px] text-slate-500 text-right mt-1.5 flex items-center justify-end gap-1">
                  <span>✓✓ Terkirim otomatis ke WhatsApp Admin CV</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Pengaturan Notifikasi WA</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB CONTENT 6: PENGATURAN DATA ISIAN FORMULIR REGISTRASI */}
      {activeSubTab === 'registrasi' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div className="border-b border-slate-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 text-[11px] font-bold border border-blue-200 mb-1">
                <UserPlus className="w-3.5 h-3.5 text-blue-600" />
                <span>Formulir Pendaftaran Satuan Pendidikan</span>
              </div>
              <h3 className="font-bold text-slate-900 text-base">
                Pengaturan Data Isian Registrasi Akun Sekolah
              </h3>
              <p className="text-xs text-slate-500">
                Atur pembukaan pendaftaran akun sekolah, mode persetujuan akun baru, kolom isian yang ditampilkan/diwajibkan, pembatasan jenjang & wilayah binaan CV, serta notifikasi WhatsApp ke Admin.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${
                regForm.bukaRegistrasi 
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300' 
                  : 'bg-rose-50 text-rose-700 border-rose-300'
              }`}>
                <span className={`w-2 h-2 rounded-full ${regForm.bukaRegistrasi ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                <span>{regForm.bukaRegistrasi ? 'Pendaftaran Dibuka' : 'Pendaftaran Ditutup'}</span>
              </span>
            </div>
          </div>

          <form onSubmit={handleSaveRegistrationSettings} className="space-y-6 text-xs">
            {/* Bagian 1: Status Pembukaan Pendaftaran & Kebijakan Aktivasi */}
            <div className="bg-slate-50/70 border border-slate-200 rounded-2xl p-5 space-y-4">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                <span>1. Kebijakan Pembukaan Pendaftaran & Mode Aktivasi Akun</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Switch Buka Registrasi */}
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <strong className="text-slate-900 font-semibold block text-xs">
                        Buka Pendaftaran Akun Lembaga Baru
                      </strong>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Jika dinonaktifkan, formulir registrasi ditutup dan sekolah diarahkan menghubungi nomor layanan CV.
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-0.5">
                      <input
                        type="checkbox"
                        checked={regForm.bukaRegistrasi}
                        onChange={(e) => setRegForm({ ...regForm, bukaRegistrasi: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                    </label>
                  </div>

                  {!regForm.bukaRegistrasi && (
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1 text-[11px]">
                        Pesan Peringatan saat Pendaftaran Ditutup:
                      </label>
                      <textarea
                        rows={2}
                        value={regForm.pesanRegistrasiTutup}
                        onChange={(e) => setRegForm({ ...regForm, pesanRegistrasiTutup: e.target.value })}
                        className="w-full px-3 py-2 border border-rose-300 bg-rose-50/50 rounded-xl text-slate-800 text-xs focus:ring-2 focus:ring-rose-500"
                        placeholder="Pendaftaran akun satuan pendidikan baru sementara ditutup..."
                      />
                    </div>
                  )}
                </div>

                {/* Mode Aktivasi Akun (Auto Approve vs Pending) */}
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3">
                  <strong className="text-slate-900 font-semibold block text-xs">
                    Mode Persetujuan Akun Pendaftar Baru
                  </strong>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label className={`p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                      regForm.autoApprove 
                        ? 'border-emerald-500 bg-emerald-50/40 text-emerald-950' 
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}>
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="autoApprove"
                          checked={regForm.autoApprove}
                          onChange={() => setRegForm({ ...regForm, autoApprove: true })}
                          className="text-emerald-600 focus:ring-emerald-500"
                        />
                        <span className="font-bold text-xs">Aktivasi Otomatis</span>
                      </div>
                      <span className="text-[10px] text-slate-500 mt-1 block">
                        Akun langsung aktif seketika setelah mendaftar dan dapat langsung login.
                      </span>
                    </label>

                    <label className={`p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                      !regForm.autoApprove 
                        ? 'border-amber-500 bg-amber-50/40 text-amber-950' 
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}>
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="autoApprove"
                          checked={!regForm.autoApprove}
                          onChange={() => setRegForm({ ...regForm, autoApprove: false })}
                          className="text-amber-600 focus:ring-amber-500"
                        />
                        <span className="font-bold text-xs">Verifikasi Super Admin</span>
                      </div>
                      <span className="text-[10px] text-slate-500 mt-1 block">
                        Akun berstatus PENDING hingga disetujui Admin CV di tab Manajemen Pengguna.
                      </span>
                    </label>
                  </div>

                  {!regForm.autoApprove && (
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1 text-[11px]">
                        Petunjuk / Pesan saat Akun Berstatus Menunggu Verifikasi:
                      </label>
                      <input
                        type="text"
                        value={regForm.pesanPendingVerifikasi}
                        onChange={(e) => setRegForm({ ...regForm, pesanPendingVerifikasi: e.target.value })}
                        className="w-full px-3 py-1.5 border border-amber-300 bg-amber-50/40 rounded-xl text-slate-800 text-xs focus:ring-2 focus:ring-amber-500"
                        placeholder="Pendaftaran berhasil dikirim. Menunggu verifikasi oleh tim CV..."
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Bagian 2: Batasan Satuan Pendidikan & Wilayah Resmi CV */}
            <div className="bg-slate-50/70 border border-slate-200 rounded-2xl p-5 space-y-4">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <School className="w-4 h-4 text-indigo-600" />
                <span>2. Batasan Jenjang Pendidikan, Status Lembaga, & Wilayah CV</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Jenjang yang Diizinkan */}
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2 md:col-span-2">
                  <div className="flex items-center justify-between">
                    <strong className="text-slate-900 font-semibold block text-xs">
                      Jenjang Satuan Pendidikan yang Dibuka:
                    </strong>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setRegForm({ ...regForm, jenjangDiizinkan: ['SD', 'SMP', 'SMA', 'SMK', 'PKBM', 'Lainnya'] })}
                        className="text-[10px] text-blue-600 hover:underline font-semibold"
                      >
                        Pilih Semua
                      </button>
                      <span className="text-slate-300">|</span>
                      <button
                        type="button"
                        onClick={() => setRegForm({ ...regForm, jenjangDiizinkan: ['SD', 'SMP'] })}
                        className="text-[10px] text-blue-600 hover:underline font-semibold"
                      >
                        Hanya SD & SMP
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1">
                    {(['SD', 'SMP', 'SMA', 'SMK', 'PKBM', 'Lainnya'] as JenjangPendidikan[]).map((j) => {
                      const isChecked = regForm.jenjangDiizinkan?.includes(j);
                      return (
                        <label
                          key={j}
                          className={`flex items-center gap-2 p-2 rounded-lg border cursor-pointer text-xs select-none transition-all ${
                            isChecked
                              ? 'bg-blue-50 border-blue-300 text-blue-900 font-semibold'
                              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              const current = regForm.jenjangDiizinkan || [];
                              if (e.target.checked) {
                                setRegForm({ ...regForm, jenjangDiizinkan: [...current, j] });
                              } else {
                                if (current.length <= 1) {
                                  alert('Harap sisakan minimal 1 jenjang yang diizinkan mendaftar.');
                                  return;
                                }
                                setRegForm({ ...regForm, jenjangDiizinkan: current.filter(item => item !== j) });
                              }
                            }}
                            className="rounded text-blue-600 focus:ring-blue-500"
                          />
                          <span>{j}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                {/* Status Lembaga yang Diizinkan */}
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
                  <strong className="text-slate-900 font-semibold block text-xs">
                    Status Satuan Pendidikan:
                  </strong>
                  <select
                    value={regForm.statusLembagaDiizinkan}
                    onChange={(e) => setRegForm({ ...regForm, statusLembagaDiizinkan: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white text-xs text-slate-800 font-medium focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="SEMUA">Semua Lembaga (Negeri & Swasta)</option>
                    <option value="NEGERI_SAJA">Hanya Lembaga Negeri</option>
                    <option value="SWASTA_SAJA">Hanya Lembaga Swasta</option>
                  </select>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Membatasi pendaftar hanya dari tipe sekolah tertentu sesuai target mitra CV.
                  </p>
                </div>
              </div>

              {/* Wilayah Binaan CV Default */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2">
                  <div>
                    <strong className="text-slate-900 font-semibold block text-xs">
                      Wilayah Binaan Resmi CV Penyedia SIPLah (Default Form)
                    </strong>
                    <p className="text-[11px] text-slate-500">
                      Kolom Kabupaten/Kota dan Provinsi pada formulir registrasi akan terisi otomatis dengan nilai ini.
                    </p>
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer text-xs select-none bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200">
                    <input
                      type="checkbox"
                      checked={regForm.kunciWilayahDefault}
                      onChange={(e) => setRegForm({ ...regForm, kunciWilayahDefault: e.target.checked })}
                      className="rounded text-amber-600 focus:ring-amber-500"
                    />
                    <span className="font-semibold text-amber-900 flex items-center gap-1">
                      <Lock className="w-3 h-3 text-amber-600" />
                      <span>Kunci Input Wilayah di Form (ReadOnly)</span>
                    </span>
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1 text-[11px]">
                      Default Kabupaten / Kota:
                    </label>
                    <input
                      type="text"
                      value={regForm.defaultKabupaten}
                      onChange={(e) => setRegForm({ ...regForm, defaultKabupaten: e.target.value })}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-xl text-slate-800 text-xs focus:ring-2 focus:ring-blue-500"
                      placeholder="Nama Kabupaten / Kota (Opsional)"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1 text-[11px]">
                      Default Provinsi:
                    </label>
                    <input
                      type="text"
                      value={regForm.defaultProvinsi}
                      onChange={(e) => setRegForm({ ...regForm, defaultProvinsi: e.target.value })}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-xl text-slate-800 text-xs focus:ring-2 focus:ring-blue-500"
                      placeholder="Contoh: Jawa Barat"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Bagian 3: Tabel Kustomisasi Kolom / Field Isian Registrasi */}
            <div className="bg-slate-50/70 border border-slate-200 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-purple-600" />
                    <span>3. Pengaturan Visibilitas & Kewajiban Kolom Isian Registrasi</span>
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Tentukan apakah kolom ditampilkan pada form dan apakah bersifat wajib diisi (Required) atau opsional.
                  </p>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-2xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-semibold uppercase tracking-wider border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Nama Kolom Isian</th>
                        <th className="py-2.5 px-3 text-center">Tampilkan di Form</th>
                        <th className="py-2.5 px-3 text-center">Sifat Kolom (Wajib/Opsional)</th>
                        <th className="py-2.5 px-3">Label Kolom Kustom</th>
                        <th className="py-2.5 px-3">Keterangan / Placeholder</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {/* 1. NIP Kepala Sekolah */}
                      <tr className="hover:bg-slate-50">
                        <td className="py-2.5 px-3">
                          <strong className="text-slate-900 block">NIP / NIK Kepala Sekolah</strong>
                          <span className="text-[10px] text-slate-400">Identitas pimpinan sekolah</span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={regForm.fields.nipKepalaSekolah.tampilkan}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                nipKepalaSekolah: { ...regForm.fields.nipKepalaSekolah, tampilkan: e.target.checked }
                              }
                            })}
                            className="w-4 h-4 rounded text-blue-600"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer select-none ${
                            regForm.fields.nipKepalaSekolah.wajib ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-600'
                          }`}
                          onClick={() => setRegForm({
                            ...regForm,
                            fields: {
                              ...regForm.fields,
                              nipKepalaSekolah: { ...regForm.fields.nipKepalaSekolah, wajib: !regForm.fields.nipKepalaSekolah.wajib }
                            }
                          })}>
                            {regForm.fields.nipKepalaSekolah.wajib ? 'WAJIB *' : 'OPSIONAL'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <input
                            type="text"
                            value={regForm.fields.nipKepalaSekolah.label || ''}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                nipKepalaSekolah: { ...regForm.fields.nipKepalaSekolah, label: e.target.value }
                              }
                            })}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-xs"
                          />
                        </td>
                        <td className="py-2.5 px-3">
                          <input
                            type="text"
                            value={regForm.fields.nipKepalaSekolah.keterangan || ''}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                nipKepalaSekolah: { ...regForm.fields.nipKepalaSekolah, keterangan: e.target.value }
                              }
                            })}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-xs text-slate-500"
                          />
                        </td>
                      </tr>

                      {/* 2. Nama Operator */}
                      <tr className="hover:bg-slate-50">
                        <td className="py-2.5 px-3">
                          <strong className="text-slate-900 block">Nama Operator Sekolah</strong>
                          <span className="text-[10px] text-slate-400">Petugas input ARKAS</span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={regForm.fields.namaOperator.tampilkan}
                            disabled
                            className="w-4 h-4 rounded text-blue-600 opacity-60 cursor-not-allowed"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer select-none ${
                            regForm.fields.namaOperator.wajib ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-600'
                          }`}
                          onClick={() => setRegForm({
                            ...regForm,
                            fields: {
                              ...regForm.fields,
                              namaOperator: { ...regForm.fields.namaOperator, wajib: !regForm.fields.namaOperator.wajib }
                            }
                          })}>
                            {regForm.fields.namaOperator.wajib ? 'WAJIB *' : 'OPSIONAL'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3" colSpan={2}>
                          <input
                            type="text"
                            value={regForm.fields.namaOperator.label || ''}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                namaOperator: { ...regForm.fields.namaOperator, label: e.target.value }
                              }
                            })}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-xs"
                          />
                        </td>
                      </tr>

                      {/* 3. WhatsApp Operator */}
                      <tr className="hover:bg-slate-50">
                        <td className="py-2.5 px-3">
                          <strong className="text-slate-900 block">Nomor WhatsApp Operator</strong>
                          <span className="text-[10px] text-slate-400">Kontak utama notifikasi & koordinasi</span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={regForm.fields.whatsappOperator.tampilkan}
                            disabled
                            className="w-4 h-4 rounded text-blue-600 opacity-60 cursor-not-allowed"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer select-none ${
                            regForm.fields.whatsappOperator.wajib ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-600'
                          }`}
                          onClick={() => setRegForm({
                            ...regForm,
                            fields: {
                              ...regForm.fields,
                              whatsappOperator: { ...regForm.fields.whatsappOperator, wajib: !regForm.fields.whatsappOperator.wajib }
                            }
                          })}>
                            {regForm.fields.whatsappOperator.wajib ? 'WAJIB *' : 'OPSIONAL'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3" colSpan={2}>
                          <input
                            type="text"
                            value={regForm.fields.whatsappOperator.label || ''}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                whatsappOperator: { ...regForm.fields.whatsappOperator, label: e.target.value }
                              }
                            })}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-xs"
                          />
                        </td>
                      </tr>

                      {/* 4. Email Sekolah */}
                      <tr className="hover:bg-slate-50">
                        <td className="py-2.5 px-3">
                          <strong className="text-slate-900 block">Email Resmi Sekolah</strong>
                          <span className="text-[10px] text-slate-400">Korespondensi berkas</span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={regForm.fields.emailSekolah.tampilkan}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                emailSekolah: { ...regForm.fields.emailSekolah, tampilkan: e.target.checked }
                              }
                            })}
                            className="w-4 h-4 rounded text-blue-600"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer select-none ${
                            regForm.fields.emailSekolah.wajib ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-600'
                          }`}
                          onClick={() => setRegForm({
                            ...regForm,
                            fields: {
                              ...regForm.fields,
                              emailSekolah: { ...regForm.fields.emailSekolah, wajib: !regForm.fields.emailSekolah.wajib }
                            }
                          })}>
                            {regForm.fields.emailSekolah.wajib ? 'WAJIB *' : 'OPSIONAL'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3" colSpan={2}>
                          <input
                            type="text"
                            value={regForm.fields.emailSekolah.label || ''}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                emailSekolah: { ...regForm.fields.emailSekolah, label: e.target.value }
                              }
                            })}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-xs"
                          />
                        </td>
                      </tr>

                      {/* 5. Telepon Kantor */}
                      <tr className="hover:bg-slate-50">
                        <td className="py-2.5 px-3">
                          <strong className="text-slate-900 block">Nomor Telepon Kantor / TU</strong>
                          <span className="text-[10px] text-slate-400">Telepon kabel kantor</span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={regForm.fields.teleponKantor.tampilkan}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                teleponKantor: { ...regForm.fields.teleponKantor, tampilkan: e.target.checked }
                              }
                            })}
                            className="w-4 h-4 rounded text-blue-600"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer select-none ${
                            regForm.fields.teleponKantor.wajib ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-600'
                          }`}
                          onClick={() => setRegForm({
                            ...regForm,
                            fields: {
                              ...regForm.fields,
                              teleponKantor: { ...regForm.fields.teleponKantor, wajib: !regForm.fields.teleponKantor.wajib }
                            }
                          })}>
                            {regForm.fields.teleponKantor.wajib ? 'WAJIB *' : 'OPSIONAL'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3" colSpan={2}>
                          <input
                            type="text"
                            value={regForm.fields.teleponKantor.label || ''}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                teleponKantor: { ...regForm.fields.teleponKantor, label: e.target.value }
                              }
                            })}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-xs"
                          />
                        </td>
                      </tr>

                      {/* 6. Alamat Jalan */}
                      <tr className="hover:bg-slate-50">
                        <td className="py-2.5 px-3">
                          <strong className="text-slate-900 block">Alamat Jalan & Nomor</strong>
                          <span className="text-[10px] text-slate-400">Domisili gedung sekolah</span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={regForm.fields.alamatJalan.tampilkan}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                alamatJalan: { ...regForm.fields.alamatJalan, tampilkan: e.target.checked }
                              }
                            })}
                            className="w-4 h-4 rounded text-blue-600"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer select-none ${
                            regForm.fields.alamatJalan.wajib ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-600'
                          }`}
                          onClick={() => setRegForm({
                            ...regForm,
                            fields: {
                              ...regForm.fields,
                              alamatJalan: { ...regForm.fields.alamatJalan, wajib: !regForm.fields.alamatJalan.wajib }
                            }
                          })}>
                            {regForm.fields.alamatJalan.wajib ? 'WAJIB *' : 'OPSIONAL'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3" colSpan={2}>
                          <input
                            type="text"
                            value={regForm.fields.alamatJalan.label || ''}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                alamatJalan: { ...regForm.fields.alamatJalan, label: e.target.value }
                              }
                            })}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-xs"
                          />
                        </td>
                      </tr>

                      {/* 7. Desa & Kecamatan */}
                      <tr className="hover:bg-slate-50">
                        <td className="py-2.5 px-3">
                          <strong className="text-slate-900 block">Desa & Kecamatan</strong>
                          <span className="text-[10px] text-slate-400">Wilayah kelurahan & distrik</span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={regForm.fields.kecamatan.tampilkan}
                            onChange={(e) => setRegForm({
                              ...regForm,
                              fields: {
                                ...regForm.fields,
                                desa: { ...regForm.fields.desa, tampilkan: e.target.checked },
                                kecamatan: { ...regForm.fields.kecamatan, tampilkan: e.target.checked }
                              }
                            })}
                            className="w-4 h-4 rounded text-blue-600"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer select-none ${
                            regForm.fields.kecamatan.wajib ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-600'
                          }`}
                          onClick={() => setRegForm({
                            ...regForm,
                            fields: {
                              ...regForm.fields,
                              desa: { ...regForm.fields.desa, wajib: !regForm.fields.desa.wajib },
                              kecamatan: { ...regForm.fields.kecamatan, wajib: !regForm.fields.kecamatan.wajib }
                            }
                          })}>
                            {regForm.fields.kecamatan.wajib ? 'WAJIB *' : 'OPSIONAL'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3" colSpan={2}>
                          <span className="text-slate-500 text-[11px]">Kolom Desa/Kelurahan dan Kecamatan terhubung</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Bagian 4: Validasi Kredensial, NPSN, & Pernyataan Integritas Data */}
            <div className="bg-slate-50/70 border border-slate-200 rounded-2xl p-5 space-y-4">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-emerald-600" />
                <span>4. Validasi Kredensial Akun & Pernyataan Integritas Data</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3">
                  <strong className="text-slate-900 font-semibold block text-xs">
                    Aturan Validasi Format Input:
                  </strong>

                  <label className="flex items-center gap-2.5 cursor-pointer text-xs select-none">
                    <input
                      type="checkbox"
                      checked={regForm.wajibValidasiNpsn8Digit}
                      onChange={(e) => setRegForm({ ...regForm, wajibValidasiNpsn8Digit: e.target.checked })}
                      className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-slate-700">
                      Wajibkan Format 8 Digit Angka NPSN (Standar Dapodik)
                    </span>
                  </label>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1 text-[11px]">
                      Minimal Panjang Karakter Password Baru:
                    </label>
                    <input
                      type="number"
                      min={4}
                      max={20}
                      value={regForm.minPanjangPassword}
                      onChange={(e) => setRegForm({ ...regForm, minPanjangPassword: parseInt(e.target.value) || 6 })}
                      className="w-32 px-3 py-1.5 border border-slate-300 rounded-xl text-slate-800 text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3">
                  <strong className="text-slate-900 font-semibold block text-xs">
                    Teks Himbauan / Petunjuk Pendaftaran di Atas Form:
                  </strong>
                  <textarea
                    rows={2}
                    value={regForm.petunjukRegistrasi}
                    onChange={(e) => setRegForm({ ...regForm, petunjukRegistrasi: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-800 text-xs focus:ring-2 focus:ring-blue-500"
                    placeholder="Pastikan data NPSN dan nama kepala sekolah sesuai Dapodik..."
                  />
                </div>
              </div>

              {/* Checkbox Pernyataan Integritas Data */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer text-xs select-none">
                    <input
                      type="checkbox"
                      checked={regForm.wajibCentangPernyataan}
                      onChange={(e) => setRegForm({ ...regForm, wajibCentangPernyataan: e.target.checked })}
                      className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span className="font-semibold text-slate-900">
                      Wajibkan Centang Pernyataan Kebenaran Data sebelum Submit
                    </span>
                  </label>
                </div>

                {regForm.wajibCentangPernyataan && (
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1 text-[11px]">
                      Kalimat Pernyataan Integritas / Sumpah Profesi Data:
                    </label>
                    <textarea
                      rows={2}
                      value={regForm.teksPernyataan}
                      onChange={(e) => setRegForm({ ...regForm, teksPernyataan: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-800 text-xs focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Bagian 5: Notifikasi WhatsApp Otomatis Registrasi Baru ke Admin CV */}
            <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-emerald-600" />
                    <span>5. Notifikasi WhatsApp Otomatis ke Admin CV saat Ada Sekolah Baru Mendaftar</span>
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    Sistem akan memicu pengiriman pesan ringkasan data registrasi sekolah ke nomor WhatsApp resmi CV Admin ({cvProfile.whatsapp || settingsForm.nomorWaAdmin || '-'}).
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={regForm.notifWaAdminRegistrasi}
                    onChange={(e) => setRegForm({ ...regForm, notifWaAdminRegistrasi: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Simulasi Teks Pesan WhatsApp Registrasi Baru */}
              <div className="space-y-1.5 pt-1">
                <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Simulasi Teks WhatsApp Notifikasi Registrasi Baru yang Tiba di WA Admin:</span>
                </span>
                <div className="relative rounded-2xl bg-[#EFEAE2] p-4 border border-slate-300 shadow-inner font-sans">
                  <div className="bg-white rounded-2xl p-4 shadow-sm border border-emerald-100 max-h-56 overflow-y-auto whitespace-pre-wrap text-[11px] text-slate-800 leading-relaxed font-mono">
                    {buildWhatsAppNewRegistrationMessage(
                      {
                        id: 'demo-lem',
                        userId: 'usr-demo',
                        namaLembaga: 'SD Negeri Sukamaju 01',
                        npsn: '20104501',
                        jenjang: 'SD',
                        statusLembaga: 'Negeri',
                        kepalaSekolah: 'Dra. Hj. Siti Rohmah, M.Pd.',
                        nipKepalaSekolah: '197505122000032001',
                        operator: 'Rahmat Hidayat, S.Kom.',
                        email: 'sdnsukamaju01@kemdikbud.id',
                        whatsapp: '0813-1122-3344',
                        telepon: '(021) 89012345',
                        alamat: 'Jl. Raya Pendidikan No. 12',
                        desa: 'Sukamaju',
                        kecamatan: 'Tarogong Kidul',
                        kabupaten: regForm.defaultKabupaten || 'Wilayah Binaan',
                        provinsi: regForm.defaultProvinsi || 'Jawa Barat',
                        createdAt: new Date().toISOString()
                      },
                      cvProfile,
                      !regForm.autoApprove
                    )}
                  </div>
                  <div className="text-[10px] text-slate-500 text-right mt-1.5 flex items-center justify-end gap-1">
                    <span>✓✓ Terkirim langsung ke nomor WhatsApp Admin CV ({cvProfile.whatsapp})</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer Form Submit */}
            <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleResetRegistrationSettings}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 bg-slate-50 hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                <span>Reset ke Pengaturan Bawaan</span>
              </button>

              <button
                type="submit"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md transition-all text-xs"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Pengaturan Data Isian Registrasi</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB CONTENT 7: MANAJEMEN PENGGUNA & HAK AKSES */}
      {activeSubTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                Manajemen Akun Pengguna & Hak Akses Super Admin
              </h3>
              <p className="text-xs text-slate-500">
                Kontrol seluruh akun sekolah dan admin CV, verifikasi akun pendaftar baru, reset password akun jika operator lupa, serta kelola status aktif/nonaktif.
              </p>
            </div>

            <button
              onClick={() => setShowAddAdminModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs shadow-xs transition-colors self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>+ Tambah Admin CV</span>
            </button>
          </div>

          {/* Banner Peringatan jika ada Akun Menunggu Verifikasi */}
          {pendingUsersCount > 0 && (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs shadow-xs">
              <div className="flex items-center gap-2 text-amber-900 font-semibold">
                <Clock className="w-4 h-4 text-amber-600 shrink-0 animate-pulse" />
                <span>Terdapat <strong>{pendingUsersCount} akun sekolah baru</strong> yang menunggu verifikasi & persetujuan Super Admin sebelum dapat login.</span>
              </div>
              <button
                type="button"
                onClick={() => setUserStatusFilter('PENDING')}
                className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-[11px] shadow-xs shrink-0 self-end sm:self-auto"
              >
                Tampilkan Akun Menunggu ({pendingUsersCount})
              </button>
            </div>
          )}

          {/* Filter Bar Users */}
          <div className="flex flex-col sm:flex-row items-center gap-2.5 text-xs">
            <div className="relative flex-1 w-full">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Cari username, email, nama sekolah, atau NPSN..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
              />
            </div>

            <select
              value={userRoleFilter}
              onChange={(e) => setUserRoleFilter(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-700 font-medium w-full sm:w-auto"
            >
              <option value="Semua">Semua Peran ({usersList.length})</option>
              <option value="LEMBAGA">Lembaga Sekolah</option>
              <option value="CV">Admin CV</option>
            </select>

            <select
              value={userStatusFilter}
              onChange={(e) => setUserStatusFilter(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-700 font-medium w-full sm:w-auto"
            >
              <option value="Semua">Semua Status</option>
              <option value="ACTIVE">Aktif Saja</option>
              <option value="PENDING">Menunggu Verifikasi ({pendingUsersCount})</option>
              <option value="INACTIVE">Nonaktif Saja</option>
            </select>
          </div>

          {/* Tabel Pengguna */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3 w-8 text-center">No</th>
                    <th className="py-2.5 px-3">Username & Email</th>
                    <th className="py-2.5 px-3">Peran / Role</th>
                    <th className="py-2.5 px-3">Identitas Satuan Pendidikan</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-3 text-center">Aksi Super Admin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400">
                        Tidak ditemukan akun pengguna yang cocok dengan kriteria pencarian.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((u, idx) => {
                      const lem = lembagaList.find(l => l.id === u.lembagaId);
                      return (
                        <tr key={u.id} className={`hover:bg-slate-50 ${u.status === 'PENDING' ? 'bg-amber-50/40' : ''}`}>
                          <td className="py-2.5 px-3 text-center text-slate-500 font-medium">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-3">
                            <strong className="font-mono text-slate-900 block">{u.username}</strong>
                            <span className="text-[10px] text-slate-500">{u.email}</span>
                          </td>
                          <td className="py-2.5 px-3">
                            <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              u.role === 'CV' 
                                ? 'bg-purple-100 text-purple-800' 
                                : 'bg-emerald-100 text-emerald-800'
                            }`}>
                              {u.role === 'CV' ? 'Super Admin CV' : 'Operator Sekolah'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3">
                            {lem ? (
                              <div>
                                <span className="font-semibold text-slate-900 block">{lem.namaLembaga}</span>
                                <span className="text-[10px] text-slate-500">NPSN: {lem.npsn} ({lem.kecamatan}, {lem.kabupaten})</span>
                              </div>
                            ) : (
                              <span className="text-slate-400 italic">Penyedia CV Utama</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              u.status === 'ACTIVE' 
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                : u.status === 'PENDING'
                                ? 'bg-amber-100 text-amber-900 border border-amber-300 font-extrabold'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}>
                              {u.status === 'PENDING' ? 'MENUNGGU VERIFIKASI' : u.status}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <div className="flex items-center justify-center gap-1.5 flex-wrap">
                              {u.status === 'PENDING' && (
                                <button
                                  onClick={() => handleApproveUser(u.id)}
                                  className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] inline-flex items-center gap-1 shadow-xs transition-colors"
                                  title="Setujui dan Aktifkan Akun Sekolah"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Setujui</span>
                                </button>
                              )}

                              <button
                                onClick={() => setResetModalUser(u)}
                                className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-[11px] inline-flex items-center gap-1"
                                title="Reset Password Akun"
                              >
                                <Key className="w-3 h-3 text-amber-600" />
                                <span>Reset Pwd</span>
                              </button>

                              {u.username !== 'admin_cv' && (
                                <button
                                  onClick={() => handleToggleUser(u.id)}
                                  className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                                    u.status === 'ACTIVE'
                                      ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
                                      : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200'
                                  }`}
                                  title="Aktifkan atau Nonaktifkan Akun"
                                >
                                  {u.status === 'ACTIVE' ? 'Nonaktifkan' : 'Aktifkan'}
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 6: CADANGAN & PEMELIHARAAN DATABASE */}
      {activeSubTab === 'backup' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-900 text-base">
              Pusat Cadangan & Pemeliharaan Database Sistem ARKAS
            </h3>
            <p className="text-xs text-slate-500">
              Ekspor seluruh data pemesanan buku, master buku, lembaga, dan riwayat audit untuk arsip keamanan data.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Box 1: Unduh Backup */}
            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                <Download className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">
                Unduh Cadangan Database (.JSON)
              </h4>
              <p className="text-slate-500 text-[11px]">
                Mengekspor seluruh tabel relasional sistem ARKAS (Profil CV, Akun Users, Lembaga, Master Buku, Seluruh Pengajuan & Riwayat Revisi, serta Log Audit) ke dalam satu file terenkripsi JSON.
              </p>
              <button
                onClick={handleDownloadBackup}
                className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Unduh File Cadangan Sekarang</span>
              </button>
            </div>

            {/* Box 2: Pulihkan Backup */}
            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
                <Upload className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">
                Pulihkan Database dari File Cadangan
              </h4>
              <p className="text-slate-500 text-[11px]">
                Pilih file `.json` cadangan yang sebelumnya pernah diunduh untuk mengembalikan seluruh kondisi data sistem ke titik waktu tersebut.
              </p>
              <label className="w-full py-2.5 px-4 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer text-center">
                <Upload className="w-4 h-4" />
                <span>Pilih File Backup JSON</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleUploadRestore}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Reset Demo Safety Box */}
          <div className="p-5 rounded-2xl border border-rose-200 bg-rose-50/40 space-y-2 text-xs">
            <h4 className="font-bold text-rose-900 text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600" />
              <span>Reset Data ke Pengaturan Simulasi Pabrik</span>
            </h4>
            <p className="text-rose-700 text-[11px]">
              Menghapus seluruh perubahan baru dan mengembalikan seluruh data pengajuan, akun sekolah, serta master buku ke data demo awal standar Kemdikbudristek.
            </p>
            <div className="pt-2">
              <button
                onClick={() => {
                  if (confirm('PERINGATAN: Seluruh data pengajuan yang baru dibuat akan dihapus dan dikembalikan ke data demo awal. Yakin?')) {
                    arkasStorage.resetToDefaultDemo();
                    onProfileUpdated();
                    showNotify('success', 'Seluruh data berhasil dikembalikan ke simulasi awal pabrik.');
                  }
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reset ke Data Demo Awal</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL RESET PASSWORD USER */}
      {resetModalUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Key className="w-4 h-4 text-amber-500" />
                <span>Reset Password Pengguna</span>
              </h3>
              <button onClick={() => setResetModalUser(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmResetPassword} className="space-y-3 pt-3">
              <p className="text-slate-600">
                Super Admin akan mereset password untuk akun: <strong className="text-slate-900">{resetModalUser.username}</strong>
              </p>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Masukkan Password Baru Sementara *
                </label>
                <input
                  type="text"
                  required
                  value={newPasswordInput}
                  onChange={(e) => setNewPasswordInput(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setResetModalUser(null)}
                  className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                >
                  Terapkan Reset Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL TAMBAH ADMIN CV */}
      {showAddAdminModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-purple-600" />
                <span>Tambah Admin CV Baru</span>
              </h3>
              <button onClick={() => setShowAddAdminModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateAdminCV} className="space-y-3 pt-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Username Admin *</label>
                <input
                  type="text"
                  required
                  placeholder="admin_operasional"
                  value={newAdminForm.username}
                  onChange={(e) => setNewAdminForm({ ...newAdminForm, username: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Email Admin *</label>
                <input
                  type="email"
                  required
                  placeholder="admin@cvgrahapustaka.id"
                  value={newAdminForm.email}
                  onChange={(e) => setNewAdminForm({ ...newAdminForm, email: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddAdminModal(false)}
                  className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-semibold"
                >
                  Daftarkan Admin CV
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
