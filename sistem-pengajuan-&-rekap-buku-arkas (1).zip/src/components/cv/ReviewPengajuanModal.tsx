import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertCircle, 
  XCircle, 
  CheckCheck, 
  Search, 
  School, 
  BookOpen, 
  Coins, 
  Send,
  FileSpreadsheet,
  Download,
  MessageSquare
} from 'lucide-react';
import { Pengajuan, Lembaga, CVProfile, StatusPengajuan } from '../../types/index.ts';
import { StatusBadge } from '../common/StatusBadge.tsx';
import { formatRupiah, formatDateIndo, arkasStorage } from '../../lib/storage.ts';
import { openWhatsAppDirect } from '../../utils/whatsapp.ts';
import { exportPengajuanToPdf } from '../../utils/exportPdf.ts';
import { POFinalWhatsAppModal } from '../common/POFinalWhatsAppModal.tsx';

interface Props {
  pengajuan: Pengajuan;
  lembaga: Lembaga;
  cvProfile: CVProfile;
  onClose: () => void;
  onSubmitReview: (pengajuanId: string, newStatus: StatusPengajuan, catatan: string) => void;
}

export const ReviewPengajuanModal: React.FC<Props> = ({
  pengajuan,
  lembaga,
  cvProfile,
  onClose,
  onSubmitReview
}) => {
  const [selectedStatus, setSelectedStatus] = useState<StatusPengajuan>('DISETUJUI');
  const [catatan, setCatatan] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [systemSettings] = useState(() => arkasStorage.getSystemSettings());
  const [notifyOperatorViaWa, setNotifyOperatorViaWa] = useState<boolean>(true);
  const [sendPdfToWaAdmin, setSendPdfToWaAdmin] = useState<boolean>(true);
  const [showPOFinalModal, setShowPOFinalModal] = useState<boolean>(false);
  const [reviewedPengajuan, setReviewedPengajuan] = useState<Pengajuan>(pengajuan);
  const [savedFinalNote, setSavedFinalNote] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    // Validasi catatan jika PERLU REVISI atau DITOLAK
    if ((selectedStatus === 'PERLU REVISI' || selectedStatus === 'DITOLAK') && !catatan.trim()) {
      setErrorMessage(
        selectedStatus === 'PERLU REVISI'
          ? 'Catatan revisi WAJIB diisi agar lembaga mengetahui bagian mana yang perlu diperbaiki.'
          : 'Alasan penolakan WAJIB diisi.'
      );
      return;
    }

    const defaultNotes = 
      selectedStatus === 'DISETUJUI' 
        ? (systemSettings.templateCatatanSetuju || 'Daftar kebutuhan buku telah diverifikasi sesuai dan disetujui untuk perencanaan anggaran ARKAS.') 
        : selectedStatus === 'SELESAI REKAP'
        ? 'Pengajuan telah difinalisasi dan dimasukkan ke dalam Rekapitulasi Rencana Kebutuhan Buku ARKAS.'
        : catatan.trim();

    const finalNote = catatan.trim() || defaultNotes;
    onSubmitReview(pengajuan.id, selectedStatus, finalNote);

    if (notifyOperatorViaWa && lembaga.whatsapp) {
      const waMsg = `📢 *UPDATE STATUS PENGAJUAN BUKU ARKAS*
────────────────────────
Yth. *${lembaga.operator || lembaga.namaLembaga}*,
Pengajuan kebutuhan buku Anda telah diverifikasi oleh Tim Admin *${cvProfile.namaCv}*:

• No. Pengajuan: *${pengajuan.nomorPengajuan}*
• Lembaga: *${lembaga.namaLembaga}*
• Status Baru: *${selectedStatus}*
• Catatan Tim Verifikasi CV:
"${finalNote}"

Silakan akses aplikasi web SIPOBU untuk melihat berkas dan menindaklanjuti. Terima kasih.`;
      openWhatsAppDirect(lembaga.whatsapp, waMsg);
    }

    if ((selectedStatus === 'DISETUJUI' || selectedStatus === 'SELESAI REKAP') && sendPdfToWaAdmin) {
      setReviewedPengajuan({
        ...pengajuan,
        status: selectedStatus,
        catatanCv: finalNote
      });
      setSavedFinalNote(finalNote);
      setShowPOFinalModal(true);
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 my-auto">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-blue-50/50 rounded-t-2xl">
          <div>
            <h3 className="font-bold text-slate-900 text-base">
              Verifikasi & Pemeriksaan Pengajuan Buku CV
            </h3>
            <p className="text-xs text-slate-500">
              Evaluasi pengajuan dari {lembaga.namaLembaga} ({pengajuan.nomorPengajuan})
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => exportPengajuanToPdf(pengajuan, lembaga, cvProfile)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs shadow-xs transition-colors"
              title="Unduh Rincian Pengajuan Format PDF"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs">
          {errorMessage && (
            <div className="p-3 rounded-lg bg-rose-50 border-l-4 border-rose-500 text-rose-700 font-semibold">
              {errorMessage}
            </div>
          )}

          {/* Ringkasan Pengajuan */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div>
              <span className="text-slate-400 block">Lembaga Pengaju:</span>
              <strong className="text-slate-900 text-sm block">{lembaga.namaLembaga}</strong>
              <span className="text-[11px] text-slate-500">NPSN: {lembaga.npsn} ({lembaga.kecamatan})</span>
            </div>
            <div>
              <span className="text-slate-400 block">Status Saat Ini:</span>
              <div className="mt-0.5">
                <StatusBadge status={pengajuan.status} size="sm" />
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">Tahun Anggaran: {pengajuan.tahunAnggaran}</span>
            </div>
            <div>
              <span className="text-slate-400 block">Total Rencana:</span>
              <strong className="text-blue-800 text-sm block">{formatRupiah(pengajuan.totalNilai)}</strong>
              <span className="text-[11px] text-slate-500">{pengajuan.totalBuku} Eksemplar ({pengajuan.totalJenisBuku} Judul)</span>
            </div>
          </div>

          {/* Rincian Buku */}
          <div>
            <h4 className="font-bold text-slate-800 mb-1.5 flex items-center justify-between">
              <span>Daftar Buku yang Diajukan</span>
              <span className="text-slate-400 font-normal">Pastikan harga dan jumlah sesuai ketentuan</span>
            </h4>
            <div className="border border-slate-200 rounded-xl overflow-hidden max-h-56 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-600 font-semibold uppercase sticky top-0 border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3 text-center w-8">No</th>
                    <th className="py-2 px-3">Judul Buku</th>
                    <th className="py-2 px-3">Jenjang/Kelas</th>
                    <th className="py-2 px-3 text-center">Jumlah</th>
                    <th className="py-2 px-3 text-right">Harga Satuan</th>
                    <th className="py-2 px-3 text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {pengajuan.items.map((it, idx) => (
                    <tr key={it.id} className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-center text-slate-500">{idx + 1}</td>
                      <td className="py-2 px-3 font-semibold text-slate-800">
                        {it.judul}
                        <span className="block text-[10px] text-slate-400 font-normal font-mono">
                          {it.kodeBuku} • ISBN: {it.isbn || '-'}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-slate-600">{it.jenjang} - {it.kelas}</td>
                      <td className="py-2 px-3 text-center font-bold text-slate-900">{it.jumlah} eks</td>
                      <td className="py-2 px-3 text-right text-slate-700">{formatRupiah(it.hargaSatuan)}</td>
                      <td className="py-2 px-3 text-right font-bold text-blue-700">{formatRupiah(it.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Form Pemilihan Status Verifikasi */}
          <form onSubmit={handleSubmit} className="space-y-4 pt-2 border-t border-slate-200">
            <div>
              <label className="block font-bold text-slate-800 mb-2">
                Pilih Keputusan Status Verifikasi CV *
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {/* 1. Setujui */}
                <button
                  type="button"
                  onClick={() => setSelectedStatus('DISETUJUI')}
                  className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    selectedStatus === 'DISETUJUI'
                      ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500/20 text-emerald-950'
                      : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    {selectedStatus === 'DISETUJUI' && <span className="text-[10px] font-bold text-emerald-600">Dipilih</span>}
                  </div>
                  <strong className="text-xs font-bold block">Setujui Pengajuan</strong>
                  <span className="text-[10px] text-slate-500 mt-0.5">Daftar buku sah & masuk rekap ARKAS</span>
                </button>

                {/* 2. Perlu Revisi */}
                <button
                  type="button"
                  onClick={() => setSelectedStatus('PERLU REVISI')}
                  className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    selectedStatus === 'PERLU REVISI'
                      ? 'bg-orange-50 border-orange-500 ring-2 ring-orange-500/20 text-orange-950'
                      : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <AlertCircle className="w-5 h-5 text-orange-600" />
                    {selectedStatus === 'PERLU REVISI' && <span className="text-[10px] font-bold text-orange-600">Dipilih</span>}
                  </div>
                  <strong className="text-xs font-bold block">Minta Revisi</strong>
                  <span className="text-[10px] text-slate-500 mt-0.5">Kembalikan ke sekolah dengan catatan</span>
                </button>

                {/* 3. Tolak */}
                <button
                  type="button"
                  onClick={() => setSelectedStatus('DITOLAK')}
                  className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    selectedStatus === 'DITOLAK'
                      ? 'bg-rose-50 border-rose-500 ring-2 ring-rose-500/20 text-rose-950'
                      : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <XCircle className="w-5 h-5 text-rose-600" />
                    {selectedStatus === 'DITOLAK' && <span className="text-[10px] font-bold text-rose-600">Dipilih</span>}
                  </div>
                  <strong className="text-xs font-bold block">Tolak Pengajuan</strong>
                  <span className="text-[10px] text-slate-500 mt-0.5">Pengajuan tidak memenuhi syarat</span>
                </button>

                {/* 4. Selesai Rekap */}
                <button
                  type="button"
                  onClick={() => setSelectedStatus('SELESAI REKAP')}
                  className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    selectedStatus === 'SELESAI REKAP'
                      ? 'bg-indigo-50 border-indigo-500 ring-2 ring-indigo-500/20 text-indigo-950'
                      : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <CheckCheck className="w-5 h-5 text-indigo-600" />
                    {selectedStatus === 'SELESAI REKAP' && <span className="text-[10px] font-bold text-indigo-600">Dipilih</span>}
                  </div>
                  <strong className="text-xs font-bold block">Selesai Rekap</strong>
                  <span className="text-[10px] text-slate-500 mt-0.5">Finalisasi pengajuan buku</span>
                </button>
              </div>
            </div>

            {/* Catatan / Alasan */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block font-bold text-slate-800 text-xs">
                  Catatan Verifikasi CV / Instruksi Revisi / Alasan Tolak:
                  {(selectedStatus === 'PERLU REVISI' || selectedStatus === 'DITOLAK') && (
                    <span className="text-rose-600 font-bold ml-1">* (Wajib Diisi)</span>
                  )}
                </label>
                {selectedStatus === 'PERLU REVISI' && systemSettings.templateCatatanRevisi && (
                  <button
                    type="button"
                    onClick={() => setCatatan(systemSettings.templateCatatanRevisi)}
                    className="text-[11px] text-blue-600 hover:text-blue-800 hover:underline font-semibold"
                  >
                    + Gunakan Template Revisi Super Admin
                  </button>
                )}
                {selectedStatus === 'DISETUJUI' && systemSettings.templateCatatanSetuju && (
                  <button
                    type="button"
                    onClick={() => setCatatan(systemSettings.templateCatatanSetuju)}
                    className="text-[11px] text-blue-600 hover:text-blue-800 hover:underline font-semibold"
                  >
                    + Gunakan Template Persetujuan Super Admin
                  </button>
                )}
              </div>
              <textarea
                rows={3}
                required={selectedStatus === 'PERLU REVISI' || selectedStatus === 'DITOLAK'}
                placeholder={
                  selectedStatus === 'PERLU REVISI'
                    ? 'Contoh: Mohon sesuaikan jumlah eksemplar buku pada item nomor 3 dengan jumlah siswa riil di Dapodik.'
                    : selectedStatus === 'DITOLAK'
                    ? 'Contoh: Judul buku yang diajukan bukan buku teks kurikulum yang diperbolehkan dianggarkan melalui ARKAS reguler.'
                    : 'Catatan konfirmasi persetujuan untuk lembaga (opsional)...'
                }
                value={catatan}
                onChange={(e) => setCatatan(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>

            {/* Opsi Kirim Berkas PDF PO Otomatis ke WA Admin CV */}
            {(selectedStatus === 'DISETUJUI' || selectedStatus === 'SELESAI REKAP') && (
              <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-200 flex items-center justify-between gap-3 text-xs">
                <label className="flex items-center gap-2 cursor-pointer font-medium text-blue-950 select-none">
                  <input
                    type="checkbox"
                    checked={sendPdfToWaAdmin}
                    onChange={(e) => setSendPdfToWaAdmin(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300"
                  />
                  <span className="flex items-center gap-1.5">
                    <Download className="w-3.5 h-3.5 text-blue-600" />
                    <span>
                      <strong>Otomatis Unduh & Kirim Berkas PDF PO ke WhatsApp Admin CV</strong> ({systemSettings.nomorWaAdmin || cvProfile.whatsapp})
                    </span>
                  </span>
                </label>
              </div>
            )}

            {/* Opsi Kirim Notifikasi WA ke Operator */}
            <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200 flex items-center justify-between gap-3 text-xs">
              <label className="flex items-center gap-2 cursor-pointer font-medium text-emerald-950 select-none">
                <input
                  type="checkbox"
                  checked={notifyOperatorViaWa}
                  onChange={(e) => setNotifyOperatorViaWa(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
                />
                <span className="flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Kirim otomatis hasil verifikasi ke WhatsApp Operator ({lembaga.operator || 'Sekolah'} - {lembaga.whatsapp})</span>
                </span>
              </label>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
              >
                Batal
              </button>

              <button
                type="submit"
                className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-white font-semibold shadow-md transition-all ${
                  selectedStatus === 'DISETUJUI'
                    ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20'
                    : selectedStatus === 'PERLU REVISI'
                    ? 'bg-orange-600 hover:bg-orange-700 shadow-orange-600/20'
                    : selectedStatus === 'DITOLAK'
                    ? 'bg-rose-600 hover:bg-rose-700 shadow-rose-600/20'
                    : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-600/20'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>Simpan Keputusan Status</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Modal Otomatisasi Kirim Berkas PDF PO ke WA Admin CV */}
      {showPOFinalModal && (
        <POFinalWhatsAppModal
          isOpen={showPOFinalModal}
          onClose={() => {
            setShowPOFinalModal(false);
            onClose();
          }}
          pengajuan={reviewedPengajuan}
          lembaga={lembaga}
          cvProfile={cvProfile}
          systemSettings={systemSettings}
          catatanReview={savedFinalNote}
          autoTrigger={true}
        />
      )}
    </div>
  );
};
