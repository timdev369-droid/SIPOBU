import React, { useState } from 'react';
import { 
  Library, 
  Plus, 
  Search, 
  Edit3, 
  CheckCircle, 
  XCircle, 
  Filter, 
  BookOpen, 
  X,
  FileSpreadsheet
} from 'lucide-react';
import { Buku, JenjangPendidikan } from '../../types/index.ts';
import { arkasStorage, formatRupiah } from '../../lib/storage.ts';
import { ImportMasterBukuModal } from './ImportMasterBukuModal.tsx';

export const MasterBukuView: React.FC = () => {
  const [bukuList, setBukuList] = useState<Buku[]>(arkasStorage.getAllBuku());
  const [search, setSearch] = useState('');
  const [filterJenjang, setFilterJenjang] = useState<string>('Semua');
  const [filterKurikulum, setFilterKurikulum] = useState<string>('Semua');

  // Modal Form State
  const [showModal, setShowModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [editingBuku, setEditingBuku] = useState<Buku | null>(null);

  const [formData, setFormData] = useState<{
    kodeBuku: string;
    isbn: string;
    judul: string;
    penulis: string;
    penerbit: string;
    jenjang: JenjangPendidikan;
    kelas: string;
    mataPelajaran: string;
    kurikulum: 'Kurikulum Merdeka' | 'Kurikulum 2013' | 'Lainnya';
    hargaReferensi: number;
    satuan: string;
    status: 'ACTIVE' | 'INACTIVE';
  }>({
    kodeBuku: '',
    isbn: '',
    judul: '',
    penulis: '',
    penerbit: 'Pusat Perbukuan Kemdikbudristek',
    jenjang: 'SD',
    kelas: 'Kelas 1',
    mataPelajaran: '',
    kurikulum: 'Kurikulum Merdeka',
    hargaReferensi: 25000,
    satuan: 'Eksemplar',
    status: 'ACTIVE'
  });

  const refreshList = () => {
    setBukuList(arkasStorage.getAllBuku());
  };

  const handleOpenAdd = () => {
    setEditingBuku(null);
    setFormData({
      kodeBuku: `BK-KM-${Math.floor(100 + Math.random() * 900)}`,
      isbn: '978-602-244-',
      judul: '',
      penulis: '',
      penerbit: 'Pusat Perbukuan Kemdikbudristek',
      jenjang: 'SD',
      kelas: 'Kelas 1',
      mataPelajaran: '',
      kurikulum: 'Kurikulum Merdeka',
      hargaReferensi: 25000,
      satuan: 'Eksemplar',
      status: 'ACTIVE'
    });
    setShowModal(true);
  };

  const handleOpenEdit = (b: Buku) => {
    setEditingBuku(b);
    setFormData({
      kodeBuku: b.kodeBuku,
      isbn: b.isbn,
      judul: b.judul,
      penulis: b.penulis,
      penerbit: b.penerbit,
      jenjang: b.jenjang,
      kelas: b.kelas,
      mataPelajaran: b.mataPelajaran,
      kurikulum: b.kurikulum as any,
      hargaReferensi: b.hargaReferensi,
      satuan: b.satuan,
      status: b.status
    });
    setShowModal(true);
  };

  const handleToggleStatus = (id: string) => {
    arkasStorage.toggleBukuStatus(id);
    refreshList();
  };

  const handleSaveBuku = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.judul.trim() || !formData.kodeBuku.trim()) {
      alert('Kode buku dan judul buku wajib diisi.');
      return;
    }

    arkasStorage.saveBuku({
      ...formData,
      id: editingBuku ? editingBuku.id : undefined
    });

    setShowModal(false);
    refreshList();
  };

  // Filter
  const filtered = bukuList.filter(b => {
    const q = search.toLowerCase();
    const matchesSearch = 
      b.judul.toLowerCase().includes(q) ||
      b.isbn.toLowerCase().includes(q) ||
      b.kodeBuku.toLowerCase().includes(q) ||
      b.penerbit.toLowerCase().includes(q) ||
      b.mataPelajaran.toLowerCase().includes(q);

    const matchesJenjang = filterJenjang === 'Semua' || b.jenjang === filterJenjang;
    const matchesKurikulum = filterKurikulum === 'Semua' || b.kurikulum === filterKurikulum;

    return matchesSearch && matchesJenjang && matchesKurikulum;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Library className="w-5 h-5 text-blue-600" />
            <span>Master Data Katalog Buku Referensi ARKAS</span>
          </h2>
          <p className="text-xs text-slate-500">
            Kelola daftar buku resmi Kurikulum Merdeka & 2013 yang dapat dipilih oleh sekolah saat mengajukan kebutuhan.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
          <button
            onClick={() => setShowImportModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-md transition-all"
            title="Impor Master Buku format: NO • JUDUL BUKU • KETERANGAN • HARGA • DIPESAN • JUMLAH"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Impor Format Excel / TSV</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-md transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Buku Baru</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3 text-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Cari berdasarkan judul, ISBN, penerbit, kode buku, atau mata pelajaran..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={filterJenjang}
            onChange={(e) => setFilterJenjang(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium"
          >
            <option value="Semua">Semua Jenjang</option>
            <option value="SD">SD</option>
            <option value="SMP">SMP</option>
            <option value="SMA">SMA</option>
            <option value="SMK">SMK</option>
            <option value="PAUD">PAUD</option>
            <option value="TK">TK</option>
          </select>

          <select
            value={filterKurikulum}
            onChange={(e) => setFilterKurikulum(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium"
          >
            <option value="Semua">Semua Kurikulum</option>
            <option value="Kurikulum Merdeka">Kurikulum Merdeka</option>
            <option value="Kurikulum 2013">Kurikulum 2013</option>
          </select>
        </div>
      </div>

      {/* Tabel Master Buku */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 w-12 text-center">No</th>
                <th className="py-3 px-4">Kode & ISBN</th>
                <th className="py-3 px-4 min-w-[240px]">Judul Buku & Penulis</th>
                <th className="py-3 px-4">Penerbit</th>
                <th className="py-3 px-4">Jenjang & Kelas</th>
                <th className="py-3 px-4">Kurikulum</th>
                <th className="py-3 px-4 text-right">Harga Referensi</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    Tidak ditemukan data buku dalam master katalog.
                  </td>
                </tr>
              ) : (
                filtered.map((b, idx) => (
                  <tr key={b.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 text-center text-slate-500 font-medium">{idx + 1}</td>
                    <td className="py-3 px-4">
                      <span className="font-mono font-semibold text-blue-700 block">{b.kodeBuku}</span>
                      <span className="font-mono text-[10px] text-slate-400">ISBN: {b.isbn}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 leading-snug">{b.judul}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        Penulis: {b.penulis} • Mapel: <strong>{b.mataPelajaran}</strong>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{b.penerbit}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded bg-slate-100 font-semibold text-slate-700 text-[10px]">
                        {b.jenjang} - {b.kelas}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-slate-600">{b.kurikulum}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-slate-900">
                      {formatRupiah(b.hargaReferensi)}
                      <span className="block text-[10px] text-slate-400 font-normal">/{b.satuan}</span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => handleToggleStatus(b.id)}
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold transition-colors ${
                          b.status === 'ACTIVE'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                            : 'bg-slate-100 text-slate-500 border border-slate-300 hover:bg-slate-200'
                        }`}
                        title="Klik untuk ubah status aktif/nonaktif"
                      >
                        {b.status === 'ACTIVE' ? <CheckCircle className="w-3 h-3 text-emerald-600" /> : <XCircle className="w-3 h-3 text-slate-400" />}
                        <span>{b.status === 'ACTIVE' ? 'Aktif' : 'Nonaktif'}</span>
                      </button>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => handleOpenEdit(b)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                        title="Ubah Data Buku"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL FORM TAMBAH / UBAH BUKU */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base">
                {editingBuku ? 'Edit Data Buku Referensi' : 'Tambah Buku Baru ke Master'}
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBuku} className="space-y-4 pt-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kode Buku *</label>
                  <input
                    type="text"
                    required
                    value={formData.kodeBuku}
                    onChange={(e) => setFormData({ ...formData, kodeBuku: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">ISBN *</label>
                  <input
                    type="text"
                    required
                    value={formData.isbn}
                    onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Judul Buku Lengkap *</label>
                <input
                  type="text"
                  required
                  value={formData.judul}
                  onChange={(e) => setFormData({ ...formData, judul: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Penulis</label>
                  <input
                    type="text"
                    value={formData.penulis}
                    onChange={(e) => setFormData({ ...formData, penulis: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Penerbit *</label>
                  <input
                    type="text"
                    required
                    value={formData.penerbit}
                    onChange={(e) => setFormData({ ...formData, penerbit: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenjang</label>
                  <select
                    value={formData.jenjang}
                    onChange={(e) => setFormData({ ...formData, jenjang: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  >
                    <option value="SD">SD</option>
                    <option value="SMP">SMP</option>
                    <option value="SMA">SMA</option>
                    <option value="SMK">SMK</option>
                    <option value="PAUD">PAUD</option>
                    <option value="TK">TK</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kelas</label>
                  <input
                    type="text"
                    value={formData.kelas}
                    onChange={(e) => setFormData({ ...formData, kelas: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Mata Pelajaran</label>
                  <input
                    type="text"
                    value={formData.mataPelajaran}
                    onChange={(e) => setFormData({ ...formData, mataPelajaran: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kurikulum</label>
                  <select
                    value={formData.kurikulum}
                    onChange={(e) => setFormData({ ...formData, kurikulum: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  >
                    <option value="Kurikulum Merdeka">Kurikulum Merdeka</option>
                    <option value="Kurikulum 2013">Kurikulum 2013</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Harga Referensi (Rp) *</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.hargaReferensi}
                    onChange={(e) => setFormData({ ...formData, hargaReferensi: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Satuan</label>
                  <input
                    type="text"
                    value={formData.satuan}
                    onChange={(e) => setFormData({ ...formData, satuan: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-xs"
                >
                  Simpan Buku
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Impor Master Buku Format NO JUDUL BUKU KETERANGAN HARGA DIPESAN JUMLAH */}
      {showImportModal && (
        <ImportMasterBukuModal
          onClose={() => setShowImportModal(false)}
          onSuccess={() => {
            refreshList();
          }}
        />
      )}
    </div>
  );
};
