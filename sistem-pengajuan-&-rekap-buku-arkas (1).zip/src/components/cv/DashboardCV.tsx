import React, { useState } from 'react';
import { 
  Building2, 
  FileText, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  XCircle, 
  Layers, 
  BookOpen, 
  Coins, 
  School, 
  MapPin, 
  BarChart, 
  TrendingUp, 
  Eye, 
  Download, 
  Check, 
  Filter,
  FileSpreadsheet,
  PieChart,
  Settings
} from 'lucide-react';
import { Pengajuan, Lembaga, CVProfile } from '../../types/index.ts';
import { StatusBadge } from '../common/StatusBadge.tsx';
import { formatRupiah, formatDateIndo } from '../../lib/storage.ts';

interface Props {
  pengajuanList: Pengajuan[];
  lembagaList: Lembaga[];
  cvProfile: CVProfile;
  onViewDetail: (pengajuan: Pengajuan) => void;
  onReviewPengajuan: (pengajuan: Pengajuan) => void;
  onNavigateTab: (tab: string) => void;
}

export const DashboardCV: React.FC<Props> = ({
  pengajuanList,
  lembagaList,
  cvProfile,
  onViewDetail,
  onReviewPengajuan,
  onNavigateTab
}) => {
  // Metrik Statistik Utama (Requirement 10)
  const totalLembaga = lembagaList.length;
  const totalPengajuan = pengajuanList.length;
  const menungguCount = pengajuanList.filter(p => p.status === 'DIKIRIM LEMBAGA' || p.status === 'DIPERIKSA CV').length;
  const revisiCount = pengajuanList.filter(p => p.status === 'PERLU REVISI').length;
  const disetujuiCount = pengajuanList.filter(p => p.status === 'DISETUJUI' || p.status === 'SELESAI REKAP').length;
  const ditolakCount = pengajuanList.filter(p => p.status === 'DITOLAK').length;

  const totalJenisBuku = pengajuanList.reduce((acc, p) => acc + p.totalJenisBuku, 0);
  const totalBuku = pengajuanList.reduce((acc, p) => acc + p.totalBuku, 0);
  const totalNilaiRencana = pengajuanList.reduce((acc, p) => acc + p.totalNilai, 0);

  // Perhitungan Data Grafik:
  // 1. Pengajuan per Jenjang
  const jenjangCounts: Record<string, number> = { SD: 0, SMP: 0, SMA: 0, SMK: 0, PAUD: 0, TK: 0, Lainnya: 0 };
  pengajuanList.forEach(p => {
    const lem = lembagaList.find(l => l.id === p.lembagaId);
    if (lem && jenjangCounts[lem.jenjang] !== undefined) {
      jenjangCounts[lem.jenjang] += p.totalBuku;
    } else {
      jenjangCounts['Lainnya'] += p.totalBuku;
    }
  });

  // 2. Pengajuan per Kecamatan
  const kecamatanMap: Record<string, { totalBuku: number; totalNilai: number; count: number }> = {};
  pengajuanList.forEach(p => {
    const lem = lembagaList.find(l => l.id === p.lembagaId);
    const kec = lem ? lem.kecamatan : 'Tidak Diketahui';
    if (!kecamatanMap[kec]) {
      kecamatanMap[kec] = { totalBuku: 0, totalNilai: 0, count: 0 };
    }
    kecamatanMap[kec].totalBuku += p.totalBuku;
    kecamatanMap[kec].totalNilai += p.totalNilai;
    kecamatanMap[kec].count += 1;
  });

  // 3. Top Lembaga Berdasarkan Nilai Rencana
  const lembagaNilaiList = lembagaList.map(lem => {
    const pList = pengajuanList.filter(p => p.lembagaId === lem.id);
    const sumNilai = pList.reduce((acc, p) => acc + p.totalNilai, 0);
    const sumBuku = pList.reduce((acc, p) => acc + p.totalBuku, 0);
    return {
      lembaga: lem,
      totalNilai: sumNilai,
      totalBuku: sumBuku,
      pengajuanCount: pList.length
    };
  }).sort((a, b) => b.totalNilai - a.totalNilai);

  // Pengajuan Butuh Tindakan (DIKIRIM LEMBAGA)
  const pendingQueue = pengajuanList.filter(p => p.status === 'DIKIRIM LEMBAGA' || p.status === 'DIPERIKSA CV');

  return (
    <div className="space-y-6">
      {/* Banner Selamat Datang CV */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 rounded-2xl p-6 text-white shadow-xl border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold ring-1 ring-blue-400/30">
              <Building2 className="w-3.5 h-3.5" />
              <span>Portal CV Penyedia SIPLah (1 CV Multi-Lembaga)</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              {cvProfile.namaCv}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Dasbor kendali verifikasi kebutuhan buku sekolah untuk perencanaan ARKAS. Pantau, periksa, setujui, dan rekap pengajuan dari seluruh lembaga mitra.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateTab('pengajuan-masuk')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md transition-all"
            >
              <span>Periksa Pengajuan Masuk</span>
              {menungguCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-white text-blue-900 font-bold text-[10px]">
                  {menungguCount}
                </span>
              )}
            </button>
            <button
              onClick={() => onNavigateTab('rekap-pengajuan')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>Rekapitulasi</span>
            </button>
            <button
              onClick={() => onNavigateTab('pengaturan')}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-semibold text-xs border border-amber-500/40 transition-colors"
              title="Pusat Pengaturan Super Admin"
            >
              <Settings className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Pengaturan Super Admin</span>
              <span className="sm:hidden">Admin</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid Statistik Sesuai Requirement 10 */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Total Lembaga</span>
            <School className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{totalLembaga}</div>
          <span className="text-[10px] text-slate-400">Sekolah terdaftar</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Total Pengajuan</span>
            <FileText className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{totalPengajuan}</div>
          <span className="text-[10px] text-slate-400">Semua status</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-blue-200 bg-blue-50/40 shadow-xs">
          <div className="flex items-center justify-between text-blue-800 mb-1">
            <span className="text-xs font-semibold">Menunggu Review</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-blue-700">{menungguCount}</div>
          <span className="text-[10px] text-blue-600/80 font-medium">Perlu tindakan CV</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-orange-200 bg-orange-50/40 shadow-xs">
          <div className="flex items-center justify-between text-orange-800 mb-1">
            <span className="text-xs font-semibold">Perlu Revisi</span>
            <AlertCircle className="w-4 h-4 text-orange-600" />
          </div>
          <div className="text-2xl font-bold text-orange-700">{revisiCount}</div>
          <span className="text-[10px] text-orange-600">Menunggu revisi sekolah</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-200 bg-emerald-50/40 shadow-xs">
          <div className="flex items-center justify-between text-emerald-800 mb-1">
            <span className="text-xs font-semibold">Disetujui</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-700">{disetujuiCount}</div>
          <span className="text-[10px] text-emerald-600">Masuk Rekap ARKAS</span>
        </div>
      </div>

      {/* Rangkuman Nilai & Volume Buku (Requirement 10) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-violet-600 text-white flex items-center justify-center shadow-md shadow-violet-600/20 shrink-0">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Jenis Buku</div>
            <div className="text-2xl font-bold text-slate-900 mt-0.5">{totalJenisBuku} Judul</div>
            <div className="text-xs text-slate-400">Variasi judul buku dipesan</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-md shadow-sky-600/20 shrink-0">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Eksemplar Buku</div>
            <div className="text-2xl font-bold text-slate-900 mt-0.5">{totalBuku.toLocaleString('id-ID')} Eks</div>
            <div className="text-xs text-slate-400">Total volume kebutuhan buku</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20 shrink-0">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Nilai Rencana ARKAS</div>
            <div className="text-2xl font-extrabold text-blue-900 mt-0.5">{formatRupiah(totalNilaiRencana)}</div>
            <div className="text-xs text-slate-400">Estimasi total kebutuhan buku</div>
          </div>
        </div>
      </div>

      {/* Visual Analytics / Grafik Sesuai Requirement 10 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Grafik 1: Kebutuhan Buku per Jenjang */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <BarChart className="w-4 h-4 text-blue-600" />
                <span>Distribusi Kebutuhan Buku per Jenjang</span>
              </h3>
              <p className="text-xs text-slate-500">Total eksemplar buku per jenjang pendidikan</p>
            </div>
            <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2 py-1 rounded">
              {totalBuku} Eks
            </span>
          </div>

          <div className="space-y-3 pt-2 text-xs">
            {Object.entries(jenjangCounts).map(([jenjang, qty]) => {
              const pct = totalBuku > 0 ? Math.round((qty / totalBuku) * 100) : 0;
              return (
                <div key={jenjang} className="space-y-1">
                  <div className="flex justify-between font-medium">
                    <span className="text-slate-700 font-semibold">{jenjang}</span>
                    <span className="text-slate-900 font-bold">{qty.toLocaleString('id-ID')} Eks ({pct}%)</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${
                        jenjang === 'SD' ? 'bg-blue-600' :
                        jenjang === 'SMP' ? 'bg-sky-500' :
                        jenjang === 'SMA' ? 'bg-indigo-600' :
                        jenjang === 'SMK' ? 'bg-teal-500' :
                        jenjang === 'PAUD' || jenjang === 'TK' ? 'bg-amber-500' : 'bg-slate-400'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Grafik 2: Kebutuhan Buku per Kecamatan */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span>Pengajuan per Wilayah / Kecamatan</span>
              </h3>
              <p className="text-xs text-slate-500">Rencana nilai anggaran kebutuhan buku per kecamatan</p>
            </div>
          </div>

          <div className="space-y-3 pt-2 text-xs">
            {Object.entries(kecamatanMap).map(([kec, val]) => {
              const pct = totalNilaiRencana > 0 ? Math.round((val.totalNilai / totalNilaiRencana) * 100) : 0;
              return (
                <div key={kec} className="space-y-1">
                  <div className="flex justify-between font-medium">
                    <span className="text-slate-700 font-semibold">{kec} ({val.count} Pengajuan)</span>
                    <span className="text-blue-900 font-bold">{formatRupiah(val.totalNilai)} ({pct}%)</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-emerald-600 rounded-full" 
                      style={{ width: `${pct}%` }} 
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Antrean Pengajuan Butuh Tindakan CV Segera */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-blue-50/30">
          <div>
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600" />
              <span>Antrean Pengajuan Menunggu Pemeriksaan CV</span>
            </h3>
            <p className="text-xs text-slate-500">
              Daftar pengajuan masuk dari sekolah yang perlu Anda setujui, revisi, atau tolak.
            </p>
          </div>
          <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-blue-100 text-blue-800">
            {pendingQueue.length} Pengajuan Menunggu
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Lembaga / Sekolah</th>
                <th className="py-3 px-4">Nomor & Tanggal</th>
                <th className="py-3 px-4">Jenjang & Kecamatan</th>
                <th className="py-3 px-4 text-right">Volume Buku</th>
                <th className="py-3 px-4 text-right">Nilai Rencana</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Aksi Verifikasi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {pendingQueue.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    <CheckCircle2 className="w-7 h-7 mx-auto text-emerald-500 mb-1" />
                    Semua pengajuan telah diperiksa. Tidak ada pengajuan yang mengantre!
                  </td>
                </tr>
              ) : (
                pendingQueue.map((p) => {
                  const lem = lembagaList.find(l => l.id === p.lembagaId);
                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-semibold text-slate-900">
                        {lem ? lem.namaLembaga : 'Lembaga'}
                        <div className="text-[11px] text-slate-400 font-normal">
                          NPSN: {lem ? lem.npsn : '-'} • KS: {lem ? lem.kepalaSekolah : '-'}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-mono font-semibold text-blue-700 block">
                          {p.nomorPengajuan}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {formatDateIndo(p.tanggalPengajuan)}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700">
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 font-medium text-[10px] mr-1">
                          {lem ? lem.jenjang : '-'}
                        </span>
                        {lem ? lem.kecamatan : '-'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-medium text-slate-900">
                        {p.totalBuku.toLocaleString('id-ID')} Eks
                        <span className="block text-[10px] text-slate-400">({p.totalJenisBuku} judul)</span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                        {formatRupiah(p.totalNilai)}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <StatusBadge status={p.status} size="sm" />
                      </td>
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => onViewDetail(p)}
                            className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5 inline mr-1" />
                            Detail
                          </button>
                          <button
                            onClick={() => onReviewPengajuan(p)}
                            className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors"
                          >
                            Periksa & Verifikasi →
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
