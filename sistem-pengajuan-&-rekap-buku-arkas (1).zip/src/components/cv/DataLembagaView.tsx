import React, { useState } from 'react';
import { 
  School, 
  Search, 
  MapPin, 
  Phone, 
  Mail, 
  UserCheck, 
  FileText, 
  ExternalLink,
  Coins
} from 'lucide-react';
import { Lembaga, Pengajuan } from '../../types/index.ts';
import { formatRupiah } from '../../lib/storage.ts';

interface Props {
  lembagaList: Lembaga[];
  pengajuanList: Pengajuan[];
  onSelectLembaga: (lembagaId: string) => void;
}

export const DataLembagaView: React.FC<Props> = ({
  lembagaList,
  pengajuanList,
  onSelectLembaga
}) => {
  const [search, setSearch] = useState('');
  const [filterJenjang, setFilterJenjang] = useState('Semua');
  const [filterKecamatan, setFilterKecamatan] = useState('Semua');

  // Ambil list unik kecamatan
  const kecamatanOptions = Array.from(new Set(lembagaList.map(l => l.kecamatan)));

  const filtered = lembagaList.filter(l => {
    const q = search.toLowerCase();
    const matchSearch = 
      l.namaLembaga.toLowerCase().includes(q) ||
      l.npsn.includes(q) ||
      l.kepalaSekolah.toLowerCase().includes(q) ||
      l.operator.toLowerCase().includes(q) ||
      l.kecamatan.toLowerCase().includes(q);

    const matchJenjang = filterJenjang === 'Semua' || l.jenjang === filterJenjang;
    const matchKecamatan = filterKecamatan === 'Semua' || l.kecamatan === filterKecamatan;

    return matchSearch && matchJenjang && matchKecamatan;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <School className="w-5 h-5 text-blue-600" />
            <span>Data Seluruh Lembaga / Satuan Pendidikan Mitra</span>
          </h2>
          <p className="text-xs text-slate-500">
            Daftar sekolah yang terdaftar dan mengajukan kebutuhan buku ARKAS ke CV ({lembagaList.length} lembaga terdaftar).
          </p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3 text-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Cari nama sekolah, NPSN, kepala sekolah, atau operator..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={filterJenjang}
            onChange={(e) => setFilterJenjang(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium"
          >
            <option value="Semua">Semua Jenjang</option>
            <option value="SD">SD</option>
            <option value="SMP">SMP</option>
            <option value="SMA">SMA</option>
            <option value="SMK">SMK</option>
            <option value="PAUD">PAUD</option>
            <option value="TK">TK</option>
          </select>

          <select
            value={filterKecamatan}
            onChange={(e) => setFilterKecamatan(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium"
          >
            <option value="Semua">Semua Kecamatan</option>
            {kecamatanOptions.map(kec => (
              <option key={kec} value={kec}>{kec}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Grid Card Lembaga */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(lem => {
          const lemPengajuan = pengajuanList.filter(p => p.lembagaId === lem.id);
          const totalNilai = lemPengajuan.reduce((acc, p) => acc + p.totalNilai, 0);
          const totalBuku = lemPengajuan.reduce((acc, p) => acc + p.totalBuku, 0);

          return (
            <div key={lem.id} className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 hover:border-blue-300 transition-all space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold text-[10px] border border-blue-200">
                      {lem.jenjang}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-medium text-[10px]">
                      {lem.statusLembaga}
                    </span>
                    <span className="font-mono text-[11px] text-slate-500 font-semibold">
                      NPSN: {lem.npsn}
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-900 text-base">
                    {lem.namaLembaga}
                  </h3>
                  <p className="text-xs text-slate-500 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{lem.alamat}, Ds. {lem.desa}, Kec. {lem.kecamatan}, Kab. {lem.kabupaten}</span>
                  </p>
                </div>

                <button
                  onClick={() => onSelectLembaga(lem.id)}
                  className="px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold text-xs transition-colors shrink-0"
                >
                  Lihat Rekap
                </button>
              </div>

              {/* Rincian Kontak & Pimpinan */}
              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div>
                  <span className="text-[10px] text-slate-400 block">Kepala Sekolah:</span>
                  <strong className="text-slate-800 text-[11px] block">{lem.kepalaSekolah}</strong>
                  {lem.nipKepalaSekolah && <span className="text-[10px] text-slate-400">NIP: {lem.nipKepalaSekolah}</span>}
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Operator Sekolah:</span>
                  <strong className="text-slate-800 text-[11px] block">{lem.operator}</strong>
                  <span className="text-[10px] text-slate-500">WA: {lem.whatsapp}</span>
                </div>
              </div>

              {/* Ringkasan Anggaran Pengajuan */}
              <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100">
                <div className="flex items-center gap-3">
                  <span className="text-slate-500">
                    <strong className="text-slate-900">{lemPengajuan.length}</strong> Pengajuan
                  </span>
                  <span className="text-slate-300">•</span>
                  <span className="text-slate-500">
                    <strong className="text-slate-900">{totalBuku.toLocaleString('id-ID')}</strong> Eks
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Total Pagu Rencana:</span>
                  <strong className="text-blue-800 font-bold">{formatRupiah(totalNilai)}</strong>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
