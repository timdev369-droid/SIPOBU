import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Calendar, 
  PlusCircle, 
  Filter, 
  RotateCcw, 
  Eye, 
  FileEdit, 
  Download, 
  FileSpreadsheet, 
  Clock, 
  AlertCircle,
  X,
  Layers,
  Coins
} from 'lucide-react';
import { Pengajuan, Lembaga, CVProfile, StatusPengajuan } from '../../types/index.ts';
import { StatusBadge } from '../common/StatusBadge.tsx';
import { formatRupiah, formatDateIndo } from '../../lib/storage.ts';
import { exportPengajuanToPdf } from '../../utils/exportPdf.ts';
import { exportSinglePengajuanToExcel } from '../../utils/exportExcel.ts';
import { MessageSquare } from 'lucide-react';
import { POFinalWhatsAppModal } from '../common/POFinalWhatsAppModal.tsx';
import { arkasStorage } from '../../lib/storage.ts';

interface Props {
  lembaga: Lembaga;
  cvProfile: CVProfile;
  pengajuanList: Pengajuan[];
  title?: string;
  onCreateNew: () => void;
  onViewDetail: (pengajuan: Pengajuan) => void;
  onEditPengajuan: (pengajuan: Pengajuan) => void;
}

export const RiwayatPengajuanLembaga: React.FC<Props> = ({
  lembaga,
  cvProfile,
  pengajuanList,
  title = 'Riwayat & Daftar Pengajuan Buku Sekolah',
  onCreateNew,
  onViewDetail,
  onEditPengajuan
}) => {
  // Real-time search by nomor pengajuan or keyword
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Date range filters
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Additional status & tahun filter
  const [statusFilter, setStatusFilter] = useState<string>('Semua');
  const [tahunFilter, setTahunFilter] = useState<string>('Semua');
  const [selectedPOForWhatsApp, setSelectedPOForWhatsApp] = useState<Pengajuan | null>(null);

  // Tahun anggaran options
  const tahunOptions = useMemo(() => {
    return Array.from(new Set(pengajuanList.map(p => p.tahunAnggaran))).sort().reverse();
  }, [pengajuanList]);

  // Quick Date Range Presets
  const handleQuickPreset = (preset: 'all' | 'this_month' | 'last_30' | 'this_year') => {
    const today = new Date();
    const toDateStr = (d: Date) => d.toISOString().split('T')[0];

    if (preset === 'all') {
      setStartDate('');
      setEndDate('');
    } else if (preset === 'this_month') {
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      setStartDate(toDateStr(firstDay));
      setEndDate(toDateStr(today));
    } else if (preset === 'last_30') {
      const past30 = new Date();
      past30.setDate(today.getDate() - 30);
      setStartDate(toDateStr(past30));
      setEndDate(toDateStr(today));
    } else if (preset === 'this_year') {
      const firstDayYear = new Date(today.getFullYear(), 0, 1);
      setStartDate(toDateStr(firstDayYear));
      setEndDate(toDateStr(today));
    }
  };

  const resetAllFilters = () => {
    setSearchQuery('');
    setStartDate('');
    setEndDate('');
    setStatusFilter('Semua');
    setTahunFilter('Semua');
  };

  const isFiltering = !!(searchQuery || startDate || endDate || statusFilter !== 'Semua' || tahunFilter !== 'Semua');

  // Real-time filtering logic
  const filteredList = useMemo(() => {
    return pengajuanList.filter(p => {
      // 1. Search Query (Nomor Pengajuan, Keterangan Umum, Judul Buku)
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const matchNomor = p.nomorPengajuan.toLowerCase().includes(q);
        const matchKeterangan = (p.keteranganUmum || '').toLowerCase().includes(q);
        const matchTahun = p.tahunAnggaran.includes(q);
        const matchBuku = p.items.some(it => 
          it.judul.toLowerCase().includes(q) ||
          it.kodeBuku.toLowerCase().includes(q) ||
          (it.isbn && it.isbn.includes(q))
        );

        if (!matchNomor && !matchKeterangan && !matchTahun && !matchBuku) {
          return false;
        }
      }

      // 2. Rentang Tanggal Pengajuan
      const itemDate = p.tanggalPengajuan; // Format: YYYY-MM-DD
      if (startDate && itemDate < startDate) {
        return false;
      }
      if (endDate && itemDate > endDate) {
        return false;
      }

      // 3. Status Filter
      if (statusFilter !== 'Semua' && p.status !== statusFilter) {
        return false;
      }

      // 4. Tahun Anggaran Filter
      if (tahunFilter !== 'Semua' && p.tahunAnggaran !== tahunFilter) {
        return false;
      }

      return true;
    });
  }, [pengajuanList, searchQuery, startDate, endDate, statusFilter, tahunFilter]);

  // Akumulasi metrik dari hasil filter real-time
  const totalBukuFiltered = useMemo(() => {
    return filteredList.reduce((acc, p) => acc + p.totalBuku, 0);
  }, [filteredList]);

  const totalNilaiFiltered = useMemo(() => {
    return filteredList.reduce((acc, p) => acc + p.totalNilai, 0);
  }, [filteredList]);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600" />
            <span>{title}</span>
          </h2>
          <p className="text-xs text-slate-500">
            Cari pengajuan berdasarkan nomor pengajuan atau rentang tanggal secara real-time.
          </p>
        </div>

        <button
          onClick={onCreateNew}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>+ Ajukan Buku Baru</span>
        </button>
      </div>

      {/* Real-time Search & Filter Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4 text-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2 font-bold text-slate-800 text-xs">
            <Filter className="w-4 h-4 text-blue-600" />
            <span>Pencarian & Filter Pengajuan Lembaga</span>
          </div>

          {isFiltering && (
            <button
              onClick={resetAllFilters}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-3 py-1 rounded-lg transition-colors self-start md:self-auto"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Semua Filter</span>
            </button>
          )}
        </div>

        {/* Input Baris 1: Pencarian Nomor Pengajuan & Keyword */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
          <div className="lg:col-span-6 relative">
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">
              Cari Nomor Pengajuan atau Kata Kunci (Real-time):
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Ketik nomor pengajuan (misal: PB-2026-0001) atau judul buku..."
                className="w-full pl-9 pr-9 py-2 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-medium placeholder:text-slate-400 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 p-0.5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Filter Status */}
          <div className="lg:col-span-3">
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">
              Status Pengajuan:
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-slate-800 font-medium focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            >
              <option value="Semua">Semua Status ({pengajuanList.length})</option>
              <option value="DIKIRIM LEMBAGA">Menunggu CV</option>
              <option value="DIPERIKSA CV">Diperiksa CV</option>
              <option value="PERLU REVISI">Perlu Revisi</option>
              <option value="DISETUJUI">Disetujui</option>
              <option value="SELESAI REKAP">Selesai Rekap</option>
              <option value="DITOLAK">Ditolak</option>
              <option value="DRAFT">Draft</option>
            </select>
          </div>

          {/* Filter Tahun */}
          <div className="lg:col-span-3">
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">
              Tahun Anggaran:
            </label>
            <select
              value={tahunFilter}
              onChange={(e) => setTahunFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-slate-800 font-medium focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            >
              <option value="Semua">Semua Tahun</option>
              {tahunOptions.map(th => (
                <option key={th} value={th}>Tahun {th}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Input Baris 2: Filter Rentang Tanggal Pengajuan */}
        <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200/80 space-y-2.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <span className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5 uppercase tracking-wider">
              <Calendar className="w-3.5 h-3.5 text-blue-600" />
              <span>Rentang Tanggal Pengajuan:</span>
            </span>

            {/* Quick Presets */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] text-slate-400 mr-1">Preset:</span>
              <button
                type="button"
                onClick={() => handleQuickPreset('all')}
                className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                  !startDate && !endDate
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                Semua
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset('this_month')}
                className="px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 text-[10px] font-medium transition-colors"
              >
                Bulan Ini
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset('last_30')}
                className="px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 text-[10px] font-medium transition-colors"
              >
                30 Hari Terakhir
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset('this_year')}
                className="px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 text-[10px] font-medium transition-colors"
              >
                Tahun Ini
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-semibold text-slate-500 mb-1">
                Dari Tanggal (Mulai):
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-800 font-medium focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-slate-500 mb-1">
                Sampai Tanggal (Selesai):
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-800 font-medium focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Indikator Hasil Pencarian Real-Time */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">
              Ditemukan: <span className="text-blue-700 font-bold">{filteredList.length}</span> dari {pengajuanList.length} pengajuan
            </span>
            {isFiltering && (
              <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 text-[10px] font-semibold border border-blue-200">
                Filter Aktif
              </span>
            )}
          </div>

          <div className="flex items-center gap-4 text-xs">
            <span className="text-slate-500">
              Total Buku: <strong className="text-slate-900 font-bold">{totalBukuFiltered.toLocaleString('id-ID')} Eks</strong>
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-slate-500">
              Total Pagu: <strong className="text-blue-800 font-extrabold">{formatRupiah(totalNilaiFiltered)}</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Tabel Hasil Pencarian Real-Time */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Nomor Pengajuan</th>
                <th className="py-3.5 px-4 text-center">Tahun</th>
                <th className="py-3.5 px-4">Tanggal Pengajuan</th>
                <th className="py-3.5 px-4">Keterangan / Judul Buku</th>
                <th className="py-3.5 px-4 text-right">Volume Buku</th>
                <th className="py-3.5 px-4 text-right">Nilai Rencana (Rp)</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Search className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-700">Tidak ada pengajuan yang cocok</p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Coba sesuaikan nomor pengajuan atau rentang tanggal pencarian Anda.
                    </p>
                    {isFiltering && (
                      <button
                        onClick={resetAllFilters}
                        className="mt-3 px-3 py-1.5 bg-blue-50 text-blue-700 font-semibold rounded-lg text-xs hover:bg-blue-100 transition-colors"
                      >
                        Bersihkan Filter Pencarian
                      </button>
                    )}
                  </td>
                </tr>
              ) : (
                filteredList.map((p) => {
                  const isMatchSearch = searchQuery.trim() && p.nomorPengajuan.toLowerCase().includes(searchQuery.trim().toLowerCase());

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-semibold text-slate-900">
                        <div className="flex items-center gap-1.5">
                          <span className={`font-mono font-bold ${isMatchSearch ? 'bg-amber-100 text-amber-900 px-1 rounded' : 'text-blue-700'}`}>
                            {p.nomorPengajuan}
                          </span>
                          {p.status === 'PERLU REVISI' && (
                            <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono text-slate-700">
                        {p.tahunAnggaran}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">
                        {formatDateIndo(p.tanggalPengajuan)}
                      </td>
                      <td className="py-3.5 px-4">
                        <strong className="text-slate-900 block">{p.totalJenisBuku} Judul Buku</strong>
                        <span className="text-[11px] text-slate-500 truncate max-w-xs block">
                          {p.keteranganUmum || `${p.items[0]?.judul || 'Pengajuan buku'}`}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-medium text-slate-900 whitespace-nowrap">
                        {p.totalBuku.toLocaleString('id-ID')} Eks
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-slate-900 whitespace-nowrap">
                        {formatRupiah(p.totalNilai)}
                      </td>
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        <StatusBadge status={p.status} size="sm" />
                      </td>
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => onViewDetail(p)}
                            className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs inline-flex items-center gap-1 transition-colors"
                            title="Lihat Detail & Riwayat Pengajuan"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Detail</span>
                          </button>

                          {(p.status === 'DRAFT' || p.status === 'PERLU REVISI') && (
                            <button
                              onClick={() => onEditPengajuan(p)}
                              className="px-2.5 py-1 rounded bg-orange-500 hover:bg-orange-600 text-white font-semibold text-xs inline-flex items-center gap-1 shadow-xs transition-colors"
                              title="Perbaiki / Edit Pengajuan"
                            >
                              <FileEdit className="w-3.5 h-3.5" />
                              <span>{p.status === 'PERLU REVISI' ? 'Perbaiki' : 'Edit'}</span>
                            </button>
                          )}

                          {(p.status === 'DISETUJUI' || p.status === 'SELESAI REKAP') && (
                            <button
                              onClick={() => setSelectedPOForWhatsApp(p)}
                              className="p-1 rounded text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors"
                              title="Kirim Berkas PDF PO ke WA Admin CV"
                            >
                              <MessageSquare className="w-4 h-4" />
                            </button>
                          )}

                          <button
                            onClick={() => exportPengajuanToPdf(p, lembaga, cvProfile)}
                            className="p-1 rounded text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Download Dokumen PDF Resmi ARKAS"
                          >
                            <Download className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => exportSinglePengajuanToExcel(p, lembaga, cvProfile)}
                            className="p-1 rounded text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
                            title="Export Excel"
                          >
                            <FileSpreadsheet className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            {filteredList.length > 0 && (
              <tfoot className="bg-slate-100 font-bold border-t border-slate-200">
                <tr>
                  <td colSpan={4} className="py-3.5 px-4 text-slate-700 uppercase tracking-wider">
                    Total Hasil Pencarian ({filteredList.length} Pengajuan):
                  </td>
                  <td className="py-3.5 px-4 text-right text-slate-900">
                    {totalBukuFiltered.toLocaleString('id-ID')} Eks
                  </td>
                  <td className="py-3.5 px-4 text-right text-blue-900 text-sm">
                    {formatRupiah(totalNilaiFiltered)}
                  </td>
                  <td colSpan={2}></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* Modal Otomatisasi Kirim Berkas PDF PO ke WA Admin CV */}
      {selectedPOForWhatsApp && (
        <POFinalWhatsAppModal
          isOpen={!!selectedPOForWhatsApp}
          onClose={() => setSelectedPOForWhatsApp(null)}
          pengajuan={selectedPOForWhatsApp}
          lembaga={lembaga}
          cvProfile={cvProfile}
          systemSettings={arkasStorage.getSystemSettings()}
          autoTrigger={true}
        />
      )}
    </div>
  );
};
