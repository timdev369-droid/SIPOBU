import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  FileSpreadsheet, 
  Clipboard, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  Check, 
  Trash2, 
  Eye, 
  Sparkles,
  ArrowRight,
  BookOpen,
  FileCheck
} from 'lucide-react';
import { JenjangPendidikan, PengajuanItem } from '../../types/index.ts';
import { formatRupiah } from '../../lib/storage.ts';
import { 
  ParsedBukuRow, 
  parseFromExcelFile, 
  parseFromRawText, 
  downloadExcelTemplate,
  getSampleTsvText
} from '../../utils/importBukuParser.ts';

interface Props {
  defaultJenjang: JenjangPendidikan;
  onClose: () => void;
  onImportItems: (items: PengajuanItem[]) => void;
}

export const ImportPengajuanExcelModal: React.FC<Props> = ({
  defaultJenjang,
  onClose,
  onImportItems
}) => {
  const [activeTab, setActiveTab] = useState<'paste' | 'upload'>('paste');
  const [pasteText, setPasteText] = useState<string>('');
  const [parsedRows, setParsedRows] = useState<ParsedBukuRow[]>([]);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleParseText = (text: string) => {
    setErrorMessage('');
    if (!text.trim()) {
      setParsedRows([]);
      return;
    }
    try {
      const rows = parseFromRawText(text, defaultJenjang);
      if (rows.length === 0) {
        setErrorMessage('Tidak ditemukan baris data buku yang valid. Pastikan format kolom: NO | JUDUL BUKU | KETERANGAN | HARGA | DIPESAN | JUMLAH');
      }
      setParsedRows(rows);
    } catch (err: any) {
      setErrorMessage(err.message || 'Gagal memproses data teks.');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMessage('');
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const buffer = event.target?.result as ArrayBuffer;
        const rows = parseFromExcelFile(buffer, defaultJenjang);
        if (rows.length === 0) {
          setErrorMessage('File Excel terbaca namun tidak ada baris data buku yang cocok.');
        }
        setParsedRows(rows);
      } catch (err: any) {
        setErrorMessage(err.message || 'Gagal membaca file spreadsheet.');
      }
    };

    reader.onerror = () => {
      setErrorMessage('Terjadi kesalahan saat membaca file.');
    };

    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  const handleLoadSample = () => {
    const sample = getSampleTsvText();
    setPasteText(sample);
    setActiveTab('paste');
    handleParseText(sample);
  };

  const handleCopySample = () => {
    navigator.clipboard.writeText(getSampleTsvText());
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  const totalBuku = parsedRows.length;
  const validBuku = parsedRows.filter(r => r.isValid).length;
  const totalDipesan = parsedRows.reduce((acc, r) => acc + (r.dipesan || 0), 0);
  const totalNilai = parsedRows.reduce((acc, r) => acc + (r.jumlah || (r.harga * r.dipesan)), 0);

  const handleApplyImport = () => {
    const validRows = parsedRows.filter(r => r.isValid);
    if (validRows.length === 0) {
      alert('Tidak ada item buku yang valid untuk dimasukkan ke pengajuan.');
      return;
    }

    const newItems: PengajuanItem[] = validRows.map((r, idx) => {
      const qty = r.dipesan > 0 ? r.dipesan : 1;
      const subtotal = r.jumlah > 0 ? r.jumlah : (r.harga * qty);

      return {
        id: `item-imp-${Date.now()}-${idx + 1}`,
        kodeBuku: r.kodeBuku,
        isbn: r.isbn,
        judul: r.judulBuku,
        penulis: r.penulis,
        penerbit: r.penerbit,
        jenjang: r.jenjang,
        kelas: r.kelas,
        mataPelajaran: r.mataPelajaran,
        kurikulum: r.kurikulum,
        jumlah: qty,
        hargaSatuan: r.harga,
        total: subtotal,
        keterangan: r.keterangan
      };
    });

    onImportItems(newItems);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[94vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 my-auto">
        {/* Header Modal */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-blue-50 via-indigo-50 to-emerald-50 rounded-t-3xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-700 text-white flex items-center justify-center shadow-md">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold tracking-wide uppercase">
                <span>Impor Cepat Pesanan Buku</span>
              </div>
              <h3 className="font-bold text-slate-900 text-base">
                Impor Daftar Kebutuhan Buku ARKAS
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                Format: NO • JUDUL BUKU • KETERANGAN • HARGA • DIPESAN • JUMLAH
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-200">
            <div className="inline-flex rounded-xl bg-slate-200 p-0.5">
              <button
                type="button"
                onClick={() => setActiveTab('paste')}
                className={`px-3 py-1.5 rounded-lg font-semibold text-xs transition-all flex items-center gap-1.5 ${
                  activeTab === 'paste'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Clipboard className="w-3.5 h-3.5" />
                <span>Tempel Tabel (Paste)</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('upload')}
                className={`px-3 py-1.5 rounded-lg font-semibold text-xs transition-all flex items-center gap-1.5 ${
                  activeTab === 'upload'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Excel (.xlsx)</span>
              </button>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={downloadExcelTemplate}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-medium text-xs transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-blue-600" />
                <span>Unduh Template</span>
              </button>

              <button
                type="button"
                onClick={handleLoadSample}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-300 font-semibold text-xs transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Muat Contoh Data</span>
              </button>

              <button
                type="button"
                onClick={handleCopySample}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-medium text-xs transition-colors"
              >
                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Clipboard className="w-3.5 h-3.5 text-slate-500" />}
                <span>{isCopied ? 'Tersalin!' : 'Salin Format'}</span>
              </button>
            </div>
          </div>

          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {activeTab === 'paste' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px] text-slate-600">
                <span className="font-semibold">Salin data dari Excel dan tempel (Ctrl+V) pada kotak di bawah:</span>
                {pasteText && (
                  <button
                    type="button"
                    onClick={() => {
                      setPasteText('');
                      setParsedRows([]);
                    }}
                    className="text-rose-600 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" /> Bersihkan
                  </button>
                )}
              </div>

              <textarea
                rows={7}
                value={pasteText}
                onChange={(e) => {
                  setPasteText(e.target.value);
                  handleParseText(e.target.value);
                }}
                placeholder="1	Matematika untuk SD Kelas 1	Kurikulum Merdeka	21500	60	1290000
2	Bahasa Indonesia untuk SD Kelas 1	Kurikulum Merdeka	23000	60	1380000
3	Pendidikan Agama Islam SD Kelas 1	Kurikulum Merdeka	24500	60	1470000"
                className="w-full p-3 font-mono text-[11px] border border-slate-300 rounded-2xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden leading-relaxed text-slate-800"
              />
            </div>
          )}

          {activeTab === 'upload' && (
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-blue-300 hover:border-blue-500 rounded-3xl p-8 text-center cursor-pointer bg-blue-50/30 hover:bg-blue-50/60 transition-all space-y-3"
            >
              <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center mx-auto shadow-inner">
                <Upload className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm">
                  {fileName ? `File: ${fileName}` : 'Pilih File Excel / Spreadsheet Pesanan'}
                </h4>
                <p className="text-slate-500 text-[11px] mt-1">
                  Mendukung file .xlsx, .xls, .csv, atau .tsv
                </p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx, .xls, .csv, .tsv"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          )}

          {/* Pratinjau Hasil Pembacaan */}
          {parsedRows.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-2.5 bg-blue-50 rounded-xl border border-blue-200">
                  <span className="text-[10px] text-blue-700 font-semibold block">TOTAL BUKU</span>
                  <strong className="text-blue-900 text-base">{totalBuku} Judul</strong>
                </div>

                <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200">
                  <span className="text-[10px] text-emerald-700 font-semibold block">TOTAL DIPESAN</span>
                  <strong className="text-emerald-900 text-base">{totalDipesan.toLocaleString('id-ID')} Eks</strong>
                </div>

                <div className="p-2.5 bg-purple-50 rounded-xl border border-purple-200">
                  <span className="text-[10px] text-purple-700 font-semibold block">TOTAL NILAI RENCANA</span>
                  <strong className="text-purple-900 text-base">{formatRupiah(totalNilai)}</strong>
                </div>
              </div>

              <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-2xs">
                <div className="max-h-60 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-semibold uppercase tracking-wider border-b border-slate-200 sticky top-0 text-[10px]">
                      <tr>
                        <th className="py-2 px-2.5 text-center w-8">No</th>
                        <th className="py-2 px-3">Judul Buku & Klasifikasi</th>
                        <th className="py-2 px-3 text-right">Harga</th>
                        <th className="py-2 px-3 text-center">Dipesan</th>
                        <th className="py-2 px-3 text-right">Jumlah Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-sans">
                      {parsedRows.map((r, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-2 px-2.5 text-center font-mono text-slate-500">
                            {r.no || idx + 1}
                          </td>
                          <td className="py-2 px-3">
                            <span className="font-bold text-slate-900 block leading-tight">{r.judulBuku}</span>
                            <div className="flex items-center gap-1.5 mt-0.5 text-[9px]">
                              <span className="px-1.5 py-0.2 rounded bg-blue-100 text-blue-800 font-semibold">
                                {r.jenjang} - {r.kelas}
                              </span>
                              <span className="text-slate-500">• {r.mataPelajaran}</span>
                              <span className="text-slate-400">• {r.keterangan}</span>
                            </div>
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-semibold text-slate-800">
                            {formatRupiah(r.harga)}
                          </td>
                          <td className="py-2 px-3 text-center font-mono font-bold text-emerald-700">
                            {r.dipesan > 0 ? `${r.dipesan} eks` : '1 eks'}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">
                            {formatRupiah(r.jumlah || (r.harga * (r.dipesan || 1)))}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors"
            >
              Batal
            </button>

            <button
              type="button"
              onClick={handleApplyImport}
              disabled={parsedRows.length === 0 || validBuku === 0}
              className={`w-full sm:w-auto px-6 py-2.5 font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2 ${
                parsedRows.length === 0 || validBuku === 0
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-600/20'
              }`}
            >
              <FileCheck className="w-4 h-4" />
              <span>
                {parsedRows.length > 0 
                  ? `Tambahkan ${validBuku} Buku ke Formulir Pengajuan` 
                  : 'Siapkan Data untuk Dimasukkan'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
