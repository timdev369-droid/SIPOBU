import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Search, 
  BookOpen, 
  Send, 
  Save, 
  ArrowLeft, 
  AlertCircle, 
  Sparkles, 
  Check, 
  X,
  PlusCircle,
  HelpCircle,
  FileSpreadsheet
} from 'lucide-react';
import { Lembaga, Buku, Pengajuan, PengajuanItem, CVProfile } from '../../types/index.ts';
import { arkasStorage, formatRupiah } from '../../lib/storage.ts';
import { WhatsAppNotificationModal } from '../common/WhatsAppNotificationModal.tsx';
import { ImportPengajuanExcelModal } from './ImportPengajuanExcelModal.tsx';

interface Props {
  lembaga: Lembaga;
  cvProfile: CVProfile;
  initialPengajuan?: Pengajuan | null;
  onSuccess: (pengajuan: Pengajuan) => void;
  onCancel: () => void;
}

export const FormPengajuanBuku: React.FC<Props> = ({
  lembaga,
  cvProfile,
  initialPengajuan,
  onSuccess,
  onCancel
}) => {
  const isEditing = !!initialPengajuan;
  const isRevisionMode = initialPengajuan?.status === 'PERLU REVISI';

  // State Form
  const [systemSettings] = useState(() => arkasStorage.getSystemSettings());
  const [submittedForWa, setSubmittedForWa] = useState<Pengajuan | null>(null);
  const [tahunAnggaran, setTahunAnggaran] = useState<string>(
    initialPengajuan?.tahunAnggaran || systemSettings.tahunAnggaranAktif || cvProfile.tahunAnggaranAktif || '2026'
  );
  const [keteranganUmum, setKeteranganUmum] = useState<string>(
    initialPengajuan?.keteranganUmum || ''
  );
  const [items, setItems] = useState<PengajuanItem[]>(
    initialPengajuan?.items || []
  );

  const [nomorPengajuanPreview, setNomorPengajuanPreview] = useState<string>(
    initialPengajuan?.nomorPengajuan || arkasStorage.generateNomorPengajuan(tahunAnggaran)
  );

  // Modal Catalog Selector
  const [showCatalogModal, setShowCatalogModal] = useState<boolean>(false);
  const [showImportOrderModal, setShowImportOrderModal] = useState<boolean>(false);
  const [catalogSearch, setCatalogSearch] = useState<string>('');
  const [filterJenjang, setFilterJenjang] = useState<string>(lembaga.jenjang || 'Semua');
  const [filterKelas, setFilterKelas] = useState<string>('Semua');

  // Modal Custom Book (Ajukan Buku Baru jika belum ada di master)
  const [showCustomModal, setShowCustomModal] = useState<boolean>(false);
  const [customForm, setCustomForm] = useState({
    judul: '',
    isbn: '',
    penulis: '',
    penerbit: '',
    jenjang: lembaga.jenjang,
    kelas: 'Kelas 1',
    mataPelajaran: '',
    kurikulum: 'Kurikulum Merdeka' as const,
    hargaSatuan: 25000,
    jumlah: 1,
    keterangan: ''
  });

  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    if (!isEditing) {
      setNomorPengajuanPreview(arkasStorage.generateNomorPengajuan(tahunAnggaran));
    }
  }, [tahunAnggaran, isEditing]);

  const masterBuku = arkasStorage.getActiveBuku();

  // Filter Catalog
  const filteredCatalog = masterBuku.filter(b => {
    const matchesSearch = 
      b.judul.toLowerCase().includes(catalogSearch.toLowerCase()) ||
      b.isbn.includes(catalogSearch) ||
      b.kodeBuku.toLowerCase().includes(catalogSearch.toLowerCase()) ||
      b.penerbit.toLowerCase().includes(catalogSearch.toLowerCase()) ||
      b.mataPelajaran.toLowerCase().includes(catalogSearch.toLowerCase());

    const matchesJenjang = filterJenjang === 'Semua' || b.jenjang === filterJenjang;
    const matchesKelas = filterKelas === 'Semua' || b.kelas === filterKelas;

    return matchesSearch && matchesJenjang && matchesKelas;
  });

  // Tambahkan buku dari master katalog
  const handleSelectFromCatalog = (b: Buku) => {
    // Cek apakah buku sudah ada dalam daftar
    const exists = items.some(item => item.bukuId === b.id || (item.isbn && item.isbn === b.isbn));
    if (exists) {
      alert(`Buku "${b.judul}" sudah ada di daftar pengajuan. Anda dapat mengubah jumlahnya langsung pada tabel.`);
      return;
    }

    const newItem: PengajuanItem = {
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      bukuId: b.id,
      kodeBuku: b.kodeBuku,
      isbn: b.isbn,
      judul: b.judul,
      penulis: b.penulis,
      penerbit: b.penerbit,
      jenjang: b.jenjang,
      kelas: b.kelas,
      mataPelajaran: b.mataPelajaran,
      kurikulum: b.kurikulum,
      jumlah: 30, // Default rombel/siswa
      hargaSatuan: b.hargaReferensi,
      total: 30 * b.hargaReferensi,
      keterangan: ''
    };

    setItems([...items, newItem]);
    setShowCatalogModal(false);
  };

  // Tambahkan buku custom yang belum ada di katalog
  const handleAddCustomBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customForm.judul.trim() || !customForm.penerbit.trim()) {
      alert('Judul buku dan penerbit wajib diisi.');
      return;
    }

    const newItem: PengajuanItem = {
      id: `item-cst-${Date.now()}`,
      kodeBuku: `CST-${Date.now().toString().slice(-4)}`,
      isbn: customForm.isbn.trim() || '-',
      judul: customForm.judul.trim(),
      penulis: customForm.penulis.trim() || '-',
      penerbit: customForm.penerbit.trim(),
      jenjang: customForm.jenjang,
      kelas: customForm.kelas,
      mataPelajaran: customForm.mataPelajaran.trim() || 'Umum',
      kurikulum: customForm.kurikulum,
      jumlah: Number(customForm.jumlah) || 1,
      hargaSatuan: Number(customForm.hargaSatuan) || 0,
      total: (Number(customForm.jumlah) || 1) * (Number(customForm.hargaSatuan) || 0),
      keterangan: customForm.keterangan.trim() || 'Buku usulan baru sekolah'
    };

    setItems([...items, newItem]);
    setShowCustomModal(false);
    // Reset
    setCustomForm({
      judul: '',
      isbn: '',
      penulis: '',
      penerbit: '',
      jenjang: lembaga.jenjang,
      kelas: 'Kelas 1',
      mataPelajaran: '',
      kurikulum: 'Kurikulum Merdeka',
      hargaSatuan: 25000,
      jumlah: 1,
      keterangan: ''
    });
  };

  // Update item field (Jumlah, Harga, Keterangan)
  const handleItemChange = (index: number, field: keyof PengajuanItem, value: any) => {
    const updated = [...items];
    const item = { ...updated[index] };

    if (field === 'jumlah') {
      const qty = Math.max(1, parseInt(value) || 1);
      item.jumlah = qty;
      item.total = qty * item.hargaSatuan;
    } else if (field === 'hargaSatuan') {
      const price = Math.max(0, parseFloat(value) || 0);
      item.hargaSatuan = price;
      item.total = item.jumlah * price;
    } else {
      (item as any)[field] = value;
    }

    updated[index] = item;
    setItems(updated);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, idx) => idx !== index));
  };

  // Kalkulasi total
  const totalJenis = items.length;
  const totalQty = items.reduce((acc, it) => acc + (Number(it.jumlah) || 0), 0);
  const grandTotalNilai = items.reduce((acc, it) => acc + (Number(it.total) || 0), 0);

  // Submit Handler
  const handleSubmit = (submitImmediately: boolean) => {
    setErrorMessage('');
    if (items.length === 0) {
      setErrorMessage('Harap tambahkan minimal 1 buku ke dalam pengajuan.');
      return;
    }

    if (submitImmediately && !systemSettings.periodePengajuanBuka) {
      setErrorMessage('Periode pengajuan buku saat ini sedang ditutup oleh Super Admin CV. Anda hanya dapat menyimpannya sebagai Draf.');
      return;
    }

    // Validasi batas eksemplar dari Super Admin
    for (const item of items) {
      const qty = Number(item.jumlah) || 0;
      if (qty < systemSettings.minEksemplarPerItem) {
        setErrorMessage(`Jumlah eksemplar buku "${item.judul}" minimal ${systemSettings.minEksemplarPerItem} eksemplar.`);
        return;
      }
      if (qty > systemSettings.maxEksemplarPerItem) {
        setErrorMessage(`Jumlah eksemplar buku "${item.judul}" (${qty} eks) melebihi batas maksimal ${systemSettings.maxEksemplarPerItem} eksemplar yang ditetapkan oleh Super Admin.`);
        return;
      }
    }

    const res = arkasStorage.savePengajuan({
      id: initialPengajuan?.id,
      lembagaId: lembaga.id,
      tahunAnggaran,
      keteranganUmum,
      items,
      submitImmediately
    });

    if (res.success) {
      if (submitImmediately && systemSettings.notifWaAdminAktif !== false) {
        setSubmittedForWa(res.pengajuan);
      } else {
        onSuccess(res.pengajuan);
      }
    } else {
      setErrorMessage(res.error || 'Gagal menyimpan pengajuan');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onCancel}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3 py-1.5 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali</span>
        </button>

        <div className="text-right">
          <span className="text-[11px] text-slate-400 block">Nomor Pengajuan Sistem:</span>
          <span className="font-mono font-bold text-blue-700 text-sm">{nomorPengajuanPreview}</span>
        </div>
      </div>

      {/* Banner Peringatan jika Periode Pengajuan Ditutup oleh Super Admin */}
      {!systemSettings.periodePengajuanBuka && (
        <div className="bg-amber-50 border-2 border-amber-300 p-4 rounded-xl flex items-start gap-3 shadow-xs">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-bold text-amber-900 text-sm">
              Pemberitahuan: Periode Pengajuan Buku Saat Ini Sedang Ditutup
            </h4>
            <p className="text-xs text-amber-800">
              Super Admin CV telah menutup periode pengajuan buku untuk tahun anggaran {systemSettings.tahunAnggaranAktif}. Anda tetap dapat menyusun dan menyimpan daftar kebutuhan buku sebagai <strong>Draf</strong>, namun belum dapat mengirimkannya langsung ke CV sampai periode dibuka kembali.
            </p>
          </div>
        </div>
      )}

      {/* Alert Revisi jika status PERLU REVISI */}
      {isRevisionMode && initialPengajuan?.catatanCv && (
        <div className="bg-orange-50 border-2 border-orange-400 p-4 rounded-xl shadow-xs">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-orange-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="font-bold text-orange-900 text-sm">
                Catatan Revisi dari CV {cvProfile.namaCv}:
              </h4>
              <p className="text-xs text-orange-800 bg-white/70 p-3 rounded-lg border border-orange-200 font-medium">
                "{initialPengajuan.catatanCv}"
              </p>
              <p className="text-[11px] text-orange-700">
                Silakan sesuaikan jumlah eksemplar, hapus/tambah judul sesuai instruksi di atas, lalu klik tombol <strong>"Kirim Kembali Revisi ke CV"</strong>.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Error Message */}
      {errorMessage && (
        <div className="bg-rose-50 border-l-4 border-rose-500 p-3 rounded-lg text-xs text-rose-700 font-medium">
          {errorMessage}
        </div>
      )}

      {/* Card Header Pengajuan Sesuai Requirement 6 */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-5">
        <div className="border-b border-slate-100 pb-4">
          <h2 className="text-lg font-bold text-slate-900">
            {isRevisionMode 
              ? 'Perbaikan / Revisi Pengajuan Kebutuhan Buku' 
              : isEditing 
              ? 'Ubah Pengajuan Buku (Draf)' 
              : 'Formulir Pengajuan Kebutuhan Buku Baru'}
          </h2>
          <p className="text-xs text-slate-500">
            Penyusunan daftar buku teks dan penunjang untuk perencanaan pagu anggaran ARKAS BOSP.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Nomor Pengajuan</label>
            <input
              type="text"
              readOnly
              value={nomorPengajuanPreview}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-semibold text-slate-700 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Tahun Anggaran *</label>
            <select
              value={tahunAnggaran}
              onChange={(e) => setTahunAnggaran(e.target.value)}
              disabled={isEditing}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-800 font-medium focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            >
              <option value="2026">2026 (Tahun Berjalan)</option>
              <option value="2027">2027</option>
              <option value="2025">2025</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Nama Lembaga & NPSN</label>
            <input
              type="text"
              readOnly
              value={`${lembaga.namaLembaga} (${lembaga.npsn})`}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Kepala Sekolah / Operator</label>
            <input
              type="text"
              readOnly
              value={`${lembaga.kepalaSekolah} / ${lembaga.operator}`}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 cursor-not-allowed"
            />
          </div>

          <div className="sm:col-span-2 lg:col-span-4">
            <label className="block font-semibold text-slate-700 mb-1">
              Keterangan Umum / Alokasi ARKAS (Opsional)
            </label>
            <input
              type="text"
              value={keteranganUmum}
              onChange={(e) => setKeteranganUmum(e.target.value)}
              placeholder="Contoh: Pengadaan Buku Teks Pokok Siswa Baru Semester 1 & 2 Anggaran BOSP Reguler 2026"
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>
        </div>
      </div>

      {/* Card Tabel Daftar Buku Sesuai Requirement 6 & 7 */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">Daftar Buku yang Diajukan</h3>
            <p className="text-xs text-slate-500">
              Pilih dari katalog referensi CV atau ajukan buku baru jika belum tersedia di katalog.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => setShowImportOrderModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs transition-colors"
              title="Impor daftar kebutuhan buku format NO • JUDUL BUKU • KETERANGAN • HARGA • DIPESAN • JUMLAH"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Impor Format Excel</span>
            </button>

            <button
              type="button"
              onClick={() => setShowCatalogModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>+ Pilih dari Master Buku CV</span>
            </button>

            {systemSettings.izinkanBukuCustom ? (
              <button
                type="button"
                onClick={() => setShowCustomModal(true)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs border border-slate-300 transition-colors"
              >
                <PlusCircle className="w-3.5 h-3.5 text-blue-600" />
                <span>+ Ajukan Buku Baru</span>
              </button>
            ) : null}
          </div>
        </div>

        {/* Tabel Input Buku */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3 text-center w-10">No</th>
                <th className="py-2.5 px-3">Kode & ISBN</th>
                <th className="py-2.5 px-3 min-w-[200px]">Judul Buku & Penerbit</th>
                <th className="py-2.5 px-3">Jenjang/Kelas</th>
                <th className="py-2.5 px-3">Kurikulum</th>
                <th className="py-2.5 px-3 text-center w-24">Jumlah (Eks)</th>
                <th className="py-2.5 px-3 text-right min-w-[110px]">Harga Satuan</th>
                <th className="py-2.5 px-3 text-right min-w-[120px]">Total (Rp)</th>
                <th className="py-2.5 px-3 min-w-[140px]">Keterangan</th>
                <th className="py-2.5 px-3 text-center w-12">Hapus</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {items.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    <BookOpen className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    Belum ada buku dalam pengajuan ini. Silakan klik tombol{' '}
                    <strong className="text-blue-600">"+ Pilih dari Master Buku CV"</strong> di atas.
                  </td>
                </tr>
              ) : (
                items.map((item, idx) => (
                  <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 text-center font-medium text-slate-500">
                      {idx + 1}
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-mono font-semibold text-slate-800 block text-[11px]">
                        {item.kodeBuku}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        ISBN: {item.isbn || '-'}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900 leading-tight">
                        {item.judul}
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        Penerbit: {item.penerbit} {item.penulis ? `• Penulis: ${item.penulis}` : ''}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-600">
                      <span className="inline-block px-1.5 py-0.5 rounded bg-slate-100 text-[10px] font-medium text-slate-700">
                        {item.jenjang} - {item.kelas}
                      </span>
                      <span className="block text-[10px] text-slate-500 mt-0.5">
                        Mapel: {item.mataPelajaran}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                      {item.kurikulum}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <input
                        type="number"
                        min="1"
                        value={item.jumlah}
                        onChange={(e) => handleItemChange(idx, 'jumlah', e.target.value)}
                        className="w-20 px-2 py-1 text-center font-bold text-slate-900 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                      />
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="font-medium text-slate-800">
                        {formatRupiah(item.hargaSatuan)}
                      </div>
                      <span className="text-[10px] text-slate-400">per eks</span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="font-bold text-blue-700">
                        {formatRupiah(item.total)}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <input
                        type="text"
                        placeholder="Contoh: Rombel 1A"
                        value={item.keterangan || ''}
                        onChange={(e) => handleItemChange(idx, 'keterangan', e.target.value)}
                        className="w-full px-2 py-1 text-[11px] border border-slate-200 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
                      />
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        title="Hapus buku dari daftar"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Ringkasan & Total Perhitungan Otomatis */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-6 text-xs text-slate-600">
            <div>
              <span className="text-slate-400 block">Total Jenis Buku:</span>
              <strong className="text-sm text-slate-900">{totalJenis} Judul</strong>
            </div>
            <div className="h-8 w-px bg-slate-200" />
            <div>
              <span className="text-slate-400 block">Total Eksemplar:</span>
              <strong className="text-sm text-slate-900">{totalQty.toLocaleString('id-ID')} Eks</strong>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-500 block">TOTAL NILAI RENCANA ANGGARAN ARKAS:</span>
            <span className="text-xl sm:text-2xl font-extrabold text-blue-800">
              {formatRupiah(grandTotalNilai)}
            </span>
          </div>
        </div>
      </div>

      {/* Aksi Bawah */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold text-xs transition-colors"
        >
          Batalkan
        </button>

        <div className="w-full sm:w-auto flex items-center gap-3">
          <button
            type="button"
            onClick={() => handleSubmit(false)}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold text-xs transition-colors"
          >
            <Save className="w-4 h-4 text-slate-600" />
            <span>Simpan Sebagai Draft</span>
          </button>

          <button
            type="button"
            onClick={() => handleSubmit(true)}
            disabled={!systemSettings.periodePengajuanBuka && !isRevisionMode}
            title={!systemSettings.periodePengajuanBuka && !isRevisionMode ? 'Periode pengajuan saat ini ditutup oleh Super Admin CV' : undefined}
            className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-white font-semibold text-xs shadow-md transition-all ${
              !systemSettings.periodePengajuanBuka && !isRevisionMode
                ? 'bg-slate-400 cursor-not-allowed opacity-70'
                : isRevisionMode 
                ? 'bg-orange-600 hover:bg-orange-700 shadow-orange-600/20' 
                : 'bg-blue-600 hover:bg-blue-700 shadow-blue-600/20'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>
              {!systemSettings.periodePengajuanBuka && !isRevisionMode 
                ? 'Pengajuan Ditutup (Simpan Draf Saja)' 
                : isRevisionMode 
                ? 'Kirim Kembali Revisi ke CV' 
                : 'Kirim Pengajuan ke CV'}
            </span>
          </button>
        </div>
      </div>

      {/* MODAL: PILIH BUKU DARI MASTER KATALOG CV */}
      {showCatalogModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900 text-base">
                  Master Katalog Buku Penyedia ({cvProfile.namaCv})
                </h3>
                <p className="text-xs text-slate-500">
                  Cari dan pilih buku resmi Kurikulum Merdeka & 2013 yang disediakan untuk pengajuan ARKAS.
                </p>
              </div>
              <button
                onClick={() => setShowCatalogModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Filter & Search Bar */}
            <div className="p-4 border-b border-slate-100 bg-slate-50 flex flex-col sm:flex-row items-center gap-3">
              <div className="relative flex-1 w-full">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Cari judul buku, ISBN, kode buku, penerbit, atau mapel..."
                  value={catalogSearch}
                  onChange={(e) => setCatalogSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <select
                  value={filterJenjang}
                  onChange={(e) => setFilterJenjang(e.target.value)}
                  className="px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-medium text-slate-700"
                >
                  <option value="Semua">Semua Jenjang</option>
                  <option value="SD">SD</option>
                  <option value="SMP">SMP</option>
                  <option value="SMA">SMA</option>
                  <option value="SMK">SMK</option>
                  <option value="PAUD">PAUD/TK</option>
                </select>
              </div>
            </div>

            {/* List Buku */}
            <div className="flex-1 overflow-y-auto p-4 divide-y divide-slate-100 max-h-[50vh]">
              {filteredCatalog.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  Tidak ditemukan buku yang cocok dengan pencarian kata kunci di atas.
                </div>
              ) : (
                filteredCatalog.map((b) => {
                  const alreadyAdded = items.some(item => item.bukuId === b.id || item.isbn === b.isbn);
                  return (
                    <div key={b.id} className="py-3 flex items-center justify-between gap-4 hover:bg-slate-50 px-2 rounded-lg transition-colors">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-semibold text-[11px] text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                            {b.kodeBuku}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            ISBN: {b.isbn}
                          </span>
                          <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            {b.kurikulum}
                          </span>
                        </div>
                        <h4 className="font-bold text-slate-900 text-sm leading-snug">
                          {b.judul}
                        </h4>
                        <div className="text-xs text-slate-500">
                          {b.jenjang} • {b.kelas} • Mapel: <strong>{b.mataPelajaran}</strong> • Penerbit: {b.penerbit}
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="font-bold text-slate-900 text-sm">
                          {formatRupiah(b.hargaReferensi)}
                        </div>
                        <div className="text-[10px] text-slate-400 mb-1.5">Harga Referensi ARKAS</div>

                        {alreadyAdded ? (
                          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-600 font-semibold bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                            <Check className="w-3.5 h-3.5" /> Sudah Dipilih
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleSelectFromCatalog(b)}
                            className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors"
                          >
                            + Tambahkan
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
              <span className="text-slate-500">
                Menampilkan {filteredCatalog.length} buku dari katalog resmi CV.
              </span>
              <button
                type="button"
                onClick={() => setShowCatalogModal(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-lg"
              >
                Selesai Memilih
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: AJUKAN BUKU BARU (CUSTOM) */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base">
                Ajukan Buku Baru (Di Luar Master CV)
              </h3>
              <button onClick={() => setShowCustomModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCustomBook} className="space-y-4 pt-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Judul Buku *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Modul Pengayaan Bahasa Sunda Kelas 4"
                  value={customForm.judul}
                  onChange={(e) => setCustomForm({ ...customForm, judul: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">ISBN (Jika Ada)</label>
                  <input
                    type="text"
                    placeholder="978-xxx-xxx-xxx-x"
                    value={customForm.isbn}
                    onChange={(e) => setCustomForm({ ...customForm, isbn: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Penerbit *</label>
                  <input
                    type="text"
                    required
                    placeholder="Nama Penerbit"
                    value={customForm.penerbit}
                    onChange={(e) => setCustomForm({ ...customForm, penerbit: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenjang</label>
                  <select
                    value={customForm.jenjang}
                    onChange={(e) => setCustomForm({ ...customForm, jenjang: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  >
                    <option value="SD">SD</option>
                    <option value="SMP">SMP</option>
                    <option value="SMA">SMA</option>
                    <option value="SMK">SMK</option>
                    <option value="PAUD">PAUD</option>
                    <option value="TK">TK</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kelas</label>
                  <input
                    type="text"
                    value={customForm.kelas}
                    onChange={(e) => setCustomForm({ ...customForm, kelas: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Mata Pelajaran</label>
                  <input
                    type="text"
                    placeholder="Mapel"
                    value={customForm.mataPelajaran}
                    onChange={(e) => setCustomForm({ ...customForm, mataPelajaran: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jumlah Eksemplar *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={customForm.jumlah}
                    onChange={(e) => setCustomForm({ ...customForm, jumlah: parseInt(e.target.value) || 1 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Harga Satuan (Rp) *</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={customForm.hargaSatuan}
                    onChange={(e) => setCustomForm({ ...customForm, hargaSatuan: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCustomModal(false)}
                  className="px-3 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-xs"
                >
                  + Tambahkan ke Tabel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Notifikasi WhatsApp Otomatis ke Admin CV */}
      {submittedForWa && (
        <WhatsAppNotificationModal
          pengajuan={submittedForWa}
          lembaga={lembaga}
          cvProfile={cvProfile}
          systemSettings={systemSettings}
          isOpen={!!submittedForWa}
          onClose={() => {
            const p = submittedForWa;
            setSubmittedForWa(null);
            onSuccess(p);
          }}
          autoOpen={true}
        />
      )}
    </div>
  );
};
