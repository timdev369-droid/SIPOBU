import React, { useState, useMemo } from 'react';
import { 
  FileText, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  XCircle, 
  FileEdit, 
  PlusCircle, 
  BookOpen, 
  Layers, 
  Coins, 
  Eye, 
  Download, 
  ArrowRight,
  School,
  FileSpreadsheet,
  Search,
  Calendar,
  X,
  RotateCcw
} from 'lucide-react';
import { Lembaga, Pengajuan, CVProfile } from '../../types/index.ts';
import { StatusBadge } from '../common/StatusBadge.tsx';
import { formatRupiah, formatDateIndo } from '../../lib/storage.ts';
import { exportPengajuanToPdf } from '../../utils/exportPdf.ts';
import { exportSinglePengajuanToExcel } from '../../utils/exportExcel.ts';

interface Props {
  lembaga: Lembaga;
  pengajuanList: Pengajuan[];
  cvProfile: CVProfile;
  onCreateNew: () => void;
  onViewDetail: (pengajuan: Pengajuan) => void;
  onEditPengajuan: (pengajuan: Pengajuan) => void;
}

export const DashboardLembaga: React.FC<Props> = ({
  lembaga,
  pengajuanList,
  cvProfile,
  onCreateNew,
  onViewDetail,
  onEditPengajuan
}) => {
  // Hitung metrik statistik
  const totalPengajuan = pengajuanList.length;
  const draftCount = pengajuanList.filter(p => p.status === 'DRAFT').length;
  const menungguCount = pengajuanList.filter(p => p.status === 'DIKIRIM LEMBAGA' || p.status === 'DIPERIKSA CV').length;
  const revisiCount = pengajuanList.filter(p => p.status === 'PERLU REVISI').length;
  const disetujuiCount = pengajuanList.filter(p => p.status === 'DISETUJUI' || p.status === 'SELESAI REKAP').length;
  const ditolakCount = pengajuanList.filter(p => p.status === 'DITOLAK').length;

  const totalJenisBuku = pengajuanList.reduce((acc, p) => acc + p.totalJenisBuku, 0);
  const totalJumlahBuku = pengajuanList.reduce((acc, p) => acc + p.totalBuku, 0);
  const totalNilaiRencana = pengajuanList.reduce((acc, p) => acc + p.totalNilai, 0);

  // Search & date range filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filteredPengajuan = useMemo(() => {
    return pengajuanList.filter(p => {
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const matchNomor = p.nomorPengajuan.toLowerCase().includes(q);
        const matchKeterangan = (p.keteranganUmum || '').toLowerCase().includes(q);
        const matchBuku = p.items.some(it => 
          it.judul.toLowerCase().includes(q) || 
          it.kodeBuku.toLowerCase().includes(q)
        );
        if (!matchNomor && !matchKeterangan && !matchBuku) return false;
      }
      if (startDate && p.tanggalPengajuan < startDate) return false;
      if (endDate && p.tanggalPengajuan > endDate) return false;
      return true;
    });
  }, [pengajuanList, searchQuery, startDate, endDate]);

  return (
    <div className="space-y-6">
      {/* Header Lembaga & Quick Action */}
      <div className="bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-white text-xs font-medium backdrop-blur-xs">
              <School className="w-3.5 h-3.5 text-blue-200" />
              <span>Portal Satuan Pendidikan • {lembaga.jenjang} • {lembaga.statusLembaga} • NPSN {lembaga.npsn}</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              {lembaga.namaLembaga}
            </h1>
            <p className="text-sm text-blue-100 max-w-2xl">
              Selamat datang di portal pemesanan buku resmi SIPOBU. Susun dan ajukan kebutuhan buku sekolah Anda langsung ke CV Penyedia SIPLah <strong>{cvProfile.namaCv}</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onCreateNew}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-sm shadow-md shadow-emerald-950/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Ajukan Buku Baru</span>
            </button>
          </div>
        </div>
      </div>

      {/* Alert Banner jika ada pengajuan yang butuh revisi */}
      {revisiCount > 0 && (
        <div className="bg-orange-50 border-l-4 border-orange-500 p-4 rounded-xl shadow-xs flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-orange-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="font-semibold text-orange-900 text-sm">
              Perhatian: Terdapat {revisiCount} pengajuan yang membutuhkan revisi dari Anda!
            </h4>
            <p className="text-xs text-orange-700 mt-0.5">
              CV telah memeriksa pengajuan dan memberikan catatan perbaikan. Silakan periksa detailnya dan kirimkan kembali.
            </p>
          </div>
        </div>
      )}

      {/* Stat Cards Sesuai Requirement 5 */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Total Pengajuan</span>
            <FileText className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{totalPengajuan}</div>
          <span className="text-[10px] text-slate-400">Sepanjang periode</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Draft</span>
            <FileEdit className="w-4 h-4 text-slate-500" />
          </div>
          <div className="text-2xl font-bold text-slate-700">{draftCount}</div>
          <span className="text-[10px] text-slate-400">Belum dikirim</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-blue-100 bg-blue-50/30 shadow-xs">
          <div className="flex items-center justify-between text-blue-700 mb-1">
            <span className="text-xs font-medium">Menunggu CV</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-blue-700">{menungguCount}</div>
          <span className="text-[10px] text-blue-600/80">Sedang diproses CV</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-orange-200 bg-orange-50/40 shadow-xs">
          <div className="flex items-center justify-between text-orange-800 mb-1">
            <span className="text-xs font-medium">Perlu Revisi</span>
            <AlertCircle className="w-4 h-4 text-orange-600" />
          </div>
          <div className="text-2xl font-bold text-orange-700">{revisiCount}</div>
          <span className="text-[10px] text-orange-600 font-medium">Perlu tindakan</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-100 bg-emerald-50/30 shadow-xs">
          <div className="flex items-center justify-between text-emerald-700 mb-1">
            <span className="text-xs font-medium">Disetujui</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-700">{disetujuiCount}</div>
          <span className="text-[10px] text-emerald-600">Masuk ARKAS</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-rose-100 bg-rose-50/30 shadow-xs">
          <div className="flex items-center justify-between text-rose-700 mb-1">
            <span className="text-xs font-medium">Ditolak</span>
            <XCircle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-bold text-rose-700">{ditolakCount}</div>
          <span className="text-[10px] text-rose-600/80">Tidak lolos</span>
        </div>
      </div>

      {/* Rangkuman Volume & Nilai Rencana (Requirement 5) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-indigo-50 to-white p-5 rounded-2xl border border-indigo-100 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-600/20 shrink-0">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-indigo-900 uppercase tracking-wider">Total Jenis Buku</div>
            <div className="text-2xl font-bold text-slate-900 mt-0.5">{totalJenisBuku} Judul</div>
            <div className="text-xs text-slate-500">Variasi judul diajukan</div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-sky-50 to-white p-5 rounded-2xl border border-sky-100 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-md shadow-sky-600/20 shrink-0">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-sky-900 uppercase tracking-wider">Total Jumlah Buku</div>
            <div className="text-2xl font-bold text-slate-900 mt-0.5">{totalJumlahBuku.toLocaleString('id-ID')} Eks</div>
            <div className="text-xs text-slate-500">Total eksemplar kebutuhan</div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-emerald-50 to-white p-5 rounded-2xl border border-emerald-100 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20 shrink-0">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-emerald-900 uppercase tracking-wider">Total Nilai Rencana</div>
            <div className="text-2xl font-bold text-slate-900 mt-0.5">{formatRupiah(totalNilaiRencana)}</div>
            <div className="text-xs text-slate-500">Estimasi pagu anggaran ARKAS</div>
          </div>
        </div>
      </div>

      {/* Tabel Pengajuan Terbaru Sesuai Requirement 5 */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Daftar Pengajuan Buku Sekolah</h3>
            <p className="text-xs text-slate-500">Pencarian real-time berdasarkan nomor pengajuan atau rentang tanggal</p>
          </div>
          <button
            onClick={onCreateNew}
            className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>+ Buat Pengajuan Baru</span>
          </button>
        </div>

        {/* Real-time search & date range bar */}
        <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex flex-col md:flex-row items-center gap-2.5 text-xs">
          <div className="relative flex-1 w-full">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Cari nomor pengajuan (misal: PB-2026-0001)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-7 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <div className="flex items-center gap-1 bg-white border border-slate-300 px-2 py-1 rounded-lg">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                title="Mulai Tanggal"
                className="text-[11px] text-slate-700 bg-transparent focus:outline-hidden"
              />
              <span className="text-slate-400">-</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                title="Sampai Tanggal"
                className="text-[11px] text-slate-700 bg-transparent focus:outline-hidden"
              />
            </div>

            {(searchQuery || startDate || endDate) && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setStartDate('');
                  setEndDate('');
                }}
                className="p-1.5 rounded-lg text-rose-600 bg-rose-50 hover:bg-rose-100 transition-colors"
                title="Reset Filter"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Nomor Pengajuan</th>
                <th className="py-3 px-4 text-center">Tahun</th>
                <th className="py-3 px-4">Tanggal</th>
                <th className="py-3 px-4 text-right">Jumlah Buku</th>
                <th className="py-3 px-4 text-right">Nilai Rencana</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPengajuan.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    Tidak ditemukan pengajuan dengan kriteria pencarian tersebut.
                  </td>
                </tr>
              ) : (
                filteredPengajuan.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-slate-900">
                      <div className="flex items-center gap-1.5">
                        <span className="text-blue-700 font-mono">{p.nomorPengajuan}</span>
                        {p.status === 'PERLU REVISI' && (
                          <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 font-normal truncate max-w-xs">
                        {p.keteranganUmum || `${p.totalJenisBuku} judul buku`}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono text-slate-700">
                      {p.tahunAnggaran}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">
                      {formatDateIndo(p.tanggalPengajuan)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-medium text-slate-900 whitespace-nowrap">
                      {p.totalBuku.toLocaleString('id-ID')} Eks
                      <span className="block text-[10px] text-slate-400 font-normal">({p.totalJenisBuku} judul)</span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-semibold text-slate-900 whitespace-nowrap">
                      {formatRupiah(p.totalNilai)}
                    </td>
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <StatusBadge status={p.status} size="sm" />
                    </td>
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => onViewDetail(p)}
                          className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs flex items-center gap-1 transition-colors"
                          title="Lihat Detail & Riwayat"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Detail</span>
                        </button>

                        {(p.status === 'DRAFT' || p.status === 'PERLU REVISI') && (
                          <button
                            onClick={() => onEditPengajuan(p)}
                            className="px-2.5 py-1 rounded bg-orange-500 hover:bg-orange-600 text-white font-medium text-xs flex items-center gap-1 shadow-xs transition-colors"
                            title="Edit atau Lakukan Revisi"
                          >
                            <FileEdit className="w-3.5 h-3.5" />
                            <span>{p.status === 'PERLU REVISI' ? 'Perbaiki' : 'Edit'}</span>
                          </button>
                        )}

                        <button
                          onClick={() => exportPengajuanToPdf(p, lembaga, cvProfile)}
                          className="p-1 rounded text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Download PDF Resmi ARKAS"
                        >
                          <Download className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => exportSinglePengajuanToExcel(p, lembaga, cvProfile)}
                          className="p-1 rounded text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
                          title="Export Excel"
                        >
                          <FileSpreadsheet className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
