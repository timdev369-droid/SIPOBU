import React, { useState } from 'react';
import { 
  X, 
  Download, 
  FileSpreadsheet, 
  FileEdit, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  User, 
  School,
  ArrowRight,
  ShieldCheck,
  Check,
  MessageSquare
} from 'lucide-react';
import { Pengajuan, Lembaga, CVProfile, UserRole } from '../../types/index.ts';
import { StatusBadge } from '../common/StatusBadge.tsx';
import { formatRupiah, formatDateIndo, formatDateTimeIndo, arkasStorage } from '../../lib/storage.ts';
import { exportPengajuanToPdf } from '../../utils/exportPdf.ts';
import { exportSinglePengajuanToExcel } from '../../utils/exportExcel.ts';
import { WhatsAppNotificationModal } from '../common/WhatsAppNotificationModal.tsx';
import { POFinalWhatsAppModal } from '../common/POFinalWhatsAppModal.tsx';

interface Props {
  pengajuan: Pengajuan;
  lembaga: Lembaga;
  cvProfile: CVProfile;
  currentRole: UserRole;
  onClose: () => void;
  onEdit?: (pengajuan: Pengajuan) => void;
  onOpenCVReview?: (pengajuan: Pengajuan) => void;
}

export const DetailPengajuanModal: React.FC<Props> = ({
  pengajuan,
  lembaga,
  cvProfile,
  currentRole,
  onClose,
  onEdit,
  onOpenCVReview
}) => {
  const [showWaModal, setShowWaModal] = useState(false);
  const [showPOFinalWaModal, setShowPOFinalWaModal] = useState(false);
  const systemSettings = arkasStorage.getSystemSettings();

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-5xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 my-auto">
        {/* Header Modal */}
        <div className="p-4 sm:p-6 border-b border-slate-200 flex items-center justify-between bg-slate-50/70 rounded-t-2xl">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-blue-700 text-sm sm:text-base">
                {pengajuan.nomorPengajuan}
              </span>
              <StatusBadge status={pengajuan.status} size="md" />
            </div>
            <p className="text-xs text-slate-500">
              Pengajuan Kebutuhan Buku Tahun Anggaran {pengajuan.tahunAnggaran} • Tanggal:{' '}
              {formatDateIndo(pengajuan.tanggalPengajuan)}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {(pengajuan.status === 'DISETUJUI' || pengajuan.status === 'SELESAI REKAP') && (
              <button
                onClick={() => setShowPOFinalWaModal(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs transition-colors"
                title="Kirim Berkas PDF PO Otomatis ke WhatsApp Admin CV"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Kirim PDF ke WA Admin</span>
              </button>
            )}

            <button
              onClick={() => exportPengajuanToPdf(pengajuan, lembaga, cvProfile)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs shadow-xs transition-colors"
              title="Unduh Rincian Pengajuan Format PDF"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh PDF</span>
            </button>

            <button
              onClick={() => exportSinglePengajuanToExcel(pengajuan, lembaga, cvProfile)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold text-xs border border-emerald-200 transition-colors"
              title="Export Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Excel</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 text-xs">
          {/* Banner PO Resmi Disetujui / Final */}
          {(pengajuan.status === 'DISETUJUI' || pengajuan.status === 'SELESAI REKAP') && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-950 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-xs uppercase tracking-wider text-emerald-900">
                    Purchase Order (PO) Telah {pengajuan.status === 'SELESAI REKAP' ? 'Final (Selesai Rekap)' : 'Resmi Disetujui'}
                  </h4>
                  <p className="text-[11px] text-emerald-800 mt-0.5">
                    Berkas PO resmi dapat diunduh otomatis dalam format PDF dan diteruskan langsung ke WhatsApp Admin CV Penyedia SIPLah.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPOFinalWaModal(true)}
                className="shrink-0 inline-flex items-center justify-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-xs transition-all cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Kirim File PDF ke WA Admin</span>
              </button>
            </div>
          )}

          {/* Alert Catatan CV jika status PERLU REVISI atau DITOLAK */}
          {pengajuan.catatanCv && (
            <div className={`p-4 rounded-xl border flex items-start gap-3 ${
              pengajuan.status === 'PERLU REVISI'
                ? 'bg-orange-50 border-orange-300 text-orange-900'
                : pengajuan.status === 'DITOLAK'
                ? 'bg-rose-50 border-rose-300 text-rose-900'
                : 'bg-blue-50 border-blue-200 text-blue-900'
            }`}>
              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-current" />
              <div className="space-y-1">
                <h4 className="font-bold text-xs uppercase tracking-wider">
                  Catatan dari CV Penyedia ({cvProfile.namaCv}):
                </h4>
                <p className="text-xs bg-white/80 p-3 rounded-lg border border-current/20 font-medium">
                  "{pengajuan.catatanCv}"
                </p>
                {currentRole === 'LEMBAGA' && pengajuan.status === 'PERLU REVISI' && onEdit && (
                  <div className="pt-1">
                    <button
                      onClick={() => onEdit(pengajuan)}
                      className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white font-semibold rounded-lg shadow-xs transition-colors"
                    >
                      Buka Form untuk Merevisi Pengajuan Sekarang →
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Info 2 Kolom: Lembaga & Ringkasan */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-2 text-slate-700 font-bold border-b border-slate-200 pb-2">
                <School className="w-4 h-4 text-blue-600" />
                <span>Identitas Lembaga Pengaju</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                <span className="text-slate-500">Nama Sekolah</span>
                <span className="col-span-2 font-semibold text-slate-900">: {lembaga.namaLembaga}</span>

                <span className="text-slate-500">NPSN / Jenjang</span>
                <span className="col-span-2 text-slate-800">: {lembaga.npsn} ({lembaga.jenjang} - {lembaga.statusLembaga})</span>

                <span className="text-slate-500">Kecamatan</span>
                <span className="col-span-2 text-slate-800">: {lembaga.kecamatan}, {lembaga.kabupaten}</span>

                <span className="text-slate-500">Kepala Sekolah</span>
                <span className="col-span-2 text-slate-800">: {lembaga.kepalaSekolah}</span>

                <span className="text-slate-500">Operator Sekolah</span>
                <span className="col-span-2 text-slate-800">: {lembaga.operator} ({lembaga.whatsapp})</span>
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-2 text-slate-700 font-bold border-b border-slate-200 pb-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Ringkasan Pengajuan ARKAS</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                <span className="text-slate-500">Tahun Anggaran</span>
                <span className="col-span-2 font-semibold text-slate-900">: {pengajuan.tahunAnggaran}</span>

                <span className="text-slate-500">Total Judul Buku</span>
                <span className="col-span-2 font-semibold text-slate-900">: {pengajuan.totalJenisBuku} Judul</span>

                <span className="text-slate-500">Total Eksemplar</span>
                <span className="col-span-2 font-semibold text-slate-900">: {pengajuan.totalBuku.toLocaleString('id-ID')} Eksemplar</span>

                <span className="text-slate-500">Total Nilai Rencana</span>
                <span className="col-span-2 font-bold text-blue-700 text-sm">: {formatRupiah(pengajuan.totalNilai)}</span>

                <span className="text-slate-500">Keterangan</span>
                <span className="col-span-2 text-slate-700">: {pengajuan.keteranganUmum || '-'}</span>
              </div>
            </div>
          </div>

          {/* Tabel Buku Sesuai Requirement 6 */}
          <div>
            <h4 className="font-bold text-slate-900 text-sm mb-2">
              Rincian Daftar Buku ({pengajuan.items.length} Item)
            </h4>
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3 text-center w-8">No</th>
                    <th className="py-2.5 px-3">Kode & ISBN</th>
                    <th className="py-2.5 px-3">Judul Buku</th>
                    <th className="py-2.5 px-3">Penerbit</th>
                    <th className="py-2.5 px-3">Jenjang/Kelas</th>
                    <th className="py-2.5 px-3 text-center">Jumlah</th>
                    <th className="py-2.5 px-3 text-right">Harga Satuan</th>
                    <th className="py-2.5 px-3 text-right">Total</th>
                    <th className="py-2.5 px-3">Keterangan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {pengajuan.items.map((it, idx) => (
                    <tr key={it.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 text-center font-medium text-slate-500">
                        {idx + 1}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="font-mono font-medium text-slate-900 block">{it.kodeBuku}</span>
                        <span className="font-mono text-[10px] text-slate-400">{it.isbn || '-'}</span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900">
                        {it.judul}
                        <span className="block text-[10px] font-normal text-slate-500 mt-0.5">
                          {it.kurikulum} • Mapel: {it.mataPelajaran}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        {it.penerbit}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        {it.jenjang} - {it.kelas}
                      </td>
                      <td className="py-2.5 px-3 text-center font-bold text-slate-900">
                        {it.jumlah} eks
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-700">
                        {formatRupiah(it.hargaSatuan)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-blue-700">
                        {formatRupiah(it.total)}
                      </td>
                      <td className="py-2.5 px-3 text-slate-500">
                        {it.keterangan || '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-slate-100 font-bold border-t border-slate-200">
                  <tr>
                    <td colSpan={5} className="py-3 px-4 text-slate-700 uppercase">
                      Total Rencana Kebutuhan Buku
                    </td>
                    <td className="py-3 px-3 text-center text-slate-900">
                      {pengajuan.totalBuku.toLocaleString('id-ID')} Eks
                    </td>
                    <td className="py-3 px-3 text-right text-slate-500">
                      -
                    </td>
                    <td className="py-3 px-3 text-right text-blue-800 text-sm">
                      {formatRupiah(pengajuan.totalNilai)}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Riwayat Status Sesuai Requirement 8 & 9 */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5 uppercase tracking-wider">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>Riwayat Perjalanan & Catatan Revisi Pengajuan</span>
            </h4>
            <div className="space-y-3 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {pengajuan.history.map((hist, idx) => (
                <div key={hist.id || idx} className="flex items-start gap-3 relative pl-6">
                  <span className="w-3 h-3 rounded-full bg-blue-600 ring-4 ring-white absolute left-1.5 top-1" />
                  <div className="flex-1 bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs">
                    <div className="flex flex-wrap items-center justify-between gap-1 text-[11px] mb-1">
                      <div className="font-semibold text-slate-800">
                        {hist.userName} <span className="text-slate-400 font-normal">({hist.userRole})</span>
                      </div>
                      <span className="text-slate-400 text-[10px]">
                        {formatDateTimeIndo(hist.createdAt)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mb-1">
                      {hist.statusSebelumnya && (
                        <>
                          <span className="text-slate-500">{hist.statusSebelumnya}</span>
                          <ArrowRight className="w-3 h-3 text-slate-400" />
                        </>
                      )}
                      <StatusBadge status={hist.statusBaru} size="sm" />
                    </div>
                    {hist.catatan && (
                      <p className="text-slate-600 bg-slate-50 p-2 rounded text-[11px] border border-slate-100">
                        {hist.catatan}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50 rounded-b-2xl flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-xl text-xs transition-colors"
          >
            Tutup
          </button>

          <div className="flex flex-wrap items-center gap-2">
            {/* Tombol Unduh PDF Rincian Pengajuan */}
            <button
              onClick={() => exportPengajuanToPdf(pengajuan, lembaga, cvProfile)}
              className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
              title="Unduh Rincian Pengajuan Format PDF Resmi"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh PDF</span>
            </button>

            {/* Action Kirim / Teruskan ke WhatsApp Admin CV */}
            {(pengajuan.status === 'DISETUJUI' || pengajuan.status === 'SELESAI REKAP') ? (
              <button
                onClick={() => setShowPOFinalWaModal(true)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
                title="Unduh & Kirim Berkas PDF PO Resmi ke WhatsApp Admin CV"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Kirim File PDF ke WA Admin</span>
              </button>
            ) : (
              <button
                onClick={() => setShowWaModal(true)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
                title="Kirim / Teruskan rincian pengajuan ke WhatsApp Admin CV"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Kirim ke WA Admin</span>
              </button>
            )}

            {/* Action for CV Role: Verifikasi pengajuan */}
            {currentRole === 'CV' && onOpenCVReview && (
              <button
                onClick={() => {
                  onClose();
                  onOpenCVReview(pengajuan);
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs shadow-md transition-colors"
              >
                Pemeriksaan / Verifikasi Pengajuan CV →
              </button>
            )}

            {/* Action for Lembaga Role: Edit or revise */}
            {currentRole === 'LEMBAGA' && (pengajuan.status === 'DRAFT' || pengajuan.status === 'PERLU REVISI') && onEdit && (
              <button
                onClick={() => {
                  onClose();
                  onEdit(pengajuan);
                }}
                className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-semibold rounded-xl text-xs shadow-md transition-colors"
              >
                {pengajuan.status === 'PERLU REVISI' ? 'Lakukan Revisi & Perbaikan' : 'Edit Pengajuan'}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Modal Notifikasi WhatsApp */}
      {showWaModal && (
        <WhatsAppNotificationModal
          pengajuan={pengajuan}
          lembaga={lembaga}
          cvProfile={cvProfile}
          systemSettings={systemSettings}
          isOpen={showWaModal}
          onClose={() => setShowWaModal(false)}
          autoOpen={false}
        />
      )}

      {/* Modal Otomatisasi Kirim Berkas PDF PO ke WA Admin CV */}
      {showPOFinalWaModal && (
        <POFinalWhatsAppModal
          isOpen={showPOFinalWaModal}
          onClose={() => setShowPOFinalWaModal(false)}
          pengajuan={pengajuan}
          lembaga={lembaga}
          cvProfile={cvProfile}
          systemSettings={systemSettings}
          autoTrigger={true}
        />
      )}
    </div>
  );
};
