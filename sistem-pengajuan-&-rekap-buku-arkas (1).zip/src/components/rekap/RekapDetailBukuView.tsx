import React, { useState } from 'react';
import { 
  BookMarked, 
  Search, 
  Download, 
  FileSpreadsheet, 
  Filter, 
  ArrowUpDown, 
  Building2,
  BookOpen
} from 'lucide-react';
import { Pengajuan, Lembaga, CVProfile, PengajuanItem } from '../../types/index.ts';
import { formatRupiah } from '../../lib/storage.ts';
import * as XLSX from 'xlsx';

interface Props {
  pengajuanList: Pengajuan[];
  lembagaList: Lembaga[];
  cvProfile: CVProfile;
}

interface FlattenedBookItem {
  key: string;
  nomorPengajuan: string;
  lembagaName: string;
  npsn: string;
  kecamatan: string;
  item: PengajuanItem;
}

export const RekapDetailBukuView: React.FC<Props> = ({
  pengajuanList,
  lembagaList,
  cvProfile
}) => {
  const [search, setSearch] = useState('');
  const [filterPenerbit, setFilterPenerbit] = useState('Semua');
  const [filterJenjang, setFilterJenjang] = useState('Semua');
  const [sortField, setSortField] = useState<'judul' | 'jumlah' | 'total'>('judul');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 15;

  // Flatten all items across all pengajuan
  const allItems: FlattenedBookItem[] = [];
  pengajuanList.forEach(p => {
    const lem = lembagaList.find(l => l.id === p.lembagaId);
    p.items.forEach(it => {
      allItems.push({
        key: `${p.id}-${it.id}`,
        nomorPengajuan: p.nomorPengajuan,
        lembagaName: lem ? lem.namaLembaga : 'Lembaga',
        npsn: lem ? lem.npsn : '-',
        kecamatan: lem ? lem.kecamatan : '-',
        item: it
      });
    });
  });

  const penerbitOptions = Array.from(new Set(allItems.map(i => i.item.penerbit)));

  // Filter
  const filtered = allItems.filter(entry => {
    const q = search.toLowerCase();
    const matchSearch = 
      entry.item.judul.toLowerCase().includes(q) ||
      entry.item.kodeBuku.toLowerCase().includes(q) ||
      entry.item.isbn.includes(q) ||
      entry.lembagaName.toLowerCase().includes(q) ||
      entry.item.penerbit.toLowerCase().includes(q) ||
      entry.nomorPengajuan.toLowerCase().includes(q);

    const matchPenerbit = filterPenerbit === 'Semua' || entry.item.penerbit === filterPenerbit;
    const matchJenjang = filterJenjang === 'Semua' || entry.item.jenjang === filterJenjang;

    return matchSearch && matchPenerbit && matchJenjang;
  });

  // Sort
  filtered.sort((a, b) => {
    let comp = 0;
    if (sortField === 'judul') {
      comp = a.item.judul.localeCompare(b.item.judul);
    } else if (sortField === 'jumlah') {
      comp = a.item.jumlah - b.item.jumlah;
    } else if (sortField === 'total') {
      comp = a.item.total - b.item.total;
    }
    return sortOrder === 'asc' ? comp : -comp;
  });

  // Pagination
  const totalPages = Math.ceil(filtered.length / itemsPerPage) || 1;
  const paginated = filtered.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const totalQtyFiltered = filtered.reduce((acc, curr) => acc + curr.item.jumlah, 0);
  const totalNilaiFiltered = filtered.reduce((acc, curr) => acc + curr.item.total, 0);

  const handleExportThisDetail = () => {
    const exportData = filtered.map((e, idx) => ({
      No: idx + 1,
      'Kode Buku': e.item.kodeBuku,
      ISBN: e.item.isbn,
      'Judul Buku': e.item.judul,
      Penerbit: e.item.penerbit,
      Jenjang: e.item.jenjang,
      Kelas: e.item.kelas,
      'Mata Pelajaran': e.item.mataPelajaran,
      'Lembaga Pengaju': e.lembagaName,
      NPSN: e.npsn,
      Kecamatan: e.kecamatan,
      'Nomor Pengajuan': e.nomorPengajuan,
      'Jumlah (Eks)': e.item.jumlah,
      'Harga Satuan (Rp)': e.item.hargaSatuan,
      'Total Rencana (Rp)': e.item.total,
      Keterangan: e.item.keterangan || '-'
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Rekap Detail Buku');
    XLSX.writeFile(wb, `Rekap_Detail_Buku_ARKAS_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <BookMarked className="w-5 h-5 text-blue-600" />
            <span>Rekapitulasi Kebutuhan Detail Per Judul Buku</span>
          </h2>
          <p className="text-xs text-slate-500">
            Daftar lengkap kebutuhan eksemplar per item buku di seluruh satuan pendidikan pengaju.
          </p>
        </div>

        <button
          onClick={handleExportThisDetail}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs transition-colors self-start sm:self-auto"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Export Excel Tabel Ini</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3 text-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Cari judul buku, kode, ISBN, nama sekolah, atau nomor pengajuan..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={filterJenjang}
            onChange={(e) => {
              setFilterJenjang(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium"
          >
            <option value="Semua">Semua Jenjang</option>
            <option value="SD">SD</option>
            <option value="SMP">SMP</option>
            <option value="SMA">SMA</option>
            <option value="SMK">SMK</option>
            <option value="PAUD">PAUD/TK</option>
          </select>

          <select
            value={filterPenerbit}
            onChange={(e) => {
              setFilterPenerbit(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium max-w-[200px]"
          >
            <option value="Semua">Semua Penerbit</option>
            {penerbitOptions.map(p => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>

          <select
            value={`${sortField}-${sortOrder}`}
            onChange={(e) => {
              const [f, o] = e.target.value.split('-');
              setSortField(f as any);
              setSortOrder(o as any);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium"
          >
            <option value="judul-asc">Judul (A-Z)</option>
            <option value="judul-desc">Judul (Z-A)</option>
            <option value="jumlah-desc">Jumlah Terbanyak</option>
            <option value="jumlah-asc">Jumlah Tersedikit</option>
            <option value="total-desc">Nilai Terbesar</option>
          </select>
        </div>
      </div>

      {/* Ringkasan Akumulasi */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-slate-100 p-3 rounded-xl border border-slate-200">
        <span className="text-slate-600">
          Menampilkan <strong>{filtered.length}</strong> baris item buku
        </span>
        <div className="flex items-center gap-6">
          <span>
            Total Kebutuhan: <strong className="text-slate-900 font-bold">{totalQtyFiltered.toLocaleString('id-ID')} Eksemplar</strong>
          </span>
          <span>
            Total Nilai: <strong className="text-blue-800 font-extrabold">{formatRupiah(totalNilaiFiltered)}</strong>
          </span>
        </div>
      </div>

      {/* Tabel Detail Buku Sesuai Requirement 13 */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-3 text-center w-10">No</th>
                <th className="py-3 px-3">Kode & ISBN</th>
                <th className="py-3 px-3 min-w-[220px]">Judul Buku</th>
                <th className="py-3 px-3">Penerbit</th>
                <th className="py-3 px-3">Lembaga Pengaju</th>
                <th className="py-3 px-3 text-center">Jumlah</th>
                <th className="py-3 px-3 text-right">Harga Satuan</th>
                <th className="py-3 px-3 text-right">Total Rencana</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    Tidak ditemukan item buku yang cocok dengan pencarian.
                  </td>
                </tr>
              ) : (
                paginated.map((entry, idx) => (
                  <tr key={entry.key} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 text-center text-slate-500 font-medium">
                      {(currentPage - 1) * itemsPerPage + idx + 1}
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-mono font-semibold text-blue-700 block text-[11px]">
                        {entry.item.kodeBuku}
                      </span>
                      <span className="font-mono text-[10px] text-slate-400">
                        ISBN: {entry.item.isbn || '-'}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900 leading-snug">
                        {entry.item.judul}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {entry.item.jenjang} - {entry.item.kelas} • Mapel: {entry.item.mataPelajaran}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-600">
                      {entry.item.penerbit}
                    </td>
                    <td className="py-3 px-3">
                      <strong className="text-slate-900 block">{entry.lembagaName}</strong>
                      <span className="text-[10px] text-slate-500">
                        NPSN: {entry.npsn} ({entry.kecamatan}) • <span className="font-mono text-blue-700">{entry.nomorPengajuan}</span>
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center font-bold text-slate-900 whitespace-nowrap">
                      {entry.item.jumlah} eks
                    </td>
                    <td className="py-3 px-3 text-right text-slate-700 whitespace-nowrap">
                      {formatRupiah(entry.item.hargaSatuan)}
                    </td>
                    <td className="py-3 px-3 text-right font-bold text-blue-800 whitespace-nowrap">
                      {formatRupiah(entry.item.total)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
            <span className="text-slate-500">
              Halaman {currentPage} dari {totalPages}
            </span>
            <div className="flex items-center gap-1">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                className="px-3 py-1 rounded bg-white border border-slate-300 disabled:opacity-40 font-medium"
              >
                Sebelumnya
              </button>
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                className="px-3 py-1 rounded bg-white border border-slate-300 disabled:opacity-40 font-medium"
              >
                Berikutnya
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
