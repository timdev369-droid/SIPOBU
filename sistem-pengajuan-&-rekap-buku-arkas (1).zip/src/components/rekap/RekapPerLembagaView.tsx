import React, { useState } from 'react';
import { 
  Building2, 
  Search, 
  ChevronDown, 
  ChevronUp, 
  BookOpen, 
  School, 
  MapPin, 
  Download, 
  FileSpreadsheet, 
  ExternalLink,
  Coins
} from 'lucide-react';
import { Lembaga, Pengajuan, CVProfile } from '../../types/index.ts';
import { StatusBadge } from '../common/StatusBadge.tsx';
import { formatRupiah, formatDateIndo } from '../../lib/storage.ts';
import { exportPengajuanToPdf } from '../../utils/exportPdf.ts';
import { exportSinglePengajuanToExcel } from '../../utils/exportExcel.ts';

interface Props {
  lembagaList: Lembaga[];
  pengajuanList: Pengajuan[];
  cvProfile: CVProfile;
  initialSelectedLembagaId?: string;
  onViewDetailPengajuan: (pengajuan: Pengajuan) => void;
}

export const RekapPerLembagaView: React.FC<Props> = ({
  lembagaList,
  pengajuanList,
  cvProfile,
  initialSelectedLembagaId,
  onViewDetailPengajuan
}) => {
  const [selectedLembagaId, setSelectedLembagaId] = useState<string>(
    initialSelectedLembagaId || (lembagaList[0]?.id || '')
  );
  const [search, setSearch] = useState<string>('');
  const [expandedPengajuanId, setExpandedPengajuanId] = useState<string | null>(null);

  const activeLembaga = lembagaList.find(l => l.id === selectedLembagaId) || lembagaList[0];
  const activeLembagaPengajuan = activeLembaga 
    ? pengajuanList.filter(p => p.lembagaId === activeLembaga.id) 
    : [];

  const totalBukuLembaga = activeLembagaPengajuan.reduce((acc, p) => acc + p.totalBuku, 0);
  const totalNilaiLembaga = activeLembagaPengajuan.reduce((acc, p) => acc + p.totalNilai, 0);

  const filteredLembaga = lembagaList.filter(l => 
    l.namaLembaga.toLowerCase().includes(search.toLowerCase()) ||
    l.npsn.includes(search) ||
    l.kecamatan.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Building2 className="w-5 h-5 text-blue-600" />
          <span>Rekapitulasi Kebutuhan Buku Per Satuan Pendidikan</span>
        </h2>
        <p className="text-xs text-slate-500">
          Pemeriksaan rincian buku yang dianggarkan per sekolah beserta rekapitulasi nilai anggaran ARKAS.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Kolom Kiri: Daftar Sekolah */}
        <div className="lg:col-span-4 space-y-3">
          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
            <div className="relative mb-2 text-xs">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Cari sekolah atau NPSN..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-8 pr-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:bg-white"
              />
            </div>

            <div className="space-y-1.5 max-h-[600px] overflow-y-auto pr-1 text-xs">
              {filteredLembaga.map(lem => {
                const pCount = pengajuanList.filter(p => p.lembagaId === lem.id).length;
                const isSelected = lem.id === activeLembaga?.id;

                return (
                  <button
                    key={lem.id}
                    onClick={() => {
                      setSelectedLembagaId(lem.id);
                      setExpandedPengajuanId(null);
                    }}
                    className={`w-full text-left p-3 rounded-xl border transition-all flex flex-col gap-1 ${
                      isSelected
                        ? 'bg-blue-50 border-blue-400 text-blue-950 font-semibold shadow-xs'
                        : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-1.5 py-0.5 rounded bg-slate-100 text-[10px] font-bold text-slate-600">
                        {lem.jenjang}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        NPSN: {lem.npsn}
                      </span>
                    </div>
                    <div className="font-bold text-xs truncate">{lem.namaLembaga}</div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span>Kec. {lem.kecamatan}</span>
                      <span className="font-semibold text-blue-700">{pCount} Pengajuan</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Kolom Kanan: Rincian Pengajuan Lembaga Terpilih */}
        <div className="lg:col-span-8 space-y-5">
          {activeLembaga ? (
            <>
              {/* Profil Header Lembaga */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-slate-100 pb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold">
                        {activeLembaga.jenjang} • {activeLembaga.statusLembaga}
                      </span>
                      <span className="font-mono text-xs text-slate-500 font-semibold">
                        NPSN: {activeLembaga.npsn}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900">
                      {activeLembaga.namaLembaga}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{activeLembaga.alamat}, Kec. {activeLembaga.kecamatan}, Kab. {activeLembaga.kabupaten}</span>
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 p-3 rounded-xl">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Kepala Sekolah</span>
                    <strong className="text-slate-800 text-xs block">{activeLembaga.kepalaSekolah}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Operator Sekolah</span>
                    <strong className="text-slate-800 text-xs block">{activeLembaga.operator}</strong>
                    <span className="text-[10px] text-slate-400">{activeLembaga.whatsapp}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Total Buku Direncanakan</span>
                    <strong className="text-slate-900 text-xs block">{totalBukuLembaga.toLocaleString('id-ID')} Eks</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Total Nilai Rencana ARKAS</span>
                    <strong className="text-blue-800 text-sm block font-extrabold">{formatRupiah(totalNilaiLembaga)}</strong>
                  </div>
                </div>
              </div>

              {/* Daftar Pengajuan Sekolah Ini */}
              <div className="space-y-4">
                <h4 className="font-bold text-slate-900 text-sm">
                  Daftar Berkas Pengajuan ({activeLembagaPengajuan.length} Berkas)
                </h4>

                {activeLembagaPengajuan.length === 0 ? (
                  <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
                    Sekolah ini belum memiliki riwayat pengajuan buku.
                  </div>
                ) : (
                  activeLembagaPengajuan.map(p => {
                    const isExpanded = expandedPengajuanId === p.id;
                    return (
                      <div key={p.id} className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                        {/* Header Berkas */}
                        <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/70 border-b border-slate-200">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-blue-700 text-sm">{p.nomorPengajuan}</span>
                              <StatusBadge status={p.status} size="sm" />
                              <span className="text-xs text-slate-500 font-mono">TA {p.tahunAnggaran}</span>
                            </div>
                            <div className="text-xs text-slate-500">
                              Tanggal Pengajuan: {formatDateIndo(p.tanggalPengajuan)} • {p.totalJenisBuku} Judul • {p.totalBuku} Eksemplar
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-sm mr-2">
                              {formatRupiah(p.totalNilai)}
                            </span>

                            <button
                              onClick={() => exportPengajuanToPdf(p, activeLembaga, cvProfile)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              title="Export PDF Resmi"
                            >
                              <Download className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => exportSinglePengajuanToExcel(p, activeLembaga, cvProfile)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
                              title="Export Excel"
                            >
                              <FileSpreadsheet className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => setExpandedPengajuanId(isExpanded ? null : p.id)}
                              className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                            >
                              <span>{isExpanded ? 'Tutup Rincian' : 'Buka Rincian Buku'}</span>
                              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </div>

                        {/* Rincian Buku Dropdown (Expandable) Sesuai Requirement 11 */}
                        {isExpanded && (
                          <div className="p-4 text-xs space-y-3">
                            {p.keteranganUmum && (
                              <p className="text-slate-600 italic bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                                Keterangan Sekolah: "{p.keteranganUmum}"
                              </p>
                            )}

                            <div className="border border-slate-200 rounded-xl overflow-hidden">
                              <table className="w-full text-left text-xs">
                                <thead className="bg-slate-100 text-slate-600 font-semibold uppercase border-b border-slate-200">
                                  <tr>
                                    <th className="py-2 px-3 text-center w-8">No</th>
                                    <th className="py-2 px-3">Judul Buku & Penerbit</th>
                                    <th className="py-2 px-3">ISBN</th>
                                    <th className="py-2 px-3 text-center">Jumlah</th>
                                    <th className="py-2 px-3 text-right">Harga Satuan</th>
                                    <th className="py-2 px-3 text-right">Total</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                  {p.items.map((it, idx) => (
                                    <tr key={it.id} className="hover:bg-slate-50">
                                      <td className="py-2 px-3 text-center text-slate-500">{idx + 1}</td>
                                      <td className="py-2 px-3 font-semibold text-slate-800">
                                        {it.judul}
                                        <span className="block text-[10px] text-slate-400 font-normal">
                                          {it.penerbit} • {it.jenjang} ({it.kelas})
                                        </span>
                                      </td>
                                      <td className="py-2 px-3 font-mono text-slate-500">{it.isbn || '-'}</td>
                                      <td className="py-2 px-3 text-center font-bold text-slate-900">{it.jumlah} eks</td>
                                      <td className="py-2 px-3 text-right text-slate-600">{formatRupiah(it.hargaSatuan)}</td>
                                      <td className="py-2 px-3 text-right font-bold text-blue-700">{formatRupiah(it.total)}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </>
          ) : (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-400">
              Pilih salah satu lembaga dari daftar di sebelah kiri untuk melihat rekapitulasi.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
