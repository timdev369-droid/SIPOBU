import React, { useState } from 'react';
import { 
  BarChart3, 
  Search, 
  Filter, 
  Download, 
  FileSpreadsheet, 
  Eye, 
  Calendar,
  Layers,
  Coins,
  School,
  FileCheck
} from 'lucide-react';
import { Pengajuan, Lembaga, CVProfile, RekapFilterOptions } from '../../types/index.ts';
import { StatusBadge } from '../common/StatusBadge.tsx';
import { formatRupiah, formatDateIndo } from '../../lib/storage.ts';
import { exportRekapToExcel } from '../../utils/exportExcel.ts';
import { exportRekapKeseluruhanToPdf } from '../../utils/exportPdf.ts';

interface Props {
  pengajuanList: Pengajuan[];
  lembagaList: Lembaga[];
  cvProfile: CVProfile;
  onViewDetail: (pengajuan: Pengajuan) => void;
}

export const RekapKeseluruhanView: React.FC<Props> = ({
  pengajuanList,
  lembagaList,
  cvProfile,
  onViewDetail
}) => {
  // Filter states sesuai Requirement 12
  const [tahunAnggaran, setTahunAnggaran] = useState<string>('Semua');
  const [filterKecamatan, setFilterKecamatan] = useState<string>('Semua');
  const [filterJenjang, setFilterJenjang] = useState<string>('Semua');
  const [filterLembagaId, setFilterLembagaId] = useState<string>('Semua');
  const [filterStatus, setFilterStatus] = useState<string>('Semua');
  const [search, setSearch] = useState<string>('');

  const kecamatanOptions = Array.from(new Set(lembagaList.map(l => l.kecamatan)));

  // Proses Filter
  const filtered = pengajuanList.filter(p => {
    const lem = lembagaList.find(l => l.id === p.lembagaId);

    const matchTahun = tahunAnggaran === 'Semua' || p.tahunAnggaran === tahunAnggaran;
    const matchKecamatan = filterKecamatan === 'Semua' || (lem && lem.kecamatan === filterKecamatan);
    const matchJenjang = filterJenjang === 'Semua' || (lem && lem.jenjang === filterJenjang);
    const matchLembaga = filterLembagaId === 'Semua' || p.lembagaId === filterLembagaId;
    const matchStatus = filterStatus === 'Semua' || p.status === filterStatus;

    const q = search.toLowerCase();
    const matchSearch = 
      p.nomorPengajuan.toLowerCase().includes(q) ||
      (lem && lem.namaLembaga.toLowerCase().includes(q)) ||
      (lem && lem.npsn.includes(q)) ||
      p.items.some(it => it.judul.toLowerCase().includes(q));

    return matchTahun && matchKecamatan && matchJenjang && matchLembaga && matchStatus && matchSearch;
  });

  const totalBuku = filtered.reduce((acc, p) => acc + p.totalBuku, 0);
  const totalNilai = filtered.reduce((acc, p) => acc + p.totalNilai, 0);

  return (
    <div className="space-y-6">
      {/* Header & Export Actions */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <span>Rekapitulasi Keseluruhan Pengajuan Buku ARKAS</span>
          </h2>
          <p className="text-xs text-slate-500">
            Daftar seluruh usulan kebutuhan buku dari seluruh sekolah untuk perencanaan & penganggaran ARKAS ({cvProfile.namaCv}).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => exportRekapToExcel(filtered, lembagaList, cvProfile, tahunAnggaran === 'Semua' ? '2026' : tahunAnggaran)}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs transition-colors"
            title="Download Excel 3 Sheets: Rekap Pengajuan, Detail Buku, Rekap Per Lembaga"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Excel (3 Sheets)</span>
          </button>

          <button
            onClick={() => exportRekapKeseluruhanToPdf(filtered, lembagaList, cvProfile, tahunAnggaran === 'Semua' ? '2026' : tahunAnggaran)}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs shadow-xs transition-colors"
            title="Download Dokumen PDF Resmi Rekapitulasi"
          >
            <Download className="w-4 h-4" />
            <span>Export PDF Rekap</span>
          </button>
        </div>
      </div>

      {/* Filter Panel Multi-Kriteria (Requirement 12) */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3 text-xs">
        <div className="flex items-center gap-2 font-bold text-slate-700 border-b border-slate-100 pb-2">
          <Filter className="w-4 h-4 text-blue-600" />
          <span>Filter Multi-Kriteria Pengajuan ARKAS</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {/* 1. Tahun Anggaran */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Tahun Anggaran</label>
            <select
              value={tahunAnggaran}
              onChange={(e) => setTahunAnggaran(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="Semua">Semua Tahun</option>
              <option value="2026">2026</option>
              <option value="2027">2027</option>
              <option value="2025">2025</option>
            </select>
          </div>

          {/* 2. Kecamatan */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Kecamatan</label>
            <select
              value={filterKecamatan}
              onChange={(e) => setFilterKecamatan(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="Semua">Semua Kecamatan</option>
              {kecamatanOptions.map(kec => (
                <option key={kec} value={kec}>{kec}</option>
              ))}
            </select>
          </div>

          {/* 3. Jenjang */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Jenjang</label>
            <select
              value={filterJenjang}
              onChange={(e) => setFilterJenjang(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="Semua">Semua Jenjang</option>
              <option value="SD">SD</option>
              <option value="SMP">SMP</option>
              <option value="SMA">SMA</option>
              <option value="SMK">SMK</option>
              <option value="PAUD">PAUD</option>
              <option value="TK">TK</option>
            </select>
          </div>

          {/* 4. Status Pengajuan */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Status Pengajuan</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="Semua">Semua Status</option>
              <option value="DIKIRIM LEMBAGA">Menunggu CV</option>
              <option value="DIPERIKSA CV">Diperiksa CV</option>
              <option value="PERLU REVISI">Perlu Revisi</option>
              <option value="DISETUJUI">Disetujui</option>
              <option value="SELESAI REKAP">Selesai Rekap</option>
              <option value="DITOLAK">Ditolak</option>
              <option value="DRAFT">Draft</option>
            </select>
          </div>

          {/* 5. Lembaga / Sekolah */}
          <div className="sm:col-span-2">
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Pilih Lembaga Spesifik</label>
            <select
              value={filterLembagaId}
              onChange={(e) => setFilterLembagaId(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="Semua">Semua Lembaga ({lembagaList.length} Sekolah)</option>
              {lembagaList.map(lem => (
                <option key={lem.id} value={lem.id}>
                  {lem.namaLembaga} (NPSN: {lem.npsn})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Search Bar */}
        <div className="pt-1">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Cari kata kunci: nomor pengajuan, nama sekolah, NPSN, atau judul buku..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>
        </div>
      </div>

      {/* Ringkasan Akumulasi Filter */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">Pengajuan Terfilter:</span>
          <strong className="text-base text-slate-900 font-bold">{filtered.length} Berkas</strong>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">Total Volume Buku:</span>
          <strong className="text-base text-blue-700 font-bold">{totalBuku.toLocaleString('id-ID')} Eksemplar</strong>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">Total Nilai Rencana ARKAS:</span>
          <strong className="text-base text-emerald-700 font-bold">{formatRupiah(totalNilai)}</strong>
        </div>
      </div>

      {/* Tabel Matriks Rekapitulasi Sesuai Requirement 12 */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-3 text-center w-10">No</th>
                <th className="py-3 px-3">Lembaga / Sekolah</th>
                <th className="py-3 px-3 text-center">NPSN</th>
                <th className="py-3 px-3 text-center">Jenjang</th>
                <th className="py-3 px-3">Kecamatan</th>
                <th className="py-3 px-3">Nomor Pengajuan</th>
                <th className="py-3 px-3 text-right">Jumlah Buku</th>
                <th className="py-3 px-3 text-right">Total Nilai Rencana</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    Tidak ada pengajuan yang sesuai dengan kriteria filter.
                  </td>
                </tr>
              ) : (
                filtered.map((p, idx) => {
                  const lem = lembagaList.find(l => l.id === p.lembagaId);
                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-3 text-center text-slate-500 font-medium">
                        {idx + 1}
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-900">
                        {lem ? lem.namaLembaga : '-'}
                        <span className="block text-[10px] text-slate-400 font-normal">
                          {p.tahunAnggaran} • {formatDateIndo(p.tanggalPengajuan)}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center font-mono text-slate-700">
                        {lem ? lem.npsn : '-'}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span className="px-2 py-0.5 rounded bg-slate-100 font-semibold text-slate-700 text-[10px]">
                          {lem ? lem.jenjang : '-'}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-700">
                        {lem ? lem.kecamatan : '-'}
                      </td>
                      <td className="py-3 px-3 font-mono font-semibold text-blue-700">
                        {p.nomorPengajuan}
                      </td>
                      <td className="py-3 px-3 text-right font-medium text-slate-900 whitespace-nowrap">
                        {p.totalBuku.toLocaleString('id-ID')} Eks
                        <span className="block text-[10px] text-slate-400">({p.totalJenisBuku} judul)</span>
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-slate-900 whitespace-nowrap">
                        {formatRupiah(p.totalNilai)}
                      </td>
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <StatusBadge status={p.status} size="sm" />
                      </td>
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <button
                          onClick={() => onViewDetail(p)}
                          className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs inline-flex items-center gap-1 transition-colors"
                          title="Lihat Detail & Dokumen"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Detail</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            {filtered.length > 0 && (
              <tfoot className="bg-slate-100 font-bold border-t border-slate-200">
                <tr>
                  <td colSpan={6} className="py-3.5 px-4 text-slate-800 uppercase tracking-wider">
                    TOTAL KESELURUHAN HASIL FILTER:
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-900">
                    {totalBuku.toLocaleString('id-ID')} Eks
                  </td>
                  <td className="py-3.5 px-3 text-right text-blue-900 text-sm">
                    {formatRupiah(totalNilai)}
                  </td>
                  <td colSpan={2}></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};
