/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  arkasStorage, 
  formatRupiah, 
  formatDateIndo,
  INITIAL_CV_PROFILE 
} from './lib/storage.ts';
import { 
  User, 
  Lembaga, 
  Pengajuan, 
  CVProfile, 
  StatusPengajuan 
} from './types/index.ts';

// Common Components
import { Navbar } from './components/common/Navbar.tsx';
import { Sidebar } from './components/common/Sidebar.tsx';
import { StatusBadge } from './components/common/StatusBadge.tsx';
import { AuditLogModal } from './components/common/AuditLogModal.tsx';
import { ProfilModal } from './components/common/ProfilModal.tsx';

// Lembaga Components
import { DashboardLembaga } from './components/lembaga/DashboardLembaga.tsx';
import { FormPengajuanBuku } from './components/lembaga/FormPengajuanBuku.tsx';
import { DetailPengajuanModal } from './components/lembaga/DetailPengajuanModal.tsx';
import { RiwayatPengajuanLembaga } from './components/lembaga/RiwayatPengajuanLembaga.tsx';

// CV Components
import { DashboardCV } from './components/cv/DashboardCV.tsx';
import { ReviewPengajuanModal } from './components/cv/ReviewPengajuanModal.tsx';
import { MasterBukuView } from './components/cv/MasterBukuView.tsx';
import { DataLembagaView } from './components/cv/DataLembagaView.tsx';
import { SuperAdminSettingsView } from './components/cv/SuperAdminSettingsView.tsx';

// Rekap Views
import { RekapKeseluruhanView } from './components/rekap/RekapKeseluruhanView.tsx';
import { RekapPerLembagaView } from './components/rekap/RekapPerLembagaView.tsx';
import { RekapDetailBukuView } from './components/rekap/RekapDetailBukuView.tsx';

// Auth Components
import { AuthModal } from './components/auth/AuthModal.tsx';
import { RegisterModal } from './components/auth/RegisterModal.tsx';

// Export Utilities
import { exportRekapToExcel } from './utils/exportExcel.ts';
import { exportRekapKeseluruhanToPdf } from './utils/exportPdf.ts';

// Icons
import { 
  FileSpreadsheet, 
  Download, 
  Bell, 
  Settings, 
  History, 
  AlertCircle, 
  PlusCircle, 
  CheckCircle2, 
  Eye, 
  FileEdit, 
  RotateCcw,
  Sparkles,
  Menu,
  X
} from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(arkasStorage.getCurrentUser());
  const [currentLembaga, setCurrentLembaga] = useState<Lembaga | null>(arkasStorage.getCurrentLembaga());
  const [cvProfile, setCvProfile] = useState<CVProfile>(arkasStorage.getCVProfile());

  const [allPengajuan, setAllPengajuan] = useState<Pengajuan[]>(arkasStorage.getAllPengajuan());
  const [allLembaga, setAllLembaga] = useState<Lembaga[]>(arkasStorage.getAllLembaga());

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Modals state
  const [selectedPengajuanDetail, setSelectedPengajuanDetail] = useState<Pengajuan | null>(null);
  const [selectedPengajuanReview, setSelectedPengajuanReview] = useState<Pengajuan | null>(null);
  const [editingPengajuan, setEditingPengajuan] = useState<Pengajuan | null>(null);

  const [showAuthModal, setShowAuthModal] = useState<boolean>(!currentUser);
  const [showRegisterModal, setShowRegisterModal] = useState<boolean>(false);
  const [showAuditLogModal, setShowAuditLogModal] = useState<boolean>(false);
  const [showProfileModal, setShowProfileModal] = useState<boolean>(false);
  const [showNotificationsModal, setShowNotificationsModal] = useState<boolean>(false);

  // Mobile sidebar toggle
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);

  // Filter khusus jika klik dari data lembaga ke rekap per lembaga
  const [drilldownLembagaId, setDrilldownLembagaId] = useState<string | undefined>(undefined);

  // Re-subscribe ke storage updates
  useEffect(() => {
    const unsubscribe = arkasStorage.subscribe(() => {
      const u = arkasStorage.getCurrentUser();
      const l = arkasStorage.getCurrentLembaga();
      setCurrentUser(u);
      setCurrentLembaga(l);
      setCvProfile(arkasStorage.getCVProfile());
      setAllPengajuan(arkasStorage.getAllPengajuan());
      setAllLembaga(arkasStorage.getAllLembaga());
    });
    return () => unsubscribe();
  }, []);

  // Filter pengajuan khusus lembaga yang login
  const lembagaPengajuanList = currentLembaga 
    ? allPengajuan.filter(p => p.lembagaId === currentLembaga.id) 
    : [];

  // Hitung badge notifikasi
  const badgeCounts = {
    masuk: allPengajuan.filter(p => p.status === 'DIKIRIM LEMBAGA').length,
    revisi: currentUser?.role === 'CV'
      ? allPengajuan.filter(p => p.status === 'PERLU REVISI').length
      : lembagaPengajuanList.filter(p => p.status === 'PERLU REVISI').length,
    disetujui: allPengajuan.filter(p => p.status === 'DISETUJUI').length,
    ditolak: allPengajuan.filter(p => p.status === 'DITOLAK').length
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setMobileSidebarOpen(false);
    if (tab === 'pengajuan-baru') {
      setEditingPengajuan(null);
    }
    if (tab === 'export-excel') {
      exportRekapToExcel(
        currentUser?.role === 'CV' ? allPengajuan : lembagaPengajuanList,
        allLembaga,
        cvProfile,
        cvProfile.tahunAnggaranAktif
      );
    }
    if (tab === 'export-pdf') {
      exportRekapKeseluruhanToPdf(
        currentUser?.role === 'CV' ? allPengajuan : lembagaPengajuanList,
        allLembaga,
        cvProfile,
        cvProfile.tahunAnggaranAktif
      );
    }
    if (tab === 'notifikasi') {
      setShowNotificationsModal(true);
    }
    if (tab === 'profil-lembaga' || tab === 'profil-cv' || tab === 'pengaturan-akun') {
      setShowProfileModal(true);
    }
    if (tab === 'riwayat-aktivitas') {
      setShowAuditLogModal(true);
    }
  };

  const handleLogout = () => {
    arkasStorage.setCurrentUser(null);
    setShowAuthModal(true);
  };

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    setCurrentLembaga(arkasStorage.getCurrentLembaga());
    setShowAuthModal(false);
    setShowRegisterModal(false);
    setActiveTab('dashboard');
  };

  const handleReviewDecision = (pengajuanId: string, newStatus: StatusPengajuan, catatan: string) => {
    arkasStorage.updatePengajuanStatusByCV(pengajuanId, newStatus, catatan);
    // Refresh
    setAllPengajuan(arkasStorage.getAllPengajuan());
  };

  // Render Konten Utama berdasarkan role & activeTab
  const renderMainContent = () => {
    // FORM PENGAJUAN BARU / EDIT REVISI (LEMBAGA)
    if (activeTab === 'pengajuan-baru' || (editingPengajuan && currentUser?.role === 'LEMBAGA')) {
      if (!currentLembaga) {
        return (
          <div className="p-8 text-center text-slate-500">
            Profil lembaga tidak ditemukan.
          </div>
        );
      }
      return (
        <FormPengajuanBuku
          lembaga={currentLembaga}
          cvProfile={cvProfile}
          initialPengajuan={editingPengajuan}
          onSuccess={(p) => {
            setEditingPengajuan(null);
            setActiveTab('pengajuan-buku');
            setSelectedPengajuanDetail(p);
          }}
          onCancel={() => {
            setEditingPengajuan(null);
            setActiveTab('dashboard');
          }}
        />
      );
    }

    // ROLE LEMBAGA
    if (currentUser?.role === 'LEMBAGA') {
      if (!currentLembaga) {
        return (
          <div className="p-8 text-center text-slate-500">
            Lembaga tidak ditemukan untuk akun ini.
          </div>
        );
      }

      switch (activeTab) {
        case 'dashboard':
          return (
            <DashboardLembaga
              lembaga={currentLembaga}
              pengajuanList={lembagaPengajuanList}
              cvProfile={cvProfile}
              onCreateNew={() => {
                setEditingPengajuan(null);
                setActiveTab('pengajuan-baru');
              }}
              onViewDetail={(p) => setSelectedPengajuanDetail(p)}
              onEditPengajuan={(p) => {
                setEditingPengajuan(p);
                setActiveTab('pengajuan-baru');
              }}
            />
          );

        case 'pengajuan-buku':
        case 'riwayat-pengajuan':
          return (
            <RiwayatPengajuanLembaga
              lembaga={currentLembaga}
              cvProfile={cvProfile}
              pengajuanList={lembagaPengajuanList}
              title={activeTab === 'riwayat-pengajuan' ? 'Riwayat Pengajuan Buku Sekolah' : 'Daftar Pengajuan Buku ARKAS'}
              onCreateNew={() => {
                setEditingPengajuan(null);
                setActiveTab('pengajuan-baru');
              }}
              onViewDetail={(p) => setSelectedPengajuanDetail(p)}
              onEditPengajuan={(p) => {
                setEditingPengajuan(p);
                setActiveTab('pengajuan-baru');
              }}
            />
          );

        case 'rekap':
          return (
            <RekapKeseluruhanView
              pengajuanList={lembagaPengajuanList}
              lembagaList={allLembaga}
              cvProfile={cvProfile}
              onViewDetail={(p) => setSelectedPengajuanDetail(p)}
            />
          );

        default:
          return (
            <DashboardLembaga
              lembaga={currentLembaga}
              pengajuanList={lembagaPengajuanList}
              cvProfile={cvProfile}
              onCreateNew={() => {
                setEditingPengajuan(null);
                setActiveTab('pengajuan-baru');
              }}
              onViewDetail={(p) => setSelectedPengajuanDetail(p)}
              onEditPengajuan={(p) => {
                setEditingPengajuan(p);
                setActiveTab('pengajuan-baru');
              }}
            />
          );
      }
    }

    // ROLE CV PENYEDIA
    if (currentUser?.role === 'CV') {
      switch (activeTab) {
        case 'dashboard':
          return (
            <DashboardCV
              pengajuanList={allPengajuan}
              lembagaList={allLembaga}
              cvProfile={cvProfile}
              onViewDetail={(p) => setSelectedPengajuanDetail(p)}
              onReviewPengajuan={(p) => setSelectedPengajuanReview(p)}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          );

        case 'data-lembaga':
          return (
            <DataLembagaView
              lembagaList={allLembaga}
              pengajuanList={allPengajuan}
              onSelectLembaga={(lemId) => {
                setDrilldownLembagaId(lemId);
                setActiveTab('rekap-per-lembaga');
              }}
            />
          );

        case 'master-buku':
          return <MasterBukuView />;

        case 'pengajuan-masuk':
        case 'perlu-revisi':
        case 'disetujui':
        case 'ditolak': {
          let filterStatus: StatusPengajuan | undefined;
          let title = 'Semua Pengajuan Masuk';
          if (activeTab === 'pengajuan-masuk') {
            title = 'Pengajuan Masuk (Menunggu Pemeriksaan CV)';
          } else if (activeTab === 'perlu-revisi') {
            filterStatus = 'PERLU REVISI';
            title = 'Pengajuan Dalam Status Perlu Revisi';
          } else if (activeTab === 'disetujui') {
            filterStatus = 'DISETUJUI';
            title = 'Pengajuan yang Telah Disetujui';
          } else if (activeTab === 'ditolak') {
            filterStatus = 'DITOLAK';
            title = 'Pengajuan yang Ditolak';
          }

          const filteredList = activeTab === 'pengajuan-masuk'
            ? allPengajuan.filter(p => p.status === 'DIKIRIM LEMBAGA' || p.status === 'DIPERIKSA CV')
            : filterStatus 
            ? allPengajuan.filter(p => p.status === filterStatus)
            : allPengajuan;

          return (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">{title}</h2>
                  <p className="text-xs text-slate-500">
                    Menampilkan {filteredList.length} pengajuan dari sekolah.
                  </p>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Lembaga & NPSN</th>
                      <th className="py-3 px-4">Nomor & Tanggal</th>
                      <th className="py-3 px-4">Jenjang & Wilayah</th>
                      <th className="py-3 px-4 text-right">Volume Buku</th>
                      <th className="py-3 px-4 text-right">Nilai Rencana</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-center">Aksi CV</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredList.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-slate-400">
                          Tidak ada pengajuan pada tab ini.
                        </td>
                      </tr>
                    ) : (
                      filteredList.map(p => {
                        const lem = allLembaga.find(l => l.id === p.lembagaId);
                        return (
                          <tr key={p.id} className="hover:bg-slate-50">
                            <td className="py-3.5 px-4 font-semibold text-slate-900">
                              {lem ? lem.namaLembaga : '-'}
                              <span className="block text-[10px] text-slate-400 font-normal">
                                NPSN: {lem ? lem.npsn : '-'} • KS: {lem ? lem.kepalaSekolah : '-'}
                              </span>
                            </td>
                            <td className="py-3.5 px-4">
                              <span className="font-mono font-bold text-blue-700 block">{p.nomorPengajuan}</span>
                              <span className="text-[10px] text-slate-400">{formatDateIndo(p.tanggalPengajuan)}</span>
                            </td>
                            <td className="py-3.5 px-4">
                              <span className="px-1.5 py-0.5 rounded bg-slate-100 font-semibold text-[10px] mr-1">
                                {lem ? lem.jenjang : '-'}
                              </span>
                              Kec. {lem ? lem.kecamatan : '-'}
                            </td>
                            <td className="py-3.5 px-4 text-right font-medium text-slate-900">
                              {p.totalBuku.toLocaleString('id-ID')} Eks
                            </td>
                            <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                              {formatRupiah(p.totalNilai)}
                            </td>
                            <td className="py-3.5 px-4 text-center">
                              <StatusBadge status={p.status} size="sm" />
                            </td>
                            <td className="py-3.5 px-4 text-center whitespace-nowrap">
                              <div className="flex items-center justify-center gap-1.5">
                                <button
                                  onClick={() => setSelectedPengajuanDetail(p)}
                                  className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs"
                                >
                                  Detail
                                </button>
                                <button
                                  onClick={() => setSelectedPengajuanReview(p)}
                                  className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs"
                                >
                                  Verifikasi →
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          );
        }

        case 'rekap-pengajuan':
          return (
            <RekapKeseluruhanView
              pengajuanList={allPengajuan}
              lembagaList={allLembaga}
              cvProfile={cvProfile}
              onViewDetail={(p) => setSelectedPengajuanDetail(p)}
            />
          );

        case 'rekap-buku':
          return (
            <RekapDetailBukuView
              pengajuanList={allPengajuan}
              lembagaList={allLembaga}
              cvProfile={cvProfile}
            />
          );

        case 'rekap-per-lembaga':
          return (
            <RekapPerLembagaView
              lembagaList={allLembaga}
              pengajuanList={allPengajuan}
              cvProfile={cvProfile}
              initialSelectedLembagaId={drilldownLembagaId}
              onViewDetailPengajuan={(p) => setSelectedPengajuanDetail(p)}
            />
          );

        case 'pengaturan':
          return (
            <SuperAdminSettingsView
              cvProfile={cvProfile}
              onProfileUpdated={() => {
                setCvProfile(arkasStorage.getCVProfile());
                setAllPengajuan(arkasStorage.getAllPengajuan());
                setAllLembaga(arkasStorage.getAllLembaga());
              }}
            />
          );

        default:
          return (
            <DashboardCV
              pengajuanList={allPengajuan}
              lembagaList={allLembaga}
              cvProfile={cvProfile}
              onViewDetail={(p) => setSelectedPengajuanDetail(p)}
              onReviewPengajuan={(p) => setSelectedPengajuanReview(p)}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          );
      }
    }

    return null;
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* 1. Top Navigation Bar */}
      <Navbar
        currentUser={currentUser}
        currentLembaga={currentLembaga}
        cvProfile={cvProfile}
        onOpenAuditLogs={() => setShowAuditLogModal(true)}
        onOpenProfile={() => setShowProfileModal(true)}
        onOpenNotifications={() => setShowNotificationsModal(true)}
        onLogout={handleLogout}
        onNavigateTab={(tab) => handleTabChange(tab)}
      />

      {/* Mobile Top Bar Navigation Drawer Trigger */}
      <div className="lg:hidden bg-slate-900 text-white px-4 py-2.5 flex items-center justify-between">
        <button
          onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          className="flex items-center gap-2 text-xs font-semibold text-slate-200"
        >
          {mobileSidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>Menu Navigasi ({currentUser?.role === 'CV' ? 'CV' : 'Sekolah'})</span>
        </button>

        <span className="text-xs font-bold text-blue-400 capitalize">
          {activeTab.replace('-', ' ')}
        </span>
      </div>

      {/* 3. Main Layout: Sidebar + Main Workspace */}
      <div className="flex-1 flex overflow-hidden max-w-7xl w-full mx-auto">
        {/* Desktop Sidebar */}
        <div className="hidden lg:block">
          <Sidebar
            role={currentUser?.role || 'LEMBAGA'}
            activeTab={activeTab}
            onSelectTab={handleTabChange}
            onLogout={handleLogout}
            badgeCounts={badgeCounts}
          />
        </div>

        {/* Mobile Drawer Sidebar */}
        {mobileSidebarOpen && (
          <div className="fixed inset-0 z-40 lg:hidden flex">
            <div className="fixed inset-0 bg-slate-900/60" onClick={() => setMobileSidebarOpen(false)} />
            <div className="relative z-50 w-72 bg-slate-900 text-white flex flex-col h-full shadow-2xl">
              <Sidebar
                role={currentUser?.role || 'LEMBAGA'}
                activeTab={activeTab}
                onSelectTab={handleTabChange}
                onLogout={handleLogout}
                badgeCounts={badgeCounts}
              />
            </div>
          </div>
        )}

        {/* Main Workspace */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto min-h-[calc(100vh-8rem)]">
          {renderMainContent()}
        </main>
      </div>

      {/* MODAL: DETAIL PENGAJUAN */}
      {selectedPengajuanDetail && (
        <DetailPengajuanModal
          pengajuan={selectedPengajuanDetail}
          lembaga={allLembaga.find(l => l.id === selectedPengajuanDetail.lembagaId) || currentLembaga || allLembaga[0]}
          cvProfile={cvProfile}
          currentRole={currentUser?.role || 'LEMBAGA'}
          onClose={() => setSelectedPengajuanDetail(null)}
          onEdit={(p) => {
            setSelectedPengajuanDetail(null);
            setEditingPengajuan(p);
            setActiveTab('pengajuan-baru');
          }}
          onOpenCVReview={(p) => {
            setSelectedPengajuanDetail(null);
            setSelectedPengajuanReview(p);
          }}
        />
      )}

      {/* MODAL: REVIEW PENGAJUAN (CV) */}
      {selectedPengajuanReview && (
        <ReviewPengajuanModal
          pengajuan={selectedPengajuanReview}
          lembaga={allLembaga.find(l => l.id === selectedPengajuanReview.lembagaId) || allLembaga[0]}
          cvProfile={cvProfile}
          onClose={() => setSelectedPengajuanReview(null)}
          onSubmitReview={handleReviewDecision}
        />
      )}

      {/* MODAL: AUDIT LOG */}
      {showAuditLogModal && (
        <AuditLogModal onClose={() => setShowAuditLogModal(false)} />
      )}

      {/* MODAL: PROFIL */}
      {showProfileModal && (
        <ProfilModal
          role={currentUser?.role || 'LEMBAGA'}
          lembaga={currentLembaga}
          cvProfile={cvProfile}
          onClose={() => setShowProfileModal(false)}
          onProfileUpdated={() => {
            setCvProfile(arkasStorage.getCVProfile());
            setCurrentLembaga(arkasStorage.getCurrentLembaga());
          }}
        />
      )}

      {/* MODAL: NOTIFIKASI */}
      {showNotificationsModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Bell className="w-4 h-4 text-blue-600" />
                <span>Pemberitahuan Sistem Pengajuan</span>
              </h3>
              <button onClick={() => setShowNotificationsModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-2.5 max-h-72 overflow-y-auto">
              {currentUser?.role === 'CV' ? (
                allPengajuan.filter(p => p.status === 'DIKIRIM LEMBAGA').length > 0 ? (
                  allPengajuan.filter(p => p.status === 'DIKIRIM LEMBAGA').map(p => {
                    const lem = allLembaga.find(l => l.id === p.lembagaId);
                    return (
                      <div 
                        key={p.id} 
                        onClick={() => {
                          setShowNotificationsModal(false);
                          setSelectedPengajuanReview(p);
                        }}
                        className="p-3 rounded-xl bg-blue-50 border border-blue-200 cursor-pointer hover:bg-blue-100 transition-colors"
                      >
                        <div className="font-bold text-blue-900">{lem ? lem.namaLembaga : 'Lembaga'}</div>
                        <div className="text-[11px] text-blue-700">Mengirimkan pengajuan {p.nomorPengajuan} ({p.totalBuku} eksemplar)</div>
                        <span className="text-[10px] text-blue-500 mt-1 block">Klik untuk periksa dan verifikasi →</span>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-center text-slate-400 py-6">Tidak ada pengajuan baru yang menunggu.</p>
                )
              ) : (
                lembagaPengajuanList.filter(p => p.status === 'PERLU REVISI').length > 0 ? (
                  lembagaPengajuanList.filter(p => p.status === 'PERLU REVISI').map(p => (
                    <div 
                      key={p.id} 
                      onClick={() => {
                        setShowNotificationsModal(false);
                        setSelectedPengajuanDetail(p);
                      }}
                      className="p-3 rounded-xl bg-orange-50 border border-orange-200 cursor-pointer hover:bg-orange-100 transition-colors"
                    >
                      <div className="font-bold text-orange-900">Perhatian: Revisi Pengajuan {p.nomorPengajuan}</div>
                      <div className="text-[11px] text-orange-800">Catatan CV: "{p.catatanCv}"</div>
                      <span className="text-[10px] text-orange-600 mt-1 block">Klik untuk melihat detail & kirim revisi →</span>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-slate-400 py-6">Tidak ada notifikasi revisi yang perlu tindakan.</p>
                )
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setShowNotificationsModal(false)}
                className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-xs"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: AUTH / LOGIN */}
      {showAuthModal && (
        <AuthModal
          onSuccess={handleLoginSuccess}
          onOpenRegister={() => {
            setShowAuthModal(false);
            setShowRegisterModal(true);
          }}
        />
      )}

      {/* MODAL: REGISTRASI LEMBAGA */}
      {showRegisterModal && (
        <RegisterModal
          onClose={() => {
            setShowRegisterModal(false);
            if (!currentUser) setShowAuthModal(true);
          }}
          onSuccess={handleLoginSuccess}
          onSwitchToLogin={() => {
            setShowRegisterModal(false);
            setShowAuthModal(true);
          }}
        />
      )}
    </div>
  );
}
