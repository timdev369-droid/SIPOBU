/**
 * Tipe data untuk SIPOBU (Sistem Informasi Pemesanan Buku)
 */

export type UserRole = 'LEMBAGA' | 'CV';

export type JenjangPendidikan = 
  | 'PAUD' 
  | 'TK' 
  | 'SD' 
  | 'SMP' 
  | 'SMA' 
  | 'SMK' 
  | 'PKBM' 
  | 'Lainnya';

export type StatusLembaga = 'Negeri' | 'Swasta';

export type StatusPengajuan = 
  | 'DRAFT'
  | 'DIKIRIM LEMBAGA'
  | 'DIPERIKSA CV'
  | 'PERLU REVISI'
  | 'DISETUJUI'
  | 'SELESAI REKAP'
  | 'DITOLAK';

export interface User {
  id: string;
  username: string;
  email: string;
  password?: string;
  role: UserRole;
  status: 'ACTIVE' | 'INACTIVE' | 'PENDING';
  lembagaId?: string; // id lembaga jika role = LEMBAGA
  createdAt: string;
}

export interface Lembaga {
  id: string;
  userId: string;
  npsn: string;
  namaLembaga: string;
  jenjang: JenjangPendidikan;
  statusLembaga: StatusLembaga;
  kepalaSekolah: string;
  nipKepalaSekolah?: string;
  operator: string;
  email: string;
  whatsapp: string;
  telepon: string;
  alamat: string;
  desa: string;
  kecamatan: string;
  kabupaten: string;
  provinsi: string;
  createdAt: string;
}

export interface CVProfile {
  id: string;
  namaCv: string;
  direktur: string;
  jabatanDirektur?: string;
  nipDirektur?: string;
  alamat: string;
  telepon: string;
  whatsapp: string;
  email: string;
  tahunAnggaranAktif: string;
  keterangan: string;
}

export interface FieldVisibilityConfig {
  tampilkan: boolean;
  wajib: boolean;
  label?: string;
  keterangan?: string;
}

export interface RegistrationSettings {
  bukaRegistrasi: boolean;
  pesanRegistrasiTutup: string;
  autoApprove: boolean; // Jika true, akun langsung aktif. Jika false, akun berstatus PENDING perlu verifikasi Admin CV
  pesanPendingVerifikasi: string;
  jenjangDiizinkan: JenjangPendidikan[];
  statusLembagaDiizinkan: 'SEMUA' | 'NEGERI_SAJA' | 'SWASTA_SAJA';
  defaultKabupaten: string;
  defaultProvinsi: string;
  kunciWilayahDefault: boolean; // Mengunci input Kabupaten & Provinsi sesuai wilayah kerja CV
  wajibValidasiNpsn8Digit: boolean;
  minPanjangPassword: number;
  petunjukRegistrasi: string;
  wajibCentangPernyataan: boolean;
  teksPernyataan: string;
  notifWaAdminRegistrasi: boolean;

  // Konfigurasi Field Isian Formulir
  fields: {
    nipKepalaSekolah: FieldVisibilityConfig;
    teleponKantor: FieldVisibilityConfig;
    alamatJalan: FieldVisibilityConfig;
    desa: FieldVisibilityConfig;
    kecamatan: FieldVisibilityConfig;
    emailSekolah: FieldVisibilityConfig;
    whatsappOperator: FieldVisibilityConfig;
    namaOperator: FieldVisibilityConfig;
  };
}

export interface SystemSettings {
  tahunAnggaranAktif: string;
  periodePengajuanBuka: boolean;
  batasWaktuPengajuan?: string; // Format: YYYY-MM-DD
  prefixNomorPengajuan: string; // e.g. "PB"
  digitNomorUrut: number; // e.g. 4
  izinkanBukuCustom: boolean; // Sekolah boleh ajukan buku baru di luar master
  minEksemplarPerItem: number; // e.g. 1
  maxEksemplarPerItem: number; // e.g. 1000
  disclaimerDokumen: string;
  templateCatatanSetuju: string;
  templateCatatanRevisi: string;
  notifWaAdminAktif: boolean; // Notifikasi otomatis WA admin saat pengajuan masuk
  nomorWaAdmin: string; // Nomor WA Admin CV penerima
  templatePesanWaAdmin?: string; // Format teks WA custom
  registrationSettings?: RegistrationSettings; // Pengaturan data isian registrasi
}

export interface Buku {
  id: string;
  kodeBuku: string;
  isbn: string;
  judul: string;
  penulis: string;
  penerbit: string;
  jenjang: JenjangPendidikan;
  kelas: string; // misal "Kelas 1", "Kelas 7", dsb.
  mataPelajaran: string;
  kurikulum: 'Kurikulum Merdeka' | 'Kurikulum 2013' | 'Lainnya';
  hargaReferensi: number;
  satuan: string; // Eksemplar / Paket
  status: 'ACTIVE' | 'INACTIVE';
}

export interface PengajuanItem {
  id: string;
  bukuId?: string;
  kodeBuku: string;
  isbn: string;
  judul: string;
  penulis?: string;
  penerbit: string;
  jenjang: JenjangPendidikan;
  kelas: string;
  mataPelajaran: string;
  kurikulum: string;
  jumlah: number;
  hargaSatuan: number;
  total: number;
  keterangan?: string;
}

export interface PengajuanHistory {
  id: string;
  pengajuanId: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  statusSebelumnya?: StatusPengajuan;
  statusBaru: StatusPengajuan;
  catatan: string;
  createdAt: string;
}

export interface Pengajuan {
  id: string;
  nomorPengajuan: string; // Format: PB-2026-0001
  lembagaId: string;
  tahunAnggaran: string;
  tanggalPengajuan: string;
  status: StatusPengajuan;
  catatanCv?: string;
  keteranganUmum?: string;
  items: PengajuanItem[];
  totalJenisBuku: number;
  totalBuku: number;
  totalNilai: number;
  history: PengajuanHistory[];
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  aktivitas: string;
  referensiId?: string; // nomor pengajuan atau ID item
  ipDevice?: string;
  createdAt: string;
}

export interface RekapFilterOptions {
  tahunAnggaran?: string;
  kecamatan?: string;
  jenjang?: string;
  lembagaId?: string;
  status?: string;
  startDate?: string;
  endDate?: string;
  searchQuery?: string;
}
